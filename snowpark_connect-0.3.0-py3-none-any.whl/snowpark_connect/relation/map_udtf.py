import inspect

import pandas
import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from pyspark.serializers import CloudPickleSerializer
from snowflake import snowpark

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark._internal.type_utils import python_type_to_snow_type
from snowflake.snowpark.types import VariantType
from snowpark_connect.column_name_handler import ColumnNameMap, build_column_map
from snowpark_connect.expression.map_expression import map_single_column_expression
from snowpark_connect.expression.map_udf import infer_udf_dependencies
from snowpark_connect.expression.typer import ExpressionTyper
from snowpark_connect.type_mapping import parse_ddl_string, proto_to_snowpark_type


def udtf_helper(udtf_proto: relation_proto.CommonInlineUserDefinedTableFunction):
    udtf = udtf_proto.python_udtf
    callable_func = CloudPickleSerializer().loads(udtf.command)
    callable_func.process = callable_func.eval
    func_signature = inspect.signature(callable_func.process)

    modules = infer_udf_dependencies(callable_func.process)
    packages = [module.__name__ for module in modules]

    input_types = []
    for param in func_signature.parameters.values():
        if param.name == "self":
            continue
        param_type = (
            python_type_to_snow_type(param.annotation)[0]
            if (
                param.annotation != inspect.Parameter.empty
                and param.annotation != pandas.core.series.Series
            )
            else VariantType()
        )
        input_types.append(param_type)

    parsed_return = parse_ddl_string(udtf.return_type.unparsed.data_type_string)
    output_schema = proto_to_snowpark_type(parsed_return)
    spark_column_names = [f.name for f in parsed_return.struct.fields]

    return (
        callable_func,
        output_schema,
        input_types,
        udtf_proto.function_name,
        packages,
        func_signature,
        spark_column_names,
    )


def register_udtf(
    udtf_proto: relation_proto.CommonInlineUserDefinedTableFunction,
) -> snowpark.udtf.UserDefinedTableFunction:
    match udtf_proto.WhichOneof("function"):
        case "python_udtf":
            session = snowpark.Session.builder.getOrCreate()
            (
                callable_func,
                output_schema,
                input_types,
                function_name,
                packages,
                _,
                spark_column_names,
            ) = udtf_helper(udtf_proto)

            udtf = session.udtf.register(
                handler=callable_func,
                output_schema=output_schema,
                input_types=input_types,
                replace=True,
                packages=packages,
            )
            session._udtfs[function_name.lower()] = (udtf, spark_column_names)
            return udtf
        case _:
            raise ValueError(f"Not python udtf {udtf_proto.function}")


def map_common_inline_user_defined_table_function(
    rel: relation_proto.CommonInlineUserDefinedTableFunction,
) -> snowpark.DataFrame:
    session = snowpark.Session.builder.getOrCreate()
    match rel.WhichOneof("function"):
        case "python_udtf":
            (
                callable_func,
                output_schema,
                _,
                function_name,
                packages,
                func_signature,
                spark_column_names,
            ) = udtf_helper(rel)

            column_map = ColumnNameMap([], [])
            snowpark_udtf_args = []
            input_types = []
            for arg_exp in rel.arguments:
                (_, snowpark_udtf_arg_tc) = map_single_column_expression(
                    arg_exp, column_map, ExpressionTyper.dummy_typer(session)
                )
                snowpark_udtf_arg = snowpark_udtf_arg_tc.col
                snowpark_udtf_args.append(snowpark_udtf_arg)
                input_types.append(snowpark_udtf_arg_tc.typ)

            snowpark_udtf = snowpark_fn.udtf(
                handler=callable_func,
                output_schema=output_schema,
                input_types=input_types,
                name=function_name,
                replace=True,
                packages=packages,
            )
            df = session.table_function(snowpark_udtf(*snowpark_udtf_args))
            snowpark_columns = [f.name for f in output_schema.fields]
            return build_column_map(
                df, spark_column_names, snowpark_column_names=snowpark_columns
            )
        case _:
            raise ValueError(f"Not python udtf {rel.python_udtf}")
