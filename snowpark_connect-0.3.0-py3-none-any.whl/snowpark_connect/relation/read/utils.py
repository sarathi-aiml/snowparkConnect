from typing import (  # noqa: F401
    TYPE_CHECKING,
    Any,
    Dict,
    Generator,
    Iterator,
    List,
    NewType,
    Optional,
    Protocol,
    Tuple,
    Type,
    Union,
    get_args,
    get_origin,
)

from snowflake import snowpark
from snowflake.core._internal.utils import normalize_path

from snowflake.snowpark._internal.analyzer import analyzer_utils

STATEMENT_PARAMS_DATA_SOURCE = "SNOWPARK_PYTHON_DATASOURCE"
DATA_SOURCE_DBAPI_SIGNATURE = "DataFrameReader.dbapi"
DATA_SOURCE_SQL_COMMENT = (
    f"/* Python:snowflake.snowpark.{DATA_SOURCE_DBAPI_SIGNATURE} */"
)


def rename_columns_as_snowflake_standard(
    df: snowpark.DataFrame,
) -> tuple[snowpark.DataFrame, list[str]]:
    """
    Renames the columns of a Snowflake DataFrame to follow a standard format.
    Args:
        df (snowpark.DataFrame): The input Snowflake DataFrame.

    Returns:
        tuple[snowpark.DataFrame, list[str]]: A tuple containing the modified DataFrame
        with renamed columns and a list of the new column names.
    """

    if df.columns is None or len(df.columns) == 0:
        return df, []

    new_names_unquoted = [
        f"{analyzer_utils.unquote_if_quoted(df.columns[i])}-{i}"
        for i in range(len(df.columns))
    ]
    return (
        df.select(
            *[
                df.col(df.columns[i]).alias(new_names_unquoted[i])
                for i in range(len(df.columns))
            ]
        ),
        list(map(analyzer_utils.quote_name_without_upper_casing, new_names_unquoted)),
    )


# Copied from snowflake.snowpark._internal.type_utils
# and snowflake.snowpark._internal.utils
# We will remove it once Snowpark team merge this code in main
def normalize_local_file(file: str) -> str:
    return normalize_path(file, is_local=True)


class Connection(Protocol):
    """External datasource connection created from user-input create_connection function."""

    def cursor(self) -> "Cursor":
        pass

    def close(self):
        pass

    def commit(self):
        pass

    def rollback(self):
        pass


class Cursor(Protocol):
    """Cursor created from external datasource connection"""

    def execute(self, sql: str, *params: Any) -> "Cursor":
        pass

    def fetchall(self):
        pass

    def fetchone(self):
        pass

    def close(self):
        pass
