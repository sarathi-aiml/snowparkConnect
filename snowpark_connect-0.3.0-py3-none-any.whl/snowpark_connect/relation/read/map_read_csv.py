import copy
import re

import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

from snowflake.snowpark._internal.analyzer import analyzer_utils
from snowpark_connect.column_name_handler import build_column_map
from snowpark_connect.relation.read.map_read import CsvReaderConfig
from snowpark_connect.relation.read.utils import rename_columns_as_snowflake_standard
from snowpark_connect.utils.telemetry import SnowparkConnectNotImplementedError


def map_read_csv(
    rel: relation_proto.Relation,
    schema: snowpark.types.StructType | None,
    session: snowpark.Session,
    paths: list[str],
    options: CsvReaderConfig,
) -> snowpark.DataFrame:
    """
    Read a CSV file into a Snowpark DataFrame.

    We leverage the stage that is already created in the map_read function that
    calls this.
    """
    if rel.read.is_streaming is True:
        # TODO: Structured streaming implementation.
        raise SnowparkConnectNotImplementedError(
            "Streaming is not supported for CSV files."
        )
    else:
        snowpark_options = options.convert_to_snowpark_args()
        if schema is None:
            reader = session.read.options(snowpark_options)
        else:
            reader = session.read.options(snowpark_options).schema(schema)
        df = reader.csv(paths[0])
        sanity_check(df, schema, session, paths[0], snowpark_options)
        if len(paths) > 1:
            # TODO: figure out if this is what Spark does.
            for p in paths[1:]:
                df = df.union_all(session.read.options(snowpark_options).csv(p))

        def subtract_one(match):
            """Spark column names are 0 indexed, Snowpark is 1 indexed."""
            return f"_c{str(int(match.group(2)) - 1)}"

        spark_column_names = [
            analyzer_utils.unquote_if_quoted(
                re.sub(r"(^\"c)(\d+)(\"$)", subtract_one, c)
            )
            for c in df.columns
        ]

        renamed_df, snowpark_column_names = rename_columns_as_snowflake_standard(df)
        return build_column_map(renamed_df, spark_column_names, snowpark_column_names)


def sanity_check(
    df: snowpark.DataFrame,
    schema: snowpark.types.StructType | None,
    session: snowpark.Session,
    path: list[str],
    snowpark_options: dict,
) -> None:
    filename = path.strip("/").split("/")[-1]
    if schema is not None:
        if len(schema.fields) != len(df.schema.fields):
            raise Exception(f"csv load from {filename} failed.")

    # TODO: Snowpark infer schema call failure ends with only 1 column
    if (
        len(df.schema.fields) == 1
        and df.schema.fields[0].name.upper() == "C1"
        and snowpark_options.get("PARSE_HEADER") is True
    ):
        snowpark_options_no_header = copy.copy(snowpark_options)
        snowpark_options_no_header["PARSE_HEADER"] = False
        df_no_header = session.read.options(snowpark_options_no_header).csv(path)
        if len(df_no_header.schema.fields) != len(df.schema.fields):
            raise Exception(f"csv load from {filename} failed.")
