import typing
from abc import ABC, abstractmethod
from dataclasses import dataclass

import pandas
from snowflake import snowpark

from snowpark_connect.utils.telemetry import SnowparkConnectNotImplementedError


class AbstractSparkCatalog(ABC):
    @abstractmethod
    def __init__(self) -> None:
        pass

    @abstractmethod
    def listDatabases(
        self,
        pattern: typing.Optional[str] = None,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("listDatabases is not implemented")

    @abstractmethod
    def getDatabase(
        self,
        dbName: str,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("getDatabase is not implemented")

    @abstractmethod
    def databaseExists(
        self,
        dbName: str,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("databaseExists is not implemented")

    @abstractmethod
    def listTables(
        self,
        dbName: typing.Optional[str] = None,
        schemaName: typing.Optional[str] = None,
        pattern: typing.Optional[str] = None,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("listTables is not implemented")

    @abstractmethod
    def getTable(
        self,
        tableName: str,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("getTable is not implemented")

    @abstractmethod
    def tableExists(
        self,
        tableName: str,
        dbName: typing.Optional[str],
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("tableExists is not implemented")

    @abstractmethod
    def listColumns(
        self,
        tableName: str,
        dbName: typing.Optional[str] = None,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("listColumns is not implemented")

    @abstractmethod
    def currentDatabase(self) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError("currentDatabase is not implemented")

    @abstractmethod
    def setCurrentDatabase(
        self,
        db_name: str,
    ) -> pandas.DataFrame:
        raise SnowparkConnectNotImplementedError(
            "setCurrentDatabase is not implemented"
        )

    @abstractmethod
    def dropGlobalTempView(
        self,
        view_name: str,
    ) -> snowpark.DataFrame:
        raise SnowparkConnectNotImplementedError(
            "dropGlobalTempView is not implemented"
        )

    @abstractmethod
    def dropTempView(
        self,
        view_name: str,
    ) -> snowpark.DataFrame:
        raise SnowparkConnectNotImplementedError("dropTempView is not implemented")


@dataclass
class CatalogMetadata:
    name: str
    description: str = None
