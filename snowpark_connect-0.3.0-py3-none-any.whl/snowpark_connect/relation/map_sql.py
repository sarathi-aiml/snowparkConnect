from collections.abc import MutableMapping, MutableSequence
from functools import reduce

import pandas
import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
import pyspark.sql.connect.proto.relations_pb2 as relation_proto
import sqlglot
import sqlglot.expressions
from snowflake import snowpark

from snowpark_connect.expression.map_expression import (
    ColumnNameMap,
    map_single_column_expression,
)
from snowpark_connect.relation.map_relation import map_relation
from snowpark_connect.utils.context import (
    gen_sql_plan_id,
    push_sql_scope,
    set_sql_args,
    set_sql_plan_name,
)
from snowpark_connect.utils.telemetry import SnowparkConnectNotImplementedError

from ..expression.map_sql_expression import (
    as_java_list,
    executing_mapped_sql,
    map_logical_plan_expression,
    sql_parser,
)


def _find_pos_args(node, positions: list[int]):
    if str(node.nodeName()) == "PosParameter":
        positions.append(node.pos())
    else:
        for child in as_java_list(node.children()):
            _find_pos_args(child, positions)
        if hasattr(node, "expressions"):
            for child in as_java_list(node.expressions()):
                _find_pos_args(child, positions)


def parse_pos_args(
    logical_plan,
    pos_args: MutableSequence[expressions_proto.Expression.Literal],
) -> dict[int, expressions_proto.Expression]:
    # Spark Connect gives us positional parameters as a regular list,
    # while Spark parser refers to them by their character indexes in the query.
    # Therefore, we need to find all positional parameters, sort their locations,
    # and match them to the list from Spark Connect.
    if not pos_args:
        return {}

    positions: list[int] = []
    _find_pos_args(logical_plan, positions)
    return dict(zip(sorted(positions), pos_args))


def execute_logical_plan(logical_plan) -> snowpark.DataFrame:
    proto = map_logical_plan_relation(logical_plan)
    with executing_mapped_sql():
        return map_relation(proto)


def map_sql_to_pandas_df(
    sql_string: str,
    named_args: MutableMapping[str, expressions_proto.Expression.Literal],
    pos_args: MutableSequence[expressions_proto.Expression.Literal],
) -> tuple[pandas.DataFrame, str] | tuple[None, None]:
    """
    Convert a sql string into a pandas DataFrame and its json schema.
    returns a tuple of empty Pandas DataFrame and schema string in case of DDL statements.
    returns a tuple of None for SELECT queries to enable lazy evaluation
    """
    logical_plan = sql_parser().parsePlan(sql_string)
    parsed_pos_args = parse_pos_args(logical_plan, pos_args)
    set_sql_args(named_args, parsed_pos_args)

    session = snowpark.Session.get_active_session()

    rows: list | None = None

    while logical_plan.nodeName() == "UnresolvedHint":
        logical_plan = logical_plan.child()

    match str(logical_plan.nodeName()):
        case "CreateView":
            df = execute_logical_plan(logical_plan.query())

            name = [str(p) for p in as_java_list(logical_plan.child().nameParts())]
            user_columns = [
                str(col._1())
                for col in as_java_list(logical_plan.userSpecifiedColumns())
            ]
            comment = logical_plan.comment()

            if user_columns:
                for orig_column, user_column in zip(df.columns, user_columns):
                    df = df.with_column_renamed(orig_column, user_column)

            df.create_temp_view(
                name,
                comment=str(comment) if comment.isDefined() else None,
            )
        case "CreateViewCommand":
            df = execute_logical_plan(logical_plan.plan())

            name = str(logical_plan.name().identifier())
            user_columns = [
                str(col._1())
                for col in as_java_list(logical_plan.userSpecifiedColumns())
            ]
            comment = logical_plan.comment()

            if user_columns:
                for orig_column, user_column in zip(df.columns, user_columns):
                    df = df.with_column_renamed(orig_column, user_column)

            df.create_temp_view(
                name,
                comment=str(comment) if comment.isDefined() else None,
            )
        case "InsertIntoStatement":
            df = execute_logical_plan(logical_plan.query())
            queries = df.queries["queries"]
            if len(queries) != 1:
                raise SnowparkConnectNotImplementedError(
                    f"Unexpected number of queries: {len(queries)}"
                )

            name = str(logical_plan.table().name())

            user_columns = [
                str(col) for col in as_java_list(logical_plan.userSpecifiedCols())
            ]
            overwrite_str = "OVERWRITE" if logical_plan.overwrite() else ""
            # TODO: How do we use `IDENTIFIER(?)`?
            cols_str = "(" + ", ".join(user_columns) + ")" if user_columns else ""

            session.sql(
                f"INSERT {overwrite_str} INTO IDENTIFIER(?) {cols_str} {queries[0]}",
                [name],
            ).collect()
        case command if (
            command.startswith("Create")
            or command.startswith("Set")
            or command.startswith("Alter")
            or command.startswith("Rename")
            or command.startswith("Replace")
            or command.startswith("Truncate")
            or command.startswith("Drop")
        ):
            parsed_sql = sqlglot.parse_one(sql_string, dialect="spark")
            snowflake_sql = parsed_sql.sql(dialect="snowflake")
            session.sql(snowflake_sql).collect()
        case command if (command.startswith("Describe") or command.startswith("Show")):
            parsed_sql = sqlglot.parse_one(sql_string, dialect="spark")
            snowflake_sql = parsed_sql.sql(dialect="snowflake")
            rows = session.sql(snowflake_sql).collect()
        case _:
            execute_logical_plan(logical_plan)
            return None, None

    if rows is not None:
        return pandas.DataFrame(rows), ""
    return pandas.DataFrame({"": [""]}), ""


def map_sql(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Map a SQL string to a DataFrame.

    The SQL string is executed and the resulting DataFrame is returned.
    """
    logical_plan = sql_parser().parseQuery(rel.sql.query)

    parsed_pos_args = parse_pos_args(logical_plan, rel.sql.pos_args)
    set_sql_args(rel.sql.args, parsed_pos_args)

    return execute_logical_plan(logical_plan)


def map_logical_plan_relation(
    rel, plan_id: int | None = None
) -> relation_proto.Relation:
    if plan_id is None:
        plan_id = gen_sql_plan_id()

    match rel.nodeName():
        case "Aggregate":
            # TODO: How are other group types specified in `rel`?
            group_type = relation_proto.Aggregate.GROUP_TYPE_GROUPBY

            with push_sql_scope():
                input = map_logical_plan_relation(rel.child())

                # DataFrame operations automatically include all GROUP BY columns.
                # Give them dummy aliases.
                group_by_expressions = [
                    (f"__group_by_{idx}", map_logical_plan_expression(e))
                    for idx, e in enumerate(as_java_list(rel.groupingExpressions()))
                ]

                aggregate_expressions = [
                    map_logical_plan_expression(e)
                    for e in as_java_list(rel.aggregateExpressions())
                ]

            proto = relation_proto.Relation(
                aggregate=relation_proto.Aggregate(
                    input=input,
                    group_type=group_type,
                    grouping_expressions=[
                        expressions_proto.Expression(
                            alias=expressions_proto.Expression.Alias(
                                expr=e,
                                name=[alias],
                            ),
                        )
                        for alias, e in group_by_expressions
                    ],
                    aggregate_expressions=aggregate_expressions,
                )
            )

            # Now drop the dummy columns.
            proto = relation_proto.Relation(
                drop=relation_proto.Drop(
                    input=proto,
                    column_names=[alias for alias, _ in group_by_expressions],
                )
            )
        case "Filter":
            proto = relation_proto.Relation(
                filter=relation_proto.Filter(
                    input=map_logical_plan_relation(rel.child()),
                    condition=map_logical_plan_expression(rel.condition()),
                )
            )
        case "GlobalLimit":
            # TODO: What's a global limit and what's a local limit?
            proto = map_logical_plan_relation(rel.child())
        case "Join":
            join_type_sql = str(rel.joinType().sql())
            join_type_name = f"JOIN_TYPE_{join_type_sql.replace(' ', '_')}"
            condition = rel.condition()

            left = map_logical_plan_relation(rel.left())
            right = map_logical_plan_relation(rel.right())
            join_condition = (
                map_logical_plan_expression(condition.get())
                if condition.isDefined()
                else None
            )

            proto = relation_proto.Relation(
                join=relation_proto.Join(
                    left=left,
                    right=right,
                    join_condition=join_condition,
                    join_type=getattr(relation_proto.Join.JoinType, join_type_name),
                    using_columns=[],
                )
            )
        case "LocalLimit":
            proto = relation_proto.Relation(
                limit=relation_proto.Limit(
                    input=map_logical_plan_relation(rel.child()),
                    limit=rel.limitExpr().value(),
                )
            )
        case "Offset":
            proto = relation_proto.Relation(
                offset=relation_proto.Offset(
                    input=map_logical_plan_relation(rel.child()),
                    offset=rel.offsetExpr().value(),
                )
            )
        case "OneRowRelation":
            # TODO: What are we actually supposed to return here?
            proto = relation_proto.Relation(
                range=relation_proto.Range(
                    start=0,
                    end=1,
                    step=1,
                )
            )
        case "Project":
            with push_sql_scope():
                input = map_logical_plan_relation(rel.child())
                expressions = [
                    map_logical_plan_expression(e)
                    for e in as_java_list(rel.projectList())
                ]
            proto = relation_proto.Relation(
                project=relation_proto.Project(
                    input=input,
                    expressions=expressions,
                )
            )
        case "Sort":
            proto = relation_proto.Relation(
                sort=relation_proto.Sort(
                    input=map_logical_plan_relation(rel.child()),
                    order=[
                        map_logical_plan_expression(e).sort_order
                        for e in as_java_list(rel.order())
                    ],
                )
            )
        case "SubqueryAlias":
            alias = str(rel.alias())
            proto = relation_proto.Relation(
                subquery_alias=relation_proto.SubqueryAlias(
                    input=map_logical_plan_relation(rel.child()),
                    alias=alias,
                )
            )
            set_sql_plan_name(alias, plan_id)
        case "UnresolvedHaving":
            proto = relation_proto.Relation(
                filter=relation_proto.Filter(
                    input=map_logical_plan_relation(rel.child()),
                    condition=map_logical_plan_expression(rel.havingCondition()),
                )
            )
        case "UnresolvedHint":
            proto = relation_proto.Relation(
                hint=relation_proto.Hint(
                    input=map_logical_plan_relation(rel.child()),
                    name=str(rel.name()),
                    parameters=[
                        map_logical_plan_expression(e)
                        for e in as_java_list(rel.parameters())
                    ],
                )
            )
        case "UnresolvedInlineTable":
            names = [str(name) for name in as_java_list(rel.names())]
            one_row = relation_proto.Relation(
                range=relation_proto.Range(
                    start=0,
                    end=1,
                    step=1,
                )
            )
            rows = (
                relation_proto.Relation(
                    common=relation_proto.RelationCommon(
                        plan_id=gen_sql_plan_id(),
                    ),
                    project=relation_proto.Project(
                        input=one_row,
                        expressions=(
                            expressions_proto.Expression(
                                alias=expressions_proto.Expression.Alias(
                                    expr=map_logical_plan_expression(val),
                                    name=[name],
                                )
                            )
                            for name, val in zip(names, as_java_list(row))
                        ),
                    ),
                )
                for row in as_java_list(rel.rows())
            )

            proto = reduce(
                lambda left, right: relation_proto.Relation(
                    common=relation_proto.RelationCommon(
                        plan_id=gen_sql_plan_id(),
                    ),
                    set_op=relation_proto.SetOperation(
                        left_input=left,
                        right_input=right,
                        set_op_type=relation_proto.SetOperation.SET_OP_TYPE_UNION,
                        is_all=True,
                    ),
                ),
                rows,
            )
        case "UnresolvedRelation":
            name = str(rel.name())
            set_sql_plan_name(name, plan_id)

            proto = relation_proto.Relation(
                read=relation_proto.Read(
                    named_table=relation_proto.Read.NamedTable(
                        unparsed_identifier=name,
                    )
                )
            )
        case "UnresolvedTableValuedFunction":
            name = ".".join(str(part) for part in as_java_list(rel.name()))
            args = [
                map_logical_plan_expression(exp)
                for exp in as_java_list(rel.functionArgs())
            ]

            match name:
                case "range":
                    m = ColumnNameMap([], [], None)
                    session = snowpark.Session.get_active_session()
                    args = (
                        session.range(1)
                        .select(
                            [
                                map_single_column_expression(arg, m, None)[1].col
                                for arg in args
                            ]
                        )
                        .collect()[0]
                    )

                    start, step = 0, 1
                    match args:
                        case [_]:
                            [end] = args
                        case [_, _]:
                            [start, end] = args
                        case [_, _, _]:
                            [start, end, step] = args

                    proto = relation_proto.Relation(
                        range=relation_proto.Range(
                            start=start,
                            end=end,
                            step=step,
                        )
                    )
                case other:
                    proto = relation_proto.Relation(
                        project=relation_proto.Project(
                            input=relation_proto.Relation(
                                range=relation_proto.Range(
                                    start=0,
                                    end=1,
                                    step=1,
                                )
                            ),
                            expressions=[
                                expressions_proto.Expression(
                                    unresolved_function=expressions_proto.Expression.UnresolvedFunction(
                                        function_name=name,
                                        arguments=args,
                                    )
                                )
                            ],
                        ),
                    )
        case other:
            raise SnowparkConnectNotImplementedError(f"Unimplemented relation: {other}")

    proto.common.plan_id = plan_id

    return proto
