import json

import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

import snowflake.snowpark.functions as snowpark_fn
import snowflake.snowpark.types as snowpark_types
from snowflake.snowpark._internal.analyzer.analyzer_utils import unquote_if_quoted
from snowflake.snowpark._internal.analyzer.expression import (
    Attribute,
    NamedExpression,
    UnresolvedAttribute,
)

# These internal util functions and classes are unlikely to change in Snowpark, so importing them directly
from snowflake.snowpark._internal.utils import generate_random_alphanumeric
from snowflake.snowpark.column import Column
from snowpark_connect.column_name_handler import (
    build_column_map,
    make_column_names_snowpark_compatible,
)
from snowpark_connect.error.error_utils import SparkException
from snowpark_connect.expression.map_expression import (
    map_alias,
    map_expression,
    map_single_column_expression,
)
from snowpark_connect.expression.typer import ExpressionTyper
from snowpark_connect.relation.map_relation import map_relation
from snowpark_connect.relation.utils import snowpark_functions_col
from snowpark_connect.type_mapping import proto_to_snowpark_type


def map_drop(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Drop columns from a DataFrame.

    The drop is a list of expressions that is applied to the DataFrame.
    """
    input_df: snowpark.DataFrame = map_relation(rel.drop.input)
    typer = ExpressionTyper(input_df)
    columns_to_drop_with_names = [
        map_single_column_expression(exp, input_df._column_map, typer)
        for exp in rel.drop.columns
    ]
    columns_to_drop: list[Column] = [
        col[1].col for col in columns_to_drop_with_names
    ] + [
        snowpark_functions_col(c, input_df._column_map)
        for c in input_df._column_map.get_snowpark_column_names_from_spark_column_names(
            list(rel.drop.column_names)
        )
        if c is not None
    ]
    # Sometimes we get a drop query with only invalid names. In this case, we return
    # the input DataFrame.
    if len(columns_to_drop) == 0:
        return input_df

    def _get_column_names_to_drop() -> list[str]:
        # more or less copied from Snowpark's DataFrame::drop
        names = []
        for c in columns_to_drop:
            if isinstance(c._expression, Attribute):
                names.append(
                    input_df._plan.expr_to_alias.get(
                        c._expression.expr_id, c._expression.name
                    )
                )
            elif (
                isinstance(c._expression, UnresolvedAttribute)
                and c._expression.df_alias
            ):
                names.append(
                    input_df.self._plan.df_aliased_col_name_to_real_col_name.get(
                        c._expression.name, c._expression.name
                    )
                )
            elif isinstance(c._expression, NamedExpression):
                names.append(c._expression.name)
        return names

    # Snowpark doesn't allow dropping all columns, so we have an EmptyDataFrame
    # object to handle these cases.
    try:
        new_columns_names = input_df._column_map.get_snowpark_columns_after_drop(
            _get_column_names_to_drop()
        )
        result: snowpark.DataFrame = input_df.drop(*columns_to_drop)
        return build_column_map(
            result,
            input_df._column_map.get_spark_column_names_from_snowpark_column_names(
                new_columns_names
            ),
            snowpark_column_names=new_columns_names,
        )
    except snowpark.exceptions.SnowparkColumnException:
        from snowpark_connect.empty_dataframe import EmptyDataFrame

        return EmptyDataFrame()


def map_project(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Project column(s).

    Projections come in as expressions, which are mapped to `snowpark.Column`
    objects.
    """
    input_df = map_relation(rel.project.input)
    expressions: list[expressions_proto.Expression] = rel.project.expressions
    select_list = []
    new_spark_columns = []
    typer = ExpressionTyper(input_df)
    seen_columns = set()

    # we are trying to make sure we get unique snowpark columns but it is only handleing case where it is a Column instance
    # with the name and no alias
    for exp in expressions:
        new_spark_names, mapper = map_expression(exp, input_df._column_map, typer)
        column_name_str: str | None = None
        if (
            isinstance(mapper.col, Column)
            and getattr(mapper.col, "alias_name", None) is None
            and mapper.col.get_name() is not None
        ):
            column_name_str = mapper.col.get_name()
            if (
                column_name_str in seen_columns
                or unquote_if_quoted(column_name_str) in seen_columns
            ):
                column_name_str = make_column_names_snowpark_compatible(
                    [column_name_str], len(select_list)
                )[0]
            else:
                seen_columns.add(column_name_str)
                column_name_str = None

        if column_name_str is not None:
            select_list.append(mapper.col.alias(column_name_str))
        else:
            select_list.append(mapper.col)

        if new_spark_names == ["*"]:
            new_spark_columns.extend(
                input_df._column_map.get_spark_column_names_from_snowpark_column_names(
                    input_df.columns
                )
            )
            # * is a special case where we don't have that information of columns in mapper.col
            seen_columns = seen_columns | set(input_df.columns)
        else:
            new_spark_columns.extend(new_spark_names)
    result = input_df.select(*select_list)
    return build_column_map(
        result,
        new_spark_columns,
        result.columns,
        column_metadata=input_df._column_map.column_metadata,
    )


def map_sort(sort: relation_proto.Sort) -> snowpark.DataFrame:
    """
    Implements DataFrame.sort().
    """
    input_df = map_relation(sort.input)
    cols = []
    ascending = []  # Ignored if all order values are set to "unspecified".
    order_specified = False
    typer = ExpressionTyper(input_df)
    for so in sort.order:
        _, typed_column = map_single_column_expression(
            so.child, input_df._column_map, typer
        )
        col = typed_column.col

        match (so.direction, so.null_ordering):
            case (
                expressions_proto.Expression.SortOrder.SORT_DIRECTION_ASCENDING,
                expressions_proto.Expression.SortOrder.SORT_NULLS_FIRST,
            ):
                col = col.asc_nulls_first()
            case (
                expressions_proto.Expression.SortOrder.SORT_DIRECTION_ASCENDING,
                expressions_proto.Expression.SortOrder.SORT_NULLS_LAST,
            ):
                col = col.asc_nulls_last()
            case (
                expressions_proto.Expression.SortOrder.SORT_DIRECTION_DESCENDING,
                expressions_proto.Expression.SortOrder.SORT_NULLS_FIRST,
            ):
                col = col.desc_nulls_first()
            case (
                expressions_proto.Expression.SortOrder.SORT_DIRECTION_DESCENDING,
                expressions_proto.Expression.SortOrder.SORT_NULLS_LAST,
            ):
                col = col.desc_nulls_last()

        cols.append(col)

        ascending.append(
            so.direction
            == expressions_proto.Expression.SortOrder.SORT_DIRECTION_ASCENDING
        )
        if (
            so.direction
            != expressions_proto.Expression.SortOrder.SORT_DIRECTION_UNSPECIFIED
        ):
            order_specified = True

    # TODO: sort.isglobal.
    if not order_specified:
        ascending = None
    result = input_df.sort(cols, ascending=ascending)
    result._column_map = input_df._column_map
    return result


def map_to_df(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Transform the column names of the input DataFrame.
    """
    input_df: snowpark.DataFrame = map_relation(rel.to_df.input)
    new_column_names = list(rel.to_df.column_names)
    if len(new_column_names) != len(input_df.columns):
        # TODO: Check error type here
        raise ValueError(
            "Number of column names must match number of columns in DataFrame"
        )
    snowpark_new_column_names = make_column_names_snowpark_compatible(new_column_names)
    result = input_df.toDF(*snowpark_new_column_names)
    return build_column_map(
        result, new_column_names, snowpark_column_names=snowpark_new_column_names
    )


def map_to_schema(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Transform the column names of the input DataFrame.
    """
    input_df: snowpark.DataFrame = map_relation(rel.to_schema.input)
    new_schema = rel.to_schema.schema
    snowpark_schema = proto_to_snowpark_type(new_schema)
    snowpark_column_names = [
        input_df._column_map.get_snowpark_column_name_from_spark_column_name(field.name)
        for field in rel.to_schema.schema.struct.fields
    ]
    result = input_df.select(
        *[
            snowpark_fn.cast(col_name, snowpark_field.datatype).as_(col_name)
            for col_name, snowpark_field in zip(
                snowpark_column_names, snowpark_schema.fields
            )
        ]
    )
    return build_column_map(
        result,
        [field.name for field in rel.to_schema.schema.struct.fields],
        snowpark_column_names=snowpark_column_names,
    )


def map_with_columns_renamed(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Rename columns in a DataFrame.
    """
    input_df: snowpark.DataFrame = map_relation(rel.with_columns_renamed.input)
    rename_columns_map = dict(rel.with_columns_renamed.rename_columns_map)
    # Creating a new df to avoid updating the state of cached dataframe.
    new_df = input_df.select("*")
    return build_column_map(
        new_df,
        [
            rename_columns_map.get(c, c)
            for c in input_df._column_map.get_spark_columns()
        ],
        snowpark_column_names=input_df._column_map.get_snowpark_columns(),
    )


def map_with_columns(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Add columns to a DataFrame.
    """
    input_df: snowpark.DataFrame = map_relation(rel.with_columns.input)
    with_columns = [
        map_alias(alias, input_df._column_map, ExpressionTyper(input_df))
        for alias in rel.with_columns.aliases
    ]
    # TODO: This list needs to contain all unique column names, but the code below doesn't
    # guarantee that.
    with_columns_names = []
    with_columns_exprs = []
    with_column_offset = len(input_df._column_map.get_spark_columns())
    new_spark_names = []
    seen_columns = set()
    for name, expr in with_columns:
        name_normalized = input_df._column_map._normalized_spark_name(name)
        if name_normalized in seen_columns:
            raise ValueError(
                f"[COLUMN_ALREADY_EXISTS] The column `{name}` already exists."
            )
        seen_columns.add(name_normalized)
        # If the column name is already in the DataFrame, we replace it, so we use the
        # mapping to get the correct column name.
        if input_df._column_map.has_spark_column(name):
            all_instances_of_spark_column_name = (
                input_df._column_map.get_snowpark_column_names_from_spark_column_names(
                    [name]
                )
            )
            if len(all_instances_of_spark_column_name) == 0:
                raise KeyError(f"Spark column name {name} does not exist")
            with_columns_names.extend(all_instances_of_spark_column_name)
            with_columns_exprs.extend(
                [expr.col] * len(all_instances_of_spark_column_name)
            )
            new_spark_names.extend([name] * len(all_instances_of_spark_column_name))
        else:
            with_columns_names.append(
                make_column_names_snowpark_compatible([name], with_column_offset)[0]
            )
            with_column_offset += 1
            with_columns_exprs.append(expr.col)
            new_spark_names.append(name)

    new_spark_columns, new_snowpark_columns = input_df._column_map.with_columns(
        new_spark_names, with_columns_names
    )

    # dedup the change in columns at snowpark name level, this is required by the with columns functions
    with_columns_names_deduped = []
    with_columns_exprs_deduped = []
    seen = set()
    for i, col_name in enumerate(with_columns_names):
        if col_name not in seen:
            seen.add(col_name)
            with_columns_names_deduped.append(col_name)
            with_columns_exprs_deduped.append(with_columns_exprs[i])
    result = input_df.with_columns(
        with_columns_names_deduped, with_columns_exprs_deduped
    ).select(*new_snowpark_columns)

    column_metadata = input_df._column_map.column_metadata or {}
    for alias in rel.with_columns.aliases:
        # this logic is triggered for df.withMetadata function.
        if alias.HasField("metadata") and len(alias.metadata.strip()) > 0:
            # spark sends list of alias names with only one element in the list with alias name.
            column_metadata[alias.name[0]] = json.loads(alias.metadata)
    return build_column_map(
        result,
        new_spark_columns,
        snowpark_column_names=new_snowpark_columns,
        column_metadata=column_metadata,
    )


def map_unpivot(rel: relation_proto.Relation) -> snowpark.DataFrame:
    # Spark API:    df.unpivot([id_columns], [unpivot_columns], var_column, val_column)
    # Snowpark API: df.unpivot(val_column, var_column, [unpivot_columns])
    if rel.unpivot.HasField("values") and len(rel.unpivot.values.values) == 0:
        raise SparkException.unpivot_requires_value_columns()

    def get_lease_common_ancestor_classes(types: list[snowpark.types.DataType]) -> set:
        mro_lists = [set(type.__class__.mro()) for type in types]
        common_ancestors = set.intersection(*mro_lists)
        common_ancestors.discard(object)
        common_ancestors.discard(snowpark.types._AtomicType)
        common_ancestors.discard(snowpark.types.DataType)
        return common_ancestors

    def should_cast_type(df: snowpark.DataFrame, col_names: list[str]) -> bool:
        # TODO: Follow the Spark type casting semantics and cast input columns to their common parent type.
        # Snowpark unpivot cannot handle columns with different types. For example, GS throws error
        # CONFLICTING_UNPIVOT_COLUMN_TYPES if unpivot_col_names contains an int column and a double column.
        # But Spark unpivot is able to handle such cases.
        # This function only handles the case where the column list contains more than one numerical types.

        type_column_list = [
            (
                f.datatype,
                df._column_map.get_spark_column_name_from_snowpark_column_name(
                    snowpark_functions_col(f.name, df._column_map).get_name()
                ),
            )
            for f in df.schema.fields
            if snowpark_functions_col(f.name, df._column_map).get_name() in col_names
        ]
        type_iter, _ = zip(*type_column_list)
        type_list = list(type_iter)
        is_same_type = len(set(type_list)) <= 1
        contains_numeric_type = any(
            [isinstance(t, snowpark_types._NumericType) for t in type_list]
        )
        if not get_lease_common_ancestor_classes(type_list):
            # TODO: match exactly how spark shows mismatched columns
            raise SparkException.unpivot_value_data_type_mismatch(
                ", ".join(
                    [
                        f"{dtype} {column_name}"
                        for (dtype, column_name) in type_column_list
                    ]
                )
            )
        return not is_same_type and contains_numeric_type

    def get_column_names(
        relation: relation_proto.Relation, df: snowpark.DataFrame
    ) -> tuple[list[str], list[str], list[str], list[str]]:
        """This function takes the input Snowpark dataframe and the input relation,
        and returns the Snowpark and Spark column names.

        Returns:
            spark_columns: contains the Spark column names in the result
            id_col_names: contains the Snowpark id column names
            unpivot_col_names: contains the Snowpark unpivot column names
            unpivot_spark_names: contains the Spark unpivot column names
        """
        spark_columns = []
        id_col_names = []
        typer = ExpressionTyper(input_df)
        for id_col in relation.unpivot.ids:
            spark_name, typed_column = map_single_column_expression(
                id_col, df._column_map, typer
            )
            id_col_names.append(typed_column.col.get_name())
            spark_columns.append(spark_name)

        # unpivot_col_names contains the Snowpark column names sent to GS.
        # unpivot_spark_name contains the Spark column names.
        unpivot_col_names = []
        unpivot_spark_names = []
        for v in relation.unpivot.values.values:
            spark_name, typed_column = map_single_column_expression(
                v, df._column_map, typer
            )
            unpivot_col_names.append(typed_column.col.get_name())
            unpivot_spark_names.append(spark_name)

        if not rel.unpivot.HasField("values"):
            # When `values` is `None`, all non-id columns will be unpivoted.
            for snowpark_name, spark_name in zip(
                df._column_map.get_snowpark_columns(),
                df._column_map.get_spark_columns(),
            ):
                if (
                    snowpark_functions_col(snowpark_name, df._column_map).get_name()
                    not in id_col_names
                ):
                    unpivot_col_names.append(
                        snowpark_functions_col(snowpark_name, df._column_map).get_name()
                    )
                    unpivot_spark_names.append(spark_name)

        spark_columns.append(relation.unpivot.variable_column_name)
        spark_columns.append(relation.unpivot.value_column_name)
        return spark_columns, id_col_names, unpivot_col_names, unpivot_spark_names

    input_df: snowpark.DataFrame = map_relation(rel.unpivot.input)
    (
        spark_columns,
        id_col_names,
        unpivot_col_names,
        unpivot_spark_names,
    ) = get_column_names(rel, input_df)
    (
        snowpark_value_column_name,
        snowpark_variable_column_name,
    ) = make_column_names_snowpark_compatible(
        [rel.unpivot.value_column_name, rel.unpivot.variable_column_name],
        len(spark_columns),
    )
    cast_type = should_cast_type(input_df, unpivot_col_names)

    # column_project is the project that happens before unpivot. This projection is used to
    # 1. preserve the id column, by projecting the id column to a random name.
    # 2. perform type casting of the unpivot columns.
    # column_reverse_project is the project that happens after unpivot. This project is used to
    # 1. project the id column from the random name back to the original name.
    # 2. perform case when postprocessing to fix the column names in the var column.
    column_project = []
    column_reverse_project = []
    for c in input_df._column_map.get_snowpark_columns():
        c_name = snowpark_functions_col(c, input_df._column_map).get_name()
        if c_name in unpivot_col_names:
            if cast_type:
                column_project.append(
                    snowpark_functions_col(c, input_df._column_map)
                    .cast("DOUBLE")
                    .alias(c_name)
                )
            else:
                column_project.append(snowpark_functions_col(c, input_df._column_map))
        if c_name in id_col_names:
            id_col_alias = "SES" + generate_random_alphanumeric().upper()
            column_project.append(
                snowpark_functions_col(c, input_df._column_map).alias(id_col_alias)
            )
            column_reverse_project.append(
                snowpark_functions_col(id_col_alias, input_df._column_map).alias(c)
            )

    # Without the case when postprocessing, the result Spark dataframe is:
    # +---+------------+------+
    # |id | var        | val  |
    # +---+------------+------+
    # | 1 | INTSES1    | 10.0 |
    # | 1 | DOUBLESES2 | 1.0  |
    # +---+------------+------+
    # which has wrong column names in the var column. The correct column names should be:
    # +---+--------+------+
    # |id | var    | val  |
    # +---+--------+------+
    # | 1 | int    | 10.0 |
    # | 1 | double | 1.0  |
    # +---+--------+------+
    # We need a case when postprocessing to convert the value in the var column.
    post_process_variable_column = None
    for snowpark_name, spark_name in zip(unpivot_col_names, unpivot_spark_names):
        if post_process_variable_column is None:
            post_process_variable_column = snowpark_fn.when(
                snowpark_functions_col(
                    snowpark_variable_column_name, input_df._column_map
                )
                == unquote_if_quoted(snowpark_name),
                spark_name,
            )
        else:
            post_process_variable_column = post_process_variable_column.when(
                snowpark_functions_col(
                    snowpark_variable_column_name, input_df._column_map
                )
                == unquote_if_quoted(snowpark_name),
                spark_name,
            )

    column_reverse_project.append(post_process_variable_column)
    column_reverse_project.append(
        snowpark_functions_col(snowpark_value_column_name, input_df._column_map)
    )

    # TODO: need to be able to set INCLUDE NULLS in snowpark.unpivot. (SNOW-1780693)
    result = (
        input_df.select(*column_project)
        .unpivot(
            snowpark_value_column_name,
            snowpark_variable_column_name,
            unpivot_col_names,
        )
        .select(*column_reverse_project)
    )
    return build_column_map(result, spark_columns, result.columns)
