from collections.abc import Callable
from functools import cached_property

from snowflake import snowpark

from snowflake.snowpark.column import Column

_EMPTY_COLUMN = Column("")


class TypedColumn:
    def __init__(
        self,
        col: Column,
        type_resolver: Callable[[], list[snowpark.types.DataType] | None],
    ) -> None:
        self.col = col
        self._type_resolver = type_resolver

    def __iter__(self):
        return iter((self.col, self._type_resolver))

    @property
    def typ(self) -> snowpark.types.DataType | None:
        assert (
            len(self.types) == 1
        ), f"Expected exactly single column expression, got {self.col}"
        return self.types[0]

    @cached_property
    def types(self) -> list[snowpark.types.DataType] | None:
        return self._type_resolver()

    @classmethod
    def empty(cls):
        return TypedColumn(_EMPTY_COLUMN, lambda: None)

    def alias(self, alias_name: str):
        return TypedColumn(self.col.alias(alias_name), self._type_resolver)

    def is_empty(self) -> bool:
        return (
            isinstance(self.col, Column)
            and self.col._expression == _EMPTY_COLUMN._expression
        )
