import re
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass

from snowflake import snowpark

from snowflake.snowpark._internal.analyzer.analyzer_utils import unquote_if_quoted
from snowflake.snowpark._internal.utils import quote_name
from snowpark_connect.config import global_config

ALREADY_QUOTED = re.compile('^(".+")$', re.DOTALL)


def build_column_map(
    result_df: snowpark.DataFrame,
    spark_column_names: list[str],
    snowpark_column_names: list[str],
    column_metadata: dict | None = None,
) -> snowpark.DataFrame:
    """
    Build a mapping from the DataFrame's column names to the Spark column names.

    This is used to track the original column names and handle column naming differences
    between Spark and Snowpark.

    The elements in result_df.columns and the elements in spark_column_names must be a one-to-one mapping.

    Args:
        result_df (snowpark.DataFrame): The DataFrame to map.
        spark_column_names (list[str]): The Spark column names.
    """
    assert len(snowpark_column_names) == len(
        spark_column_names
    ), "Number of Spark column names must match number of columns in DataFrame"
    result_df._column_map = ColumnNameMap(
        spark_column_names, snowpark_column_names, column_metadata=column_metadata
    )
    return result_df


def make_column_names_snowpark_compatible(
    names: list[str], offset: int = 0
) -> list[str]:
    """
    Make a list of column names Snowpark compatible. The naming convention for the generated snowpark column names is
    to append a column index at the end of the column name. The column index suffix guarantees the uniqueness of
    the generated Snowpark column names. Snowpark column names cannot contain SQL keywords.

    For example: Spark columns [a, b, c] will be converted to ["a-0", "b-1", "c-2"].

    The offset argument is used to offset the column index. It should be set to non-zero when generating new column
    names for an existing dataframe to avoid potential naming conflict.

    For example: Suppose we have a dataframe `df` that contains column a and b.
        Now we need to append a few more columns to the dataframe, which is very common in unpivot and withColumn.
        `df.unpivot(['a', 'b'], None, 'a', 'b')` will result in this Spark dataframe:
        +---+---+---+---+
        |  a|  b|  a|  b|
        +---+---+---+---+
        ...
        +---+---+---+---+
        To avoid duplicated column names, the corresponding Snowpark dataframe should be:
        +----+----+----+----+
        | a-0| b-1| a-2| b-3|
        +----+----+----+----+
        ...
        +----+----+----+----+
        In this case the function call should be `make_column_names_snowpark_compatible(['a', 'b'], 2)`,
        to avoid naming conflicts between the new columns and the old columns.
    """
    return [
        # Use `-` in the name to force df.column to return double-quoted names
        quote_name(unquote_if_quoted(name) + "-" + str(i + offset))
        for i, name in enumerate(names)
    ]


class ColumnNameMap:
    def __init__(
        self,
        spark_column_names: list[str],
        snowpark_column_names: list[str | dict],
        is_case_sensitive: Callable[
            [], bool
        ] = lambda: global_config.spark_sql_caseSensitive,
        snowpark_schema: snowpark.types.StructType | None = None,
        column_metadata: dict | None = None,
    ) -> None:
        """
        spark_column_names: Original spark column names
        snowpark_column_names: Snowpark column names
        snowpark_schema: Snowpark schema
        column_metadata: This field is used to store metadata related to columns. Since Snowpark’s Struct type does not support metadata,
        we use this attribute to store any metadata related to the columns.
        The key is the original Spark column name, and the value is the metadata.
        example: Dict('age', {'foo': 'bar'})
        """
        self.columns = []
        self.spark_to_col = {}
        self.uppercase_spark_to_col = {}
        self.snowpark_to_col = {}
        self.is_case_sensitive = is_case_sensitive
        self.column_metadata = column_metadata

        for i in range(len(spark_column_names)):
            c = ColumnNames(
                spark_name=spark_column_names[i],
                snowpark_name=snowpark_column_names[i],
            )
            self.columns.append(c)
            # the same spark name can map to multiple snowpark names
            if c.spark_name in self.spark_to_col:
                self.spark_to_col[c.spark_name].append(c)
                self.uppercase_spark_to_col[c.spark_name.upper()].append(c)
            else:
                self.spark_to_col[c.spark_name] = [c]
                self.uppercase_spark_to_col[c.spark_name.upper()] = [c]

            # the same snowpark name can map to multiple spark column
            # e.g. df.select(date_format('dt', 'yyy'), date_format('dt', 'yyyy')) ->
            # [
            #   to_char( TRY_CAST (to_char("dt-0") AS TIMESTAMP), 'YYYY'),
            #   to_char( TRY_CAST (to_char("dt-0") AS TIMESTAMP), 'YYYY'),
            # ]
            if c.snowpark_name in self.snowpark_to_col:
                self.snowpark_to_col[c.snowpark_name].append(c)
            else:
                self.snowpark_to_col[c.snowpark_name] = [c]

    def get_snowpark_column_names_from_spark_column_names(
        self, spark_column_names: list[str], return_first: bool = False
    ) -> list[str]:
        assert isinstance(spark_column_names, list)
        if isinstance(spark_column_names, str):
            spark_column_names = [spark_column_names]
        snowpark_column_names = []

        for name in spark_column_names:
            # Handle nested column names first
            nested = self.get_renamed_nested_column_name(name)
            if nested is not None:
                snowpark_column_names.append(nested)
                continue

            if not global_config.spark_sql_caseSensitive:
                name = name.upper()
                mapping = self.uppercase_spark_to_col
            else:
                mapping = self.spark_to_col
            if name not in mapping:
                # column may still be prefixed with df alias, but we don't know that here
                continue

            if return_first:
                snowpark_column_names.append(mapping[name][0].snowpark_name)
            else:
                snowpark_column_names.extend([c.snowpark_name for c in mapping[name]])

        return snowpark_column_names

    def get_snowpark_column_name_from_spark_column_name(
        self,
        spark_column_name: str,
        *,
        allow_non_exists: bool = False,
        return_first: bool = False,
    ) -> str | None:
        assert isinstance(spark_column_name, str)
        snowpark_names = self.get_snowpark_column_names_from_spark_column_names(
            [spark_column_name], return_first
        )
        snowpark_names_len = len(snowpark_names)
        if snowpark_names_len > 1:
            raise KeyError(
                f"Ambiguous spark column name {spark_column_name}, potential snowpark column names {snowpark_names}"
            )
        elif snowpark_names_len == 0:
            if allow_non_exists:
                return None
            else:
                raise KeyError(f"Spark column name {spark_column_name} does not exist")
        return snowpark_names[0]

    def get_spark_column_names_from_snowpark_column_names(
        self,
        snowpark_column_names: list[str],
    ) -> list[str]:
        assert isinstance(snowpark_column_names, list)
        spark_column_names = []
        for n in snowpark_column_names:
            if n not in self.snowpark_to_col:
                continue

            spark_column_names.extend([c.spark_name for c in self.snowpark_to_col[n]])
        return spark_column_names

    def get_spark_column_name_from_snowpark_column_name(
        self, snowpark_column_name: str
    ) -> str:
        assert isinstance(snowpark_column_name, str)

        spark_names = self.get_spark_column_names_from_snowpark_column_names(
            [snowpark_column_name]
        )
        spark_names_len = len(spark_names)
        if spark_names_len > 1:
            raise KeyError(
                f"Ambiguous snowpark column name {snowpark_column_name}, potential spark column names {spark_names}"
            )
        elif spark_names_len == 0:
            raise KeyError(
                f"Snowpark column name {snowpark_column_name} does not exist"
            )
        return spark_names[0]

    def get_spark_column_name(self, idx: int) -> str:
        return self.columns[idx].spark_name

    def get_spark_columns(self) -> list[str]:
        return [c.spark_name for c in self.columns]

    def get_snowpark_columns(self) -> list[str]:
        return [c.snowpark_name for c in self.columns]

    def get_snowpark_columns_after_drop(self, cols_to_drop: list[str]) -> list[str]:
        return [
            c
            for c in self.get_snowpark_columns()
            if self._quote_if_unquoted(c) not in cols_to_drop
        ]

    @staticmethod
    def _quote_if_unquoted(s: str) -> str:
        if not ALREADY_QUOTED.match(s):
            s = s.replace('"', '\\"')
            return f'"{s}"'
        return s

    def get_renamed_nested_column_name(self, name) -> str | None:
        # Handle nested column names
        # TODO: Support names like "col@"."col@"
        if not ALREADY_QUOTED.match(name) and "." in name:
            name_parts = name.split(".")
            replaced_first_part = (
                self.get_snowpark_column_names_from_spark_column_names([name_parts[0]])
            )
            if len(replaced_first_part) == 1:
                name_parts[0] = replaced_first_part[0]
                return ".".join(name_parts)

        return None

    def has_spark_column(self, spark_column_name: str) -> bool:
        if self.is_case_sensitive():
            return spark_column_name in self.spark_to_col
        else:
            return spark_column_name.upper() in self.uppercase_spark_to_col

    def snowpark_to_spark_map(self) -> dict[str, str]:
        return {c.snowpark_name: c.spark_name for c in self.columns}

    def spark_to_snowpark_for_pattern(self, pattern: str) -> list[tuple[str, str]]:
        pattern_regex = re.compile(
            pattern, 0 if self.is_case_sensitive() else re.IGNORECASE
        )
        return [
            (c.spark_name, c.snowpark_name)
            for c in self.columns
            if pattern_regex.fullmatch(c.spark_name)
        ]

    def with_columns(
        self, new_spark_columns: list[str], new_snowpark_columns: list[str]
    ) -> (list[str], list[str]):
        """
        Returns an ordered list of spark and snowpark column names after adding the new columns through a withColumns call.
        All replaced columns retain their ordering in the dataframe. The new columns are added to the end of the list.
        """

        assert len(new_spark_columns) == len(new_snowpark_columns)

        spark_name_to_snowpark_name_map: dict[str, deque[int]] = {}

        for i, c in enumerate(new_spark_columns):
            column_name = self._normalized_spark_name(c)
            if column_name in spark_name_to_snowpark_name_map:
                spark_name_to_snowpark_name_map[column_name].append(i)
            else:
                spark_name_to_snowpark_name_map[column_name] = deque([i])

        spark_columns = []
        snowpark_columns = []
        removed_index: set[int] = set()

        for c in self.columns:
            column_name = self._normalized_spark_name(c.spark_name)
            if column_name in spark_name_to_snowpark_name_map:
                index = spark_name_to_snowpark_name_map[column_name].popleft()
                removed_index.add(index)
                spark_columns.append(new_spark_columns[index])
                snowpark_columns.append(new_snowpark_columns[index])
            else:
                spark_columns.append(c.spark_name)
                snowpark_columns.append(c.snowpark_name)

        for i, _ in enumerate(new_spark_columns):
            if i not in removed_index:
                spark_columns.append(new_spark_columns[i])
                snowpark_columns.append(new_snowpark_columns[i])

        return spark_columns, snowpark_columns

    def _normalized_spark_name(self, spark_name: str) -> str:
        if self.is_case_sensitive():
            return spark_name
        else:
            return spark_name.upper()


@dataclass(frozen=True)
class ColumnNames:
    spark_name: str
    snowpark_name: str


class JoinColumnNameMap(ColumnNameMap):
    def __init__(
        self,
        left_input: snowpark.DataFrame,
        right_input: snowpark.DataFrame,
        snowpark_schema: snowpark.types.StructType | None = None,
    ) -> None:
        self.left_column_mapping: ColumnNameMap = left_input._column_map
        self.right_column_mapping: ColumnNameMap = right_input._column_map
        self.snowpark_schema = snowpark_schema

    def get_snowpark_column_name_from_spark_column_name(
        self,
        spark_column_name: str,
        *,
        allow_non_exists: bool = False,
        return_first: bool = False,
    ) -> str | None:
        snowpark_column_name_in_left = (
            self.left_column_mapping.get_snowpark_column_name_from_spark_column_name(
                spark_column_name, allow_non_exists=allow_non_exists
            )
        )
        snowpark_column_name_in_right = (
            self.right_column_mapping.get_snowpark_column_name_from_spark_column_name(
                spark_column_name, allow_non_exists=allow_non_exists
            )
        )

        if (snowpark_column_name_in_right is not None) and (
            snowpark_column_name_in_left is not None
        ):
            raise KeyError(f"Ambiguous column name {spark_column_name}")

        return (
            snowpark_column_name_in_right
            if snowpark_column_name_in_left is None
            else snowpark_column_name_in_left
        )

    def get_snowpark_column_names_from_spark_column_names(
        self, spark_column_names: list[str], return_first: bool = False
    ) -> list[str]:
        raise NotImplementedError("Method not implemented!")

    def get_spark_column_names_from_snowpark_column_names(
        self,
        snowpark_column_names: list[str],
    ) -> list[str]:
        raise NotImplementedError("Method not implemented!")

    def get_spark_column_name_from_snowpark_column_name(
        self, snowpark_column_name: str
    ) -> str:
        raise NotImplementedError("Method not implemented!")

    def get_spark_columns(self) -> list[str]:
        raise NotImplementedError("Method not implemented!")

    def get_snowpark_columns(self) -> list[str]:
        raise NotImplementedError("Method not implemented!")

    def get_snowpark_columns_after_drop(self, cols_to_drop: list[str]) -> list[str]:
        raise NotImplementedError("Method not implemented!")

    def get_renamed_nested_column_name(self, name) -> str | None:
        raise NotImplementedError("Method not implemented!")

    def has_spark_column(self, spark_column_name: str) -> bool:
        raise NotImplementedError("Method not implemented!")

    def snowpark_to_spark_map(self) -> dict[str, str]:
        raise NotImplementedError("Method not implemented!")

    def spark_to_snowpark_for_pattern(self, pattern: str) -> list[tuple[str, str]]:
        raise NotImplementedError("Method not implemented!")

    def with_columns(
        self, new_spark_columns: list[str], new_snowpark_columns: list[str]
    ) -> (list[str], list[str]):
        raise NotImplementedError("Method not implemented!")
