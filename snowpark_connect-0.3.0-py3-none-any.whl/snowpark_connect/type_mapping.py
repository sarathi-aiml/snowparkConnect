import json
import re

import pyarrow as pa
import pyarrow.lib
import pyspark.sql.connect.proto.types_pb2 as types_proto
import pyspark.sql.types
from pyspark.errors.exceptions.base import AnalysisException, IllegalArgumentException
from pyspark.sql.connect.proto import expressions_pb2
from snowflake import snowpark

from snowflake.snowpark._internal.type_utils import type_string_to_type_object
from snowpark_connect.column_name_handler import ColumnNameMap
from snowpark_connect.constants import (
    COLUMN_METADATA_COLLISION_KEY,
    STRUCTURED_TYPES_ENABLED,
)
from snowpark_connect.expression.literal import get_literal_field_and_name
from snowpark_connect.utils.telemetry import SnowparkConnectNotImplementedError

SNOWPARK_TYPE_NAME_TO_PYSPARK_TYPE_NAME = {
    snowpark.types.ArrayType.__name__: pyspark.sql.types.ArrayType.typeName(),
    snowpark.types.BinaryType.__name__: pyspark.sql.types.BinaryType.typeName(),
    snowpark.types.BooleanType.__name__: pyspark.sql.types.BooleanType.typeName(),
    snowpark.types.DateType.__name__: pyspark.sql.types.DateType.typeName(),
    snowpark.types.DecimalType.__name__: pyspark.sql.types.DecimalType.typeName(),
    snowpark.types.DoubleType.__name__: pyspark.sql.types.DoubleType.typeName(),
    snowpark.types.FloatType.__name__: pyspark.sql.types.FloatType.typeName(),
    snowpark.types.IntegerType.__name__: pyspark.sql.types.IntegerType.typeName(),
    snowpark.types.LongType.__name__: pyspark.sql.types.LongType.typeName(),
    snowpark.types.MapType.__name__: pyspark.sql.types.MapType.typeName(),
    snowpark.types.NullType.__name__: pyspark.sql.types.NullType.typeName(),
    snowpark.types.ShortType.__name__: pyspark.sql.types.ShortType.typeName(),
    snowpark.types.StringType.__name__: pyspark.sql.types.StringType.typeName(),
    snowpark.types.StructType.__name__: pyspark.sql.types.StructType.typeName(),
    snowpark.types.TimestampType.__name__: pyspark.sql.types.TimestampType.typeName(),
}


def snowpark_to_proto_type(
    data_type: snowpark.types.DataType,
    column_name_map: ColumnNameMap,
    df: snowpark.DataFrame = None,  # remove this param after SNOW-1857090
    depth: int = 0,
) -> dict[str, types_proto.DataType]:
    """
    Map a Snowpark data type to a Proto data type.
    """
    match type(data_type):
        case snowpark.types.ArrayType:
            # in the case of semi-structured array, the element_type is None.
            # Before we finish structured type casting rewriting, we fall back to StringType.
            return {
                "array": types_proto.DataType.Array(
                    element_type=types_proto.DataType(
                        **dict(
                            snowpark_to_proto_type(
                                data_type.element_type
                                if data_type.element_type
                                else snowpark.types.StringType(),
                                column_name_map,
                                df,
                                depth + 1,
                            )
                        )
                    )
                )
            }
        case snowpark.types.BinaryType:
            return {"binary": types_proto.DataType.Binary()}
        case snowpark.types.BooleanType:
            return {"boolean": types_proto.DataType.Boolean()}
        case snowpark.types.DateType:
            return {"date": types_proto.DataType.Date()}
        case snowpark.types.DecimalType:
            return {
                "decimal": types_proto.DataType.Decimal(
                    precision=data_type.precision, scale=data_type.scale
                )
            }
        case snowpark.types.DoubleType:
            return {"double": types_proto.DataType.Double()}
        case snowpark.types.FloatType:
            return {"float": types_proto.DataType.Float()}
        case snowpark.types.IntegerType:
            return {"integer": types_proto.DataType.Integer()}
        case snowpark.types.LongType:
            return {"long": types_proto.DataType.Long()}
        case snowpark.types.MapType:
            if not data_type.structured:
                return {"string": types_proto.DataType.String()}
            # In the case of semi-structured Map, the key_type and data_type are None.
            # Before we finish structured type casting rewriting, we fall back to StringType.
            return {
                "map": types_proto.DataType.Map(
                    key_type=types_proto.DataType(
                        **snowpark_to_proto_type(
                            data_type.key_type
                            if data_type.key_type
                            else snowpark.types.StringType(),
                            column_name_map,
                            df,
                            depth + 1,
                        )
                    ),
                    value_type=types_proto.DataType(
                        **snowpark_to_proto_type(
                            data_type.value_type
                            if data_type.value_type
                            else snowpark.types.StringType(),
                            column_name_map,
                            df,
                            depth + 1,
                        )
                    ),
                )
            }
        case snowpark.types.NullType:
            return {"null": types_proto.DataType.NULL()}
        case snowpark.types.ShortType:
            return {"short": types_proto.DataType.Short()}
        case snowpark.types.StringType:
            return {"string": types_proto.DataType.String()}
        case snowpark.types.StructType:
            if not data_type.structured:
                return {"string": types_proto.DataType.String()}

            def map_field(index, field):
                # For attributes inside struct type (depth > 0), they don't get renamed as normal dataframe column names. Thus no need to do the conversion from snowpark column name to spark column name.
                spark_name = (
                    column_name_map.get_spark_column_name(index)
                    if depth == 0
                    else field.name
                )
                column_metadata_str = None
                if column_name_map.column_metadata:
                    metadata = column_name_map.column_metadata.get(spark_name, None)
                    if metadata is None and df and field.name in df.columns:
                        try:
                            # check for collision using expr_id
                            expr_id = df[field.name]._expression.expr_id
                            new_key = COLUMN_METADATA_COLLISION_KEY.format(
                                expr_id=expr_id, key=spark_name
                            )
                            metadata = column_name_map.column_metadata.get(
                                new_key, None
                            )
                        except snowpark.exceptions.SnowparkColumnException:
                            # TODO remove try/catch after SNOW-1857090
                            pass
                    if metadata is not None:
                        column_metadata_str = json.dumps(metadata)

                return types_proto.DataType.StructField(
                    name=spark_name,
                    data_type=types_proto.DataType(
                        **snowpark_to_proto_type(
                            field.datatype, column_name_map, df, depth + 1
                        )
                    ),
                    nullable=field.nullable,
                    metadata=column_metadata_str,
                )

            fields = [map_field(i, field) for i, field in enumerate(data_type.fields)]

            return {"struct": types_proto.DataType.Struct(fields=fields)}
        case snowpark.types.TimestampType:
            match data_type.tz:
                case snowpark.types.TimestampTimeZone.NTZ:
                    return {"timestamp_ntz": types_proto.DataType.TimestampNTZ()}
                case _:
                    return {"timestamp": types_proto.DataType.Timestamp()}
        case snowpark.types.VariantType:
            # For now we are returning a string type for variant types.
            return {"string": types_proto.DataType.String()}
        case _:
            raise SnowparkConnectNotImplementedError(
                f"Unsupported snowpark data type: {data_type}"
            )


def proto_to_snowpark_type(
    data_type: types_proto.DataType,
) -> snowpark.types.DataType:
    """
    Map a Proto data type to a Snowpark data type.
    """
    match data_type.WhichOneof("kind"):
        case "array":
            return snowpark.types.ArrayType(
                proto_to_snowpark_type(data_type.array.element_type),
                structured=STRUCTURED_TYPES_ENABLED,
            )
        case "map":
            # TODO: When Snowpark MapType supports nullable, we can get it from proto by `data_type.map.value_contains_null`. The property is ignored now.
            return snowpark.types.MapType(
                key_type=proto_to_snowpark_type(data_type.map.key_type),
                value_type=proto_to_snowpark_type(data_type.map.value_type),
                structured=STRUCTURED_TYPES_ENABLED,
            )
        case "struct":
            return snowpark.types.StructType(
                [
                    snowpark.types.StructField(
                        # NOTE: The column names are not mapped to the Spark column names here.
                        field.name,
                        proto_to_snowpark_type(field.data_type),
                        field.nullable,
                    )
                    for field in data_type.struct.fields
                ],
                structured=STRUCTURED_TYPES_ENABLED,
            )
        case _:
            return map_simple_types(data_type.WhichOneof("kind"))


def map_snowpark_types_to_pyarrow_types(
    snowpark_type: snowpark.types.DataType,
    pa_type: pa.DataType,
    rename_struct_columns: bool = False,
) -> pa.lib.DataType:
    """
    Map a Snowpark data type to a pyarrow data type.
    """
    assert pa_type is not None, "arrow type can't be None"
    match type(snowpark_type):
        case snowpark.types.ArrayType:
            if (
                not snowpark_type.structured
                or snowpark_type.element_type is None
                or pa_type == pa.string()
            ):
                # in the case of unstructured & semi-structured types, e.g. semi-structured array's element_type is None.
                # Before structured type is fully supported, we fall back to string type.
                return pa.string()
            if pa.types.is_list(pa_type):
                return pa.list_(
                    map_snowpark_types_to_pyarrow_types(
                        snowpark_type.element_type, pa_type.value_type
                    )
                )
            else:
                raise AnalysisException(
                    f"Unsupported arrow type {pa_type} for snowpark ArrayType."
                )
        case snowpark.types.BinaryType:
            return pa.binary()
        case snowpark.types.BooleanType:
            return pa.bool_()
        case snowpark.types.DateType:
            return pa.date32()
        case snowpark.types.DecimalType:
            return pa.decimal128(snowpark_type.precision, snowpark_type.scale)
        case snowpark.types.DoubleType:
            return pa.float64()
        case snowpark.types.FloatType:
            return pa.float32()
        case snowpark.types.IntegerType:
            return pa.int32()
        case snowpark.types.LongType:
            return pa.int64()
        case snowpark.types.MapType:
            if not snowpark_type.structured:
                # semi-structured value
                return pa.string()
            if pa.types.is_map(pa_type):
                return pa.map_(
                    key_type=map_snowpark_types_to_pyarrow_types(
                        snowpark_type.key_type, pa_type.key_type
                    ),
                    item_type=map_snowpark_types_to_pyarrow_types(
                        snowpark_type.value_type, pa_type.item_type
                    ),
                )
            else:
                raise AnalysisException(
                    f"Unsupported arrow type {pa_type} for snowpark MapType."
                )
        case snowpark.types.NullType:
            return pa.null()
        case snowpark.types.ShortType:
            return pa.int16()
        case snowpark.types.StringType:
            return pa.string()
        case snowpark.types.StructType:
            if not snowpark_type.structured:
                # semi-structured value
                return pa.string()
            if pa.types.is_struct(pa_type):
                return pa.struct(
                    fields=[
                        pa.field(
                            field.name if not rename_struct_columns else str(i),
                            map_snowpark_types_to_pyarrow_types(
                                field.datatype, pa_type[i].type
                            ),
                            nullable=field.nullable,
                        )
                        for i, field in enumerate(snowpark_type.fields)
                    ]
                )
            else:
                raise AnalysisException(
                    f"Unsupported arrow type {pa_type} for snowpark StructType."
                )
        case snowpark.types.TimestampType:
            return pa_type
        case snowpark.types.VariantType:
            return pa.string()
        case _:
            raise SnowparkConnectNotImplementedError(
                f"Unsupported snowpark data type: {snowpark_type}"
            )


def map_pyspark_types_to_snowpark_types(
    type_to_map: pyspark.sql.types.DataType,
) -> snowpark.types.DataType:
    """
    Map a PySpark data type to a Snowpark data type.

    This function is used to map the data types of columns in a PySpark DataFrame
    to the data types used in Snowpark. This is used in, for example, UDFs, where
    the client passes a serialized version of the client type (which will be a Pyspark
    type) and we need to map this to the Snowpark type.
    """
    if isinstance(type_to_map, pyspark.sql.types.ArrayType):
        return snowpark.types.ArrayType(
            map_pyspark_types_to_snowpark_types(type_to_map.elementType),
            structured=STRUCTURED_TYPES_ENABLED,
        )
    if isinstance(type_to_map, pyspark.sql.types.BinaryType):
        return snowpark.types.BinaryType()
    if isinstance(type_to_map, pyspark.sql.types.BooleanType):
        return snowpark.types.BooleanType()
    if isinstance(type_to_map, pyspark.sql.types.DateType):
        return snowpark.types.DateType()
    if isinstance(type_to_map, pyspark.sql.types.DecimalType):
        return snowpark.types.DecimalType()
    if isinstance(type_to_map, pyspark.sql.types.DoubleType):
        return snowpark.types.DoubleType()
    if isinstance(type_to_map, pyspark.sql.types.FloatType):
        return snowpark.types.FloatType()
    if isinstance(type_to_map, pyspark.sql.types.IntegerType):
        return snowpark.types.IntegerType()
    if isinstance(type_to_map, pyspark.sql.types.LongType):
        return snowpark.types.LongType()
    if isinstance(type_to_map, pyspark.sql.types.MapType):
        # TODO: When Snowpark MapType supports nullable, we can get it from pyspark by `type_to_map.valueContainsNull`. The property is ignored now.
        return snowpark.types.MapType(
            key_type=map_pyspark_types_to_snowpark_types(type_to_map.keyType),
            value_type=map_pyspark_types_to_snowpark_types(type_to_map.valueType),
            structured=STRUCTURED_TYPES_ENABLED,
        )
    if isinstance(type_to_map, pyspark.sql.types.NullType):
        return snowpark.types.NullType()
    if isinstance(type_to_map, pyspark.sql.types.ShortType):
        return snowpark.types.ShortType()
    if isinstance(type_to_map, pyspark.sql.types.StringType):
        return snowpark.types.StringType()
    if isinstance(type_to_map, pyspark.sql.types.StructType):
        return snowpark.types.StructType(
            [
                snowpark.types.StructField(
                    field.name,
                    map_pyspark_types_to_snowpark_types(field.dataType),
                    field.nullable,
                )
                for field in type_to_map.fields
            ],
            structured=STRUCTURED_TYPES_ENABLED,
        )
    if isinstance(type_to_map, pyspark.sql.types.TimestampType):
        return snowpark.types.TimestampType()
    raise SnowparkConnectNotImplementedError(
        f"Unsupported spark data type: {type_to_map}"
    )


def map_snowpark_to_pyspark_types(
    type_to_map: snowpark.types.DataType,
) -> pyspark.sql.types.DataType:
    """
    Map a Snowpark data type to a PySpark data type.

    This function is used to map the data types of columns in a Snowpark DataFrame
    to the data types used in PySpark. This is used in converting a Snowpark schema
    into the expected JSON schema for LocalRelation.
    """
    if isinstance(type_to_map, snowpark.types.ArrayType):
        return pyspark.sql.types.ArrayType(
            map_snowpark_to_pyspark_types(type_to_map.element_type)
        )
    if isinstance(type_to_map, snowpark.types.BinaryType):
        return pyspark.sql.types.BinaryType()
    if isinstance(type_to_map, snowpark.types.BooleanType):
        return pyspark.sql.types.BooleanType()
    if isinstance(type_to_map, snowpark.types.DateType):
        return pyspark.sql.types.DateType()
    if isinstance(type_to_map, snowpark.types.DecimalType):
        return pyspark.sql.types.DecimalType()
    if isinstance(type_to_map, snowpark.types.DoubleType):
        return pyspark.sql.types.DoubleType()
    if isinstance(type_to_map, snowpark.types.FloatType):
        return pyspark.sql.types.FloatType()
    if isinstance(type_to_map, snowpark.types.IntegerType):
        return pyspark.sql.types.IntegerType()
    if isinstance(type_to_map, snowpark.types.LongType):
        return pyspark.sql.types.LongType()
    if isinstance(type_to_map, snowpark.types.MapType):
        # TODO: when snowpark MapType supports "valueContainsNull", get it from there instead of default to true.
        return pyspark.sql.types.MapType(
            keyType=map_snowpark_to_pyspark_types(type_to_map.key_type),
            valueType=map_snowpark_to_pyspark_types(type_to_map.value_type),
            valueContainsNull=True,
        )
    if isinstance(type_to_map, snowpark.types.NullType):
        return pyspark.sql.types.NullType()
    if isinstance(type_to_map, snowpark.types.ShortType):
        return pyspark.sql.types.ShortType()
    if isinstance(type_to_map, snowpark.types.StringType):
        return pyspark.sql.types.StringType()
    if isinstance(type_to_map, snowpark.types.StructType):
        return pyspark.sql.types.StructType(
            [
                pyspark.sql.types.StructField(
                    field.name,
                    map_snowpark_to_pyspark_types(field.datatype),
                    field.nullable,
                )
                for field in type_to_map.fields
            ]
        )
    if isinstance(type_to_map, snowpark.types.TimestampType):
        return pyspark.sql.types.TimestampType()
    raise SnowparkConnectNotImplementedError(f"Unsupported data type: {type_to_map}")


def map_simple_types(simple_type: str) -> snowpark.types.DataType:
    """
    Map a simple type string to z Snowpark data type.
    """
    match simple_type.lower():
        case "null":
            return snowpark.types.NullType()
        case "binary":
            return snowpark.types.BinaryType()
        case "boolean":
            return snowpark.types.BooleanType()
        case "byte":
            return snowpark.types.ByteType()
        case "number":
            return snowpark.types.DoubleType()
        case "short":
            return snowpark.types.ShortType()
        case "integer" | "int":
            return snowpark.types.IntegerType()
        case "long":
            return snowpark.types.LongType()
        case "float":
            return snowpark.types.FloatType()
        case "double":
            return snowpark.types.DoubleType()
        case "decimal":
            return snowpark.types.DecimalType()
        case "string":
            return snowpark.types.StringType()
        case "char":
            return snowpark.types.StringType()
        case "var_char":
            return snowpark.types.StringType()
        case "date":
            return snowpark.types.DateType()
        case "timestamp":
            return snowpark.types.TimestampType(snowpark.types.TimestampTimeZone.LTZ)
        case "timestamp_ntz":
            return snowpark.types.TimestampType(snowpark.types.TimestampTimeZone.NTZ)
        case "day_time_interval":
            return snowpark.types.StringType()
        case _:
            if simple_type.startswith("decimal"):
                precision = int(simple_type.split("(")[1].split(",")[0])
                scale = int(simple_type.split(",")[1].split(")")[0])
                return snowpark.types.DecimalType(precision, scale)
            raise SnowparkConnectNotImplementedError(
                f"Unsupported simple type: {simple_type}"
            )


def map_json_schema_to_snowpark(schema: dict | str) -> snowpark.types.StructType:
    """
    Map a JSON schema to a Snowpark schema.

    Because of inconsistencies in how the schema is represented in the JSON,
    we need to handle both the case where the schema is a string and the case
    where it is a dictionary. We have a separate function to handle the string
    case, but it is necessary to handle both cases here because types can be nested
    json objects or strings.
    """
    if isinstance(schema, str):
        return map_simple_types(schema)
    match schema.get("type", None):
        case "struct":
            return snowpark.types.StructType(
                [
                    snowpark.types.StructField(
                        field["name"],
                        map_json_schema_to_snowpark(field["type"]),
                        field.get("nullable", True),
                    )
                    for field in schema["fields"]
                ],
                structured=STRUCTURED_TYPES_ENABLED,
            )
        case "array":
            return snowpark.types.ArrayType(
                map_json_schema_to_snowpark(schema["elementType"]),
                structured=STRUCTURED_TYPES_ENABLED,
            )
        case "map":
            # TODO: pyspark schema["valueContainsNull"] is ignored for now. Snowflake MAP supports this parameter,
            #  `MAP( <key_type> , <value_type> [ NOT NULL ] )`, while snowpark MapType hasn't supported it yet.
            return snowpark.types.MapType(
                key_type=map_json_schema_to_snowpark(schema["keyType"]),
                value_type=map_json_schema_to_snowpark(schema["valueType"]),
                structured=STRUCTURED_TYPES_ENABLED,
            )
        case _:
            return map_simple_types(schema["type"])


def _replace_complex_patterns(type_string):
    # Check if entire string matches struct pattern "struct<col1 int, col2 int, col3 int, col4 int>"
    struct_match = re.match(r"^struct<(.+)>$", type_string, re.IGNORECASE)
    if struct_match:
        return struct_match.group(1)
    # Replace 'struct<[^>]*>' with 'struct' and map<*> with map as we are only interested in column names.
    type_string = re.sub(r"struct<[^>]*>", "struct", type_string, flags=re.IGNORECASE)
    type_string = re.sub(r"map<[^>]*>", "map", type_string, flags=re.IGNORECASE)
    return type_string.replace(":", " ")


def parse_ddl_string(
    ddl_string: str, return_raw_type: bool = False
) -> types_proto.DataType | snowpark.types.DataType:
    """
    Parse a DDL string and return the Proto data type.

    This function is used to parse a DDL string and return the Proto data type.
    """
    schema = type_string_to_type_object(ddl_string)
    column_name_map = None

    # snowpark doesn't retain the column casing. Using this custom logic to construct ColumnNameMap
    # and preserve the name mapping.
    if isinstance(schema, snowpark.types.StructType):
        spark_column_names = []
        snowpark_column_names = []
        cols = _replace_complex_patterns(ddl_string).split(",")
        for col in cols:
            parts = col.strip().split(" ")
            if len(parts) > 0:
                spark_column_names.append(parts[0])

        for field in schema.fields:
            for spark_name in spark_column_names:
                if spark_name.lower() == field.name.lower():
                    snowpark_column_names.append(field.name)

        column_name_map = ColumnNameMap(spark_column_names, snowpark_column_names)

    struct_proto = list(snowpark_to_proto_type(schema, column_name_map).values())[0]

    if return_raw_type:
        return schema

    if isinstance(schema, snowpark.types.StructType):
        return types_proto.DataType(struct=struct_proto)
    else:
        type_dict = {ddl_string.lower(): struct_proto}
        type_name_mapping = {"int": "integer"}
        type_dict = {type_name_mapping.get(k, k): v for k, v in type_dict.items()}
        return types_proto.DataType(**type_dict)


def map_spark_timestamp_format_expression(arguments: expressions_pb2.Expression) -> str:
    """
    Converts a Spark date-time format expression to a Snowflake date-time format string.

    :param arguments: Spark date-time format literal expression
    :return: Equivalent Snowflake date-time format string
    """
    match arguments.WhichOneof("expr_type"):
        case "literal":
            lit_value, _ = get_literal_field_and_name(arguments.literal)
            return _map_spark_to_snowflake_timestamp_format(lit_value)
        case other:
            raise SnowparkConnectNotImplementedError(
                f"Unsupported expression type {other} in timestamp format argument"
            )


TIMESTAMP_FORMAT_RE = re.compile(r"(\w)\1*")


def _map_spark_to_snowflake_timestamp_format(spark_format: str) -> str:
    """
    Converts a Spark date-time format string to a Snowflake date-time format string.

    :param spark_format: Spark date-time format string
    :return: Equivalent Snowflake date-time format string
    """
    # Mapping of Spark format to Snowflake format
    format_mapping = {
        "yyyy": "YYYY",  # Year
        "yyy": "YYYY",  # Year
        "yy": "YY",  # 2 Digit Year
        "y": "YYYY",  # Year
        "MMMM": "MMMM",  # Name of the month
        "MMM": "MON",  # Abbreviated name of the month
        "MM": "MM",  # Month
        "M": "MM",  # Month
        "LLLL": "MMMM",  # Name of the month
        "LLL": "MON",  # Abbreviated name of the month
        "LL": "MM",  # Month
        "L": "MM",  # Month
        "dd": "DD",  # Day
        "d": "DD",  # Day
        "DD": "DD",  # Day
        "D": "DD",  # Day
        "HH": "HH24",  # Hour (24-hour format)
        "H": "HH24",  # Hour (24-hour format)
        "hh": "HH12",  # Hour (12-hour format)
        "h": "HH12",  # Hour (12-hour format)
        "mm": "MI",  # Minute
        "m": "MI",  # Minute
        "ss": "SS",  # Second
        "s": "SS",  # Second
        "SSS": "FF3",  # Milliseconds (3 fractional digits)
        "SS": "FF2",  # Milliseconds (2 fractional digits)
        "S": "FF1",  # Milliseconds (1 fractional digits)
        "a": "AM",  # AM/PM
        "XXX": "TZH:TZM",  # Timezone offset in ±HH:MM format
        "EEE": "DY",  # Abbreviated day of the week
        "EE": "DY",  # Abbreviated day of the week
        "E": "DY",  # Abbreviated day of the week
    }

    def _replace(m: re.Match) -> str:
        ret = format_mapping.get(m.group(0))
        if ret is None:
            raise IllegalArgumentException(f"Invalid format pattern: {spark_format!r}")
        return ret

    return TIMESTAMP_FORMAT_RE.sub(_replace, spark_format)
