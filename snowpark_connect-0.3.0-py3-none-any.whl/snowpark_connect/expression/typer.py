from snowflake import snowpark

from snowflake.snowpark import Column, DataFrame
from snowflake.snowpark.types import DataType, LongType, StructField, StructType


class ExpressionTyper:
    def __init__(self, df: DataFrame) -> None:
        self.df = df
        self._is_window_enabled = False

    def type(self, column: Column) -> list[DataType]:
        return [f.datatype for f in self.df.select(column).schema.fields]

    @staticmethod
    def dummy_typer(session: snowpark.Session = None):
        """
        Get a dummy typer, which can be used to get expression types. Since typer requires a dataframe,
        the dummy typer is mainly used when there is no existing handy dataframe.

        Example:
            (_, typed_column) = map_single_column_expression(
                    expression, column_map, ExpressionTyper.dummy_typer(session)
                )
        """
        if session is None:
            session = snowpark.Session.builder.getOrCreate()
        empty_df = session.create_dataframe(
            [], schema=StructType([StructField("id", LongType(), True)])
        )
        typer = ExpressionTyper(empty_df)
        return typer

    @property
    def is_window_enabled(self) -> bool:
        """
        Get the flag that indicates if window expressions are enabled.

        Returns:
            bool: True if window expressions are enabled; otherwise False.
        """
        return self._is_window_enabled

    @is_window_enabled.setter
    def is_window_enabled(self, value: bool) -> None:
        """
        Set the flag for enabling window expressions.

        Args:
            value (bool): The new setting for window expressions.
        """
        self._is_window_enabled = value
