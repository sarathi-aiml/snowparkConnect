import re
from typing import Tuple

import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
from snowflake import snowpark

import snowflake.snowpark.functions as snowpark_fn
from snowpark_connect.column_name_handler import ColumnNameMap
from snowpark_connect.expression.typer import ExpressionTyper
from snowpark_connect.typed_column import TypedColumn
from snowpark_connect.utils.context import get_alias_map, get_plan_id_map

IDENTIFIER_UNQUOTED_CASE_INSENSITIVE = re.compile('^(["-_A-Za-z]+[".-_A-Za-z0-9$]*)$')
SPARK_QUOTED = re.compile("^(`.+`)$", re.DOTALL)


def is_spark_quoted(name: str) -> bool:
    """
    Check if the name is already quoted.
    """
    return SPARK_QUOTED.match(name) is not None


def map_unresolved_attribute(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[str, TypedColumn]:
    attr_name = exp.unresolved_attribute.unparsed_identifier
    if is_spark_quoted(attr_name):
        # Drop the quotes because we don't need them. Case sensitivity is handled without them.
        attr_name = attr_name[1:-1]
    if exp.unresolved_attribute.HasField("plan_id"):
        target_df = get_plan_id_map(exp.unresolved_attribute.plan_id)
        typer = ExpressionTyper(target_df)
        assert (
            target_df is not None
        ), f"resolving an attribute of a unresolved dataframe {exp.unresolved_attribute.plan_id}"

        snowpark_name = (
            target_df._column_map.get_snowpark_column_name_from_spark_column_name(
                attr_name
            )
        )
        col = target_df.col(snowpark_name)
        return (attr_name, TypedColumn(col, lambda: typer.type(col)))
    else:
        snowpark_name = column_mapping.get_snowpark_column_name_from_spark_column_name(
            attr_name, allow_non_exists=True
        )
        if snowpark_name is None:
            # check for alias
            (alias_name, col_name) = _parse_spark_column_alias(attr_name)
            if col_name is not None and alias_name in get_alias_map():
                alias_df = get_alias_map()[alias_name]
                typer = ExpressionTyper(alias_df)
                snowpark_name = alias_df._column_map.get_snowpark_column_name_from_spark_column_name(
                    col_name
                )
                col = alias_df.col(snowpark_name)
                return col_name, TypedColumn(col, lambda: typer.type(col))
            # Column does not exist. Pass in dummy column name for lazy error throwing.
            snowpark_name = attr_name
        # This is a special case for join, where we may have ambiguous column names between
        # left and right in Snowpark, but not in Spark.
        if isinstance(snowpark_name, snowpark.column.Column):
            result_exp = snowpark_name
        else:
            is_qualified_name = IDENTIFIER_UNQUOTED_CASE_INSENSITIVE.match(
                snowpark_name
            )
            result_exp = snowpark_fn.col(
                snowpark_name, _is_qualified_name=is_qualified_name
            )
        return attr_name, TypedColumn(
            result_exp,
            lambda: typer.type(result_exp),
        )


def _parse_spark_column_alias(attr_name: str) -> Tuple[str, str | None]:
    """Parse df_alias.col to (df_alias, col)"""
    # TODO: properly handle alias and column names that contains ` and .
    res = attr_name.split(".")
    if len(res) == 1:
        return res[0], None
    return res[0], res[1]
