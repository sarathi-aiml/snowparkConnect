from snowflake import snowpark

import snowflake.snowpark.functions as snowpark_fn
from snowpark_connect.typed_column import TypedColumn


def to_semistructured(tc: TypedColumn) -> snowpark.Column:
    if len(tc.types) > 1:
        return tc.col
    match tc.typ:
        case snowpark.types.StructType() if tc.typ.structured:
            return snowpark_fn.cast(tc.col, snowpark.types.StructType())
        case snowpark.types.MapType() if tc.typ.structured:
            return snowpark_fn.cast(tc.col, snowpark.types.MapType())
        case snowpark.types.ArrayType() if tc.typ.structured:
            return snowpark_fn.cast(tc.col, snowpark.types.ArrayType())
    return tc.col
