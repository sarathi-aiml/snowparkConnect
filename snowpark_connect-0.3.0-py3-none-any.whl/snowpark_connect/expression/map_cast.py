import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark._internal.type_utils import type_string_to_type_object
from snowflake.snowpark.types import (
    BinaryType,
    BooleanType,
    DateType,
    DoubleType,
    LongType,
    NullType,
    StringType,
    StructType,
    TimestampTimeZone,
    TimestampType,
    _FractionalType,
    _IntegralType,
    _NumericType,
)
from snowpark_connect.column_name_handler import ColumnNameMap
from snowpark_connect.expression.typer import ExpressionTyper
from snowpark_connect.type_mapping import proto_to_snowpark_type
from snowpark_connect.typed_column import TypedColumn


def map_cast(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
    typer: ExpressionTyper,
) -> tuple[list[str], TypedColumn]:
    """
    Map a cast expression to a Snowpark expression.
    """

    from snowpark_connect.expression.map_expression import map_single_column_expression

    match exp.cast.WhichOneof("cast_to_type"):
        case "type":
            to_type = proto_to_snowpark_type(exp.cast.type)
        case "type_str":
            to_type = type_string_to_type_object(exp.cast.type_str)
        case _:
            raise ValueError("No type to cast to")
    new_name, typed_column = map_single_column_expression(
        exp.cast.expr, column_mapping, typer
    )
    from_type = typed_column.typ
    col = typed_column.col
    match (from_type, to_type):
        case (_, _) if (from_type == to_type):
            result_exp = col
        case (NullType(), _):
            result_exp = col.cast(to_type)
        case (StructType(), _) if from_type.structured:
            result_exp = col.cast(to_type, rename_fields=True)

        # date and timestamp
        case (TimestampType(), _) if isinstance(to_type, _NumericType):
            epoch_s = snowpark_fn.date_part("epoch_seconds", col)
            result_exp = epoch_s.cast(to_type)
        case (TimestampType(), BooleanType()):
            timestamp_0L = snowpark_fn.to_timestamp(snowpark_fn.lit(0))
            result_exp = snowpark_fn.when(
                col.is_not_null(),
                col
                != timestamp_0L,  # 0L timestamp is mapped to False, other values are mapped to True
            ).otherwise(snowpark_fn.lit(None))
        case (TimestampType(), DateType()):
            result_exp = snowpark_fn.to_date(col)
        case (DateType(), TimestampType()):
            result_exp = snowpark_fn.to_timestamp(col)
            result_exp = result_exp.cast(TimestampType(TimestampTimeZone.NTZ))
        case (TimestampType(), TimestampType()):
            result_exp = col
        case (_, TimestampType()) if isinstance(from_type, _NumericType):
            microseconds = col * snowpark_fn.lit(1000000)
            result_exp = snowpark_fn.when(
                col < 0, snowpark_fn.ceil(microseconds)
            ).otherwise(snowpark_fn.floor(microseconds))
            result_exp = result_exp.cast(LongType())
            result_exp = snowpark_fn.to_timestamp(
                result_exp, snowpark_fn.lit(6)
            )  # microseconds precision
            result_exp = result_exp.cast(TimestampType(TimestampTimeZone.NTZ))
        case (_, TimestampType()) if isinstance(from_type, BooleanType):
            result_exp = snowpark_fn.to_timestamp(
                col.cast(LongType()), snowpark_fn.lit(6)
            )  # microseconds precision
            result_exp = result_exp.cast(TimestampType(TimestampTimeZone.NTZ))
        case (_, TimestampType()):
            result_exp = snowpark_fn.function("try_to_timestamp")(col)
            result_exp = result_exp.cast(TimestampType(TimestampTimeZone.NTZ))
        case (DateType(), _) if isinstance(to_type, (_NumericType, BooleanType)):
            result_exp = snowpark_fn.cast(snowpark_fn.lit(None), to_type)
        case (_, DateType()):
            result_exp = snowpark_fn.function("try_to_date")(col)

        # boolean
        case (BooleanType(), _) if isinstance(to_type, _NumericType):
            result_exp = col.cast(LongType()).cast(to_type)
        case (_, BooleanType()) if isinstance(from_type, _NumericType):
            result_exp = col.cast(LongType()).cast(to_type)

        # binary
        case (StringType(), BinaryType()):
            result_exp = snowpark_fn.to_binary(col, "UTF-8")
        case (_, BinaryType()):
            result_exp = snowpark_fn.try_to_binary(col)
        case (BinaryType(), StringType()):
            result_exp = snowpark_fn.to_varchar(col, "UTF-8")

        # numeric
        case (_, _) if isinstance(from_type, _FractionalType) and isinstance(
            to_type, _IntegralType
        ):
            result_exp = snowpark_fn.when(col < 0, snowpark_fn.ceil(col)).otherwise(
                snowpark_fn.floor(col)
            )
            result_exp = result_exp.cast(to_type)
        case (StringType(), _) if (isinstance(to_type, _IntegralType)):
            result_exp = snowpark_fn.try_cast(col, DoubleType())
            result_exp = snowpark_fn.when(
                result_exp < 0, snowpark_fn.ceil(result_exp)
            ).otherwise(snowpark_fn.floor(result_exp))
            result_exp = result_exp.cast(to_type)

        case (StringType(), _):
            result_exp = snowpark_fn.try_cast(col, to_type)

        case _:
            result_exp = snowpark_fn.cast(col, to_type)

    return [new_name], TypedColumn(result_exp, lambda: [to_type])
