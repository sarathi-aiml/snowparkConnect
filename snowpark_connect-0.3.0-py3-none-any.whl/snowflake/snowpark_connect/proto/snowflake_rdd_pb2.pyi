from pyspark.sql.connect.proto import relations_pb2 as _relations_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Mapping, Optional, Union

DESCRIPTOR: _descriptor.FileDescriptor

class Rdd(_message.Message):
    __slots__ = ["map", "reduce"]
    MAP_FIELD_NUMBER: ClassVar[int]
    REDUCE_FIELD_NUMBER: ClassVar[int]
    map: RddMap
    reduce: RddReduce
    def __init__(
        self,
        map: Optional[Union[RddMap, Mapping]] = ...,
        reduce: Optional[Union[RddReduce, Mapping]] = ...,
    ) -> None: ...

class RddMap(_message.Message):
    __slots__ = ["func", "input"]
    FUNC_FIELD_NUMBER: ClassVar[int]
    INPUT_FIELD_NUMBER: ClassVar[int]
    func: bytes
    input: _relations_pb2.Relation
    def __init__(
        self,
        input: Optional[Union[_relations_pb2.Relation, Mapping]] = ...,
        func: Optional[bytes] = ...,
    ) -> None: ...

class RddReduce(_message.Message):
    __slots__ = ["func", "input"]
    FUNC_FIELD_NUMBER: ClassVar[int]
    INPUT_FIELD_NUMBER: ClassVar[int]
    func: bytes
    input: _relations_pb2.Relation
    def __init__(
        self,
        input: Optional[Union[_relations_pb2.Relation, Mapping]] = ...,
        func: Optional[bytes] = ...,
    ) -> None: ...
