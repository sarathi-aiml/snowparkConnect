# Proto source for reference:
# https://github.com/apache/spark/blob/branch-3.5/connector/connect/common/src/main/protobuf/spark/connect/base.proto#L420
import re
from copy import copy
from typing import Any, Dict

import pyspark.sql.connect.proto.base_pb2 as proto_base
from tzlocal import get_localzone_name

from snowflake import snowpark
from snowflake.snowpark_connect.utils.snowpark_connect_logging import logger
from snowflake.snowpark_connect.utils.telemetry import (
    SnowparkConnectNotImplementedError,
)


def str_to_bool(boolean_str: str) -> bool:
    assert boolean_str in [
        "True",
        "true",
        "False",
        "false",
        "1",
        "0",
        "",  # This is the default value, equivalent to False.
    ], f"Invalid boolean value: {boolean_str}"
    return boolean_str in ["True", "true", "1"]


class GlobalConfig:
    """This class contains the global configuration for the Spark Server."""

    default_static_global_config = {
        "spark.sql.globalTempDatabase": "global_temp",
    }

    default_global_config = {
        # TODO: This will need to be changed to the actual host of the driver.
        "spark.driver.host": "sc://localhost:15002",
        "spark.sql.pyspark.inferNestedDictAsStruct.enabled": "false",
        "spark.sql.pyspark.legacy.inferArrayTypeFromFirstElement.enabled": "false",
        "spark.sql.repl.eagerEval.enabled": "false",
        "spark.sql.repl.eagerEval.maxNumRows": "20",
        "spark.sql.repl.eagerEval.truncate": "20",
        "spark.sql.session.localRelationCacheThreshold": "67108864",
        "spark.sql.session.timeZone": get_localzone_name(),  # spark by default uses jvm local timezone
        "spark.sql.timestampType": "TIMESTAMP_LTZ",
        "spark.sql.crossJoin.enabled": "true",
        "spark.sql.caseSensitive": "false",
        "spark.sql.mapKeyDedupPolicy": "EXCEPTION",
    }

    boolean_config_list = [
        "spark.sql.pyspark.inferNestedDictAsStruct.enabled",
        "spark.sql.pyspark.legacy.inferArrayTypeFromFirstElement.enabled",
        "spark.sql.repl.eagerEval.enabled",
        "spark.sql.crossJoin.enabled",
        "spark.sql.caseSensitive",
    ]

    int_config_list = [
        "spark.sql.repl.eagerEval.maxNumRows",
        "spark.sql.repl.eagerEval.truncate",
        "spark.sql.session.localRelationCacheThreshold",
    ]

    float_config_list = []

    def __init__(self) -> None:
        self.global_config = copy(self.default_global_config)
        for key, pair in self.default_static_global_config.items():
            self.set(key, pair)
        for key in self.global_config.keys():
            setattr(self, key.replace(".", "_"), self._get_config_setting(key))

    def _get_config_setting(self, key: str) -> bool | int | float | str:
        """Get the configuration setting for the key based on the setting type."""
        if key in self.boolean_config_list:
            return str_to_bool(self.global_config[key])
        elif key in self.int_config_list:
            return int(self.global_config[key])
        elif key in self.float_config_list:
            return float(self.global_config[key])
        else:
            return self.global_config[key]

    def __getitem__(self, item: str) -> str:
        return self.get(item)

    def __setitem__(self, key: str, value: str) -> None:
        return self.set(key, value)

    def get(self, key, default=None) -> str:
        return self.global_config.get(key, default)

    def set(self, key: str, value: str) -> None:
        self.global_config[key] = value
        # This is necessary to make the configuration available as an attribute.
        setattr(self, key.replace(".", "_"), self._get_config_setting(key))


SESSION_CONFIG_KEY_WHITELIST = {
    "spark.hadoop.fs.s3a.access.key",
    "spark.hadoop.fs.s3a.secret.key",
    "spark.hadoop.fs.s3a.session.token",
    "snowpark.connect.sql.passthrough",
}
AZURE_SAS_KEY = re.compile(
    r"^fs\.azure\.sas\.[^\.]+\.[^\.]+\.blob\.core\.windows\.net$"
)


def valid_session_config_key(key: str):
    return (
        key in SESSION_CONFIG_KEY_WHITELIST  # AWS session keys
        or AZURE_SAS_KEY.match(key)  # Azure session keys
    )


class SessionConfig:
    """This class contains the session configuration for the Spark Server."""

    def __init__(self) -> None:
        self.config = {}

    def __getitem__(self, item: str) -> str:
        return self.get(item)

    def __setitem__(self, key: str, value: str) -> None:
        return self.set(key, value)

    def get(self, key, default=None) -> str:
        return self.config.get(key, default)

    def set(self, key: str, value: str) -> None:
        if not valid_session_config_key(key):
            return

        self.config[key] = value


# Set some default configuration that are necessary for the driver.
global_config = GlobalConfig()
sessions_config: Dict[str, SessionConfig] = {}


def route_config_proto(
    config: proto_base.ConfigRequest,
    snowpark_session: snowpark.Session,
) -> proto_base.ConfigResponse:
    global global_config
    global sessions_config

    match config.operation.WhichOneof("op_type"):
        case "set":
            logger.info("SET")

            if config.session_id not in sessions_config:
                sessions_config[config.session_id] = SessionConfig()

            for pair in config.operation.set.pairs:
                _require_non_static_config(pair.key)
                global_config[pair.key] = pair.value
                if valid_session_config_key(pair.key):
                    sessions_config[config.session_id][pair.key] = pair.value
                set_snowflake_parameters(pair.key, pair.value, snowpark_session)
            return proto_base.ConfigResponse(session_id=config.session_id)
        case "unset":
            logger.info("UNSET")
            for key in config.operation.unset.keys:
                _require_non_static_config(key)
                default_value = global_config.default_global_config.get(key, "")
                global_config[key] = default_value
                set_snowflake_parameters(key, default_value, snowpark_session)
            return proto_base.ConfigResponse(session_id=config.session_id)
        case "get":
            logger.info("GET")
            pairs = [
                proto_base.KeyValue(key=key, value=global_config.get(key, ""))
                for key in config.operation.get.keys
            ]
            return proto_base.ConfigResponse(
                session_id=config.session_id,
                pairs=pairs,
            )
        case "get_with_default":
            logger.info("GET_WITH_DEFAULT")
            result_pairs = [
                proto_base.KeyValue(
                    key=pair.key, value=global_config.get(pair.key, pair.value)
                )
                for pair in config.operation.get_with_default.pairs
            ]
            return proto_base.ConfigResponse(
                session_id=config.session_id,
                pairs=result_pairs,
            )
        case "get_option":
            logger.info("GET_OPTION")
            res = proto_base.ConfigResponse(session_id=config.session_id)
            for key in config.operation.get_option.keys:
                pair = res.pairs.add()
                pair.key = key
                val = global_config.get(key)
                if val:
                    pair.value = val
            return res
        case _:
            raise SnowparkConnectNotImplementedError(f"Unexpected request {config}")


def _require_non_static_config(key: str) -> None:
    # https://github.com/apache/spark/blob/v3.5.3/sql/core/src/main/scala/org/apache/spark/sql/RuntimeConfig.scala#L161
    # Spark does not allow to modify static configurations at runtime.
    if key in global_config.default_static_global_config.keys():
        raise ValueError(f"Cannot modify the value of a static config: {key}")


def init_snowpark_session(session: snowpark.Session) -> None:
    logger.info(f"Initializing session {session}")

    # TODO: need to deal with scenario when a session expires and a new session is created. Probably add a global util
    # function to get session and re-init new session there when needed.
    session.sql("ALTER SESSION SET TIMESTAMP_TYPE_MAPPING = TIMESTAMP_LTZ").collect()
    session.sql(
        f"ALTER SESSION SET TIMEZONE = '{global_config.spark_sql_session_timeZone}'"
    ).collect()

    db = session.get_current_database()
    prev_schema = session.get_current_schema()
    # This schema is used for "global temp views".
    # If schema is created, it is also changed in the context of the session
    session.sql(
        f"create schema if not exists {global_config.spark_sql_globalTempDatabase}"
    ).collect()
    match (prev_schema, session.get_current_schema()):
        case (None, curr) if curr is not None:
            # session.use_schema(None) is not allowed.
            # Instead, we call `use_database` which will set schema in context to the default one.
            session.use_database(db)
        case (prev, curr) if prev != curr:
            session.use_schema(prev)


def set_snowflake_parameters(
    key: str, value: Any, snowpark_session: snowpark.Session
) -> None:
    if key == "spark.sql.session.timeZone":
        if value:
            snowpark_session.sql(f"ALTER SESSION SET TIMEZONE = '{value}'").collect()
        else:
            snowpark_session.sql("ALTER SESSION UNSET TIMEZONE").collect()
