# Very simple script to count API usage.
# It goes by the file functions_of_interest.txt in this directory. That is a simple extraction
# of the API scope from the sheet https://docs.google.com/spreadsheets/d/1E5EJ41OIDcZNcfE3ZxGZ8-dguwjPU65jtTJW9yJcItg/edit?gid=200028645#gid=200028645.
# It is only very approximate - it uses the function name (e.g. pyspark.sql.connect.functions.year => year)
# and does a simple string count in the test files (e.g. search for "year(").
#
# The intention is to make it easier to see what still needs to be done to facilitate work distribution,
# and to see progress.
#
# The counts just go to stdout, and can be copied to sheets from there.

import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def read_apis(file_path):
    with open(file_path) as file:
        # Use the last part. This is just a quick heuristic.
        return [line.strip().split(".")[-1] for line in file.readlines()]


def count_api_calls(directory, apis, exclude_dir=None):
    api_counts = {api: 0 for api in apis}
    for root, _, files in os.walk(directory):
        if exclude_dir and exclude_dir in root:
            continue
        for file in files:
            if file.endswith(".py") or file.endswith(".test"):
                with open(os.path.join(root, file)) as f:
                    content = f.read()
                    # This scans each file many times... but it's fast enough for now.
                    for api in apis:
                        # ( to check for invocation. Again, heuristic.
                        api_counts[api] += content.count(f"{api}(")
    return api_counts


def main():
    apis_file = os.path.join(SCRIPT_DIR, "functions_of_interest.txt")
    # NOTE: This targets the data dir for expectation tests.
    # Hence, artificial workloads are (intentionally) excluded.
    expectation_tests_dir = os.path.join(
        SCRIPT_DIR, "..", "tests", "expectation_tests", "data"
    )
    tests_dir = os.path.join(SCRIPT_DIR, "..", "tests")

    apis = read_apis(apis_file)

    counts_in_expectation_tests = count_api_calls(expectation_tests_dir, apis)
    counts_in_other_tests = count_api_calls(tests_dir, apis, expectation_tests_dir)

    print("API, Count in expectation_tests, Count in other tests")  # noqa: T201
    for api in apis:
        expectation_count = counts_in_expectation_tests.get(api, 0)
        tests_count = counts_in_other_tests.get(api, 0)
        print(f"{api}, {expectation_count}, {tests_count}")  # noqa: T201


if __name__ == "__main__":
    main()
