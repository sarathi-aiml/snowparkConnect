import base64

import grpc

import snowpark_connect.proto.control_pb2 as control_proto
import snowpark_connect.proto.control_pb2_grpc as control_grpc


class ControlClient:
    def __init__(self) -> None:
        self.host = "localhost"
        self.server_port = 15002
        self.channel = grpc.insecure_channel(f"{self.host}:{self.server_port}")
        self.stub = control_grpc.ControlServiceStub(self.channel)

        # Check if the service is active.
        # TODO: our local socket solution currently doesn't expose this feature.
        try:
            grpc.channel_ready_future(self.channel).result(timeout=1)
        except Exception:
            self.stub = None

    def configure(self, config):
        return config  # TODO

    def ping(self, payload):
        return self.stub.Ping(control_proto.PingRequest(payload=payload)).payload

    def get_request_ast(self, force_flush: bool = False):
        if self.stub is None:
            return "", ""
        else:
            res = self.stub.GetRequestAst(
                control_proto.GetRequestAstRequest(force_flush=force_flush)
            )
            return [
                base64.b64encode(req).decode("utf-8") for req in res.spark_requests
            ], res.snowpark_ast_batches
