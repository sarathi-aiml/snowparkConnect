# flake8: noqa: T201

import argparse
import collections
import json
import pathlib
import re
import subprocess
import tempfile
from collections.abc import Iterable
from dataclasses import asdict, dataclass

from snowflake.cortex import complete as cortex_complete

from snowflake.snowpark import Session

DEFAULT_CONNECTION_NAME = "spark-connect"

PROJECT_BASE_PATH = pathlib.Path(__file__).resolve().parent.parent

EXPECTATION_TESTS_DIR_PATH = PROJECT_BASE_PATH / "tests" / "expectation_tests" / "data"

DEFAULT_MODEL = "claude-3-5-sonnet"

# To scan the LLM-generated code using Snyk you need access to Snyk via Okta and be a member of "Random Tests & Scans" org
# from the "Snowflake Corporate" group. Alternatively, you can disable the scans using "--disable-snyk" flag.
# Reference: https://snowflakecomputing.atlassian.net/wiki/spaces/CITS/pages/2614264640/Snyk+Intro+and+Onboarding+Document
SNYK_SCAN_ORG_ID = "2995b019-9169-4e10-89b4-f918c4dfe697"

PROMPT_ANALYZE_COVERAGE = """
You will be provided an expectation test script for a function, that tries to mimic exactly PySpark "{function_name}" inside of the triple backticks. Your goal is to provide a summary of this test coverage by outputting a JSON in the following format:
{{
    "null_inputs": <boolean>,
    "edge_cases": <boolean>,
    "different_data_types": <boolean>
    "show_with_schema_instead_of_show": <boolean>
}}

Each field in this JSON represents, whether the provided test cases sufficiently covers this criteria:
- "null_inputs" - does this test cover NULL and empty input values?
- "edge_cases" - does this test cover different edge cases?
- "different_data_types" - does this test cover different input data types?
- "show_with_schema_instead_of_show" - is "show_with_schema" is used instead of "show"?

Give only a valid JSON as an output, do not provide additional information.

```
{test_case}
```
"""

PROMPT_EXTEND_TEST_CASE = """
You will be provided an expectation test script for a function, that tries to mimic exactly PySpark "{function_name}" inside of the triple backticks.
This test does not match the following criteria:
{unsatisfied_criteria}

Your goal is to extend the provided test case. Do not provide additional information, output only the test case content without additional formating or separators.
Follow these rules strictly:
  - Do not delete any existing code lines.
  - Do not structure code in classes or functions. Keep it as a flat test case content.
  - Give only the whole new test case script as an output. Do not provide additional information.
  - If a given test scenario is meant to fail, use "with xfail(reason: str)" context  manager. Do not import it - it is available in the test content and it is not from pytest.
  - Do not add any additional import statements.
  - Do not use pytest.raises
  - Keep the test scenarios clean and readable. Increase coverage as much as possible, but do not include redundant scenarios.
  - Make sure that your code is a valid PySpark code.
  - Dot not mix types that to not match in a single dataframe, create separate dataframes for them.
  - Do not test for None values using a separate dataframe. Include this scenario in an dataframe, where there are more rows with values, which are not None.
  - Use show_with_schema as a separate function, not as a dataframe method. For example show_with_schema(df.select("xyz")).
  - If you are using show_with_schema, do not format it in multiple lines.
  - Structure your code to match the criteria, e.g. common case, null testing, data type tests.

```
{test_case}
```
"""

CHECKLIST_ITEM_TO_EXTEND_TEST_CASE_PROMPT_BULLET_POINT_MAP = {
    "null_inputs": "null and empty inputs should be tested",
    "edge_cases": "edge cases should be tested",
    "different_data_types": "different input data types should tested",
    "show_with_schema_instead_of_show": "show_with_schema should be used instead of show",
}


@dataclass(frozen=True)
class ExpectationTest:
    category: str
    name: str
    file_name: str
    test_case: str


@dataclass(frozen=True)
class TestCoverageChecklist:
    null_inputs: bool
    edge_cases: bool
    different_data_types: bool
    show_with_schema_instead_of_show: bool

    @property
    def all_criteria_satisfied(self) -> bool:
        return all(asdict(self).values())

    @property
    def unsatisfied_criteria(self) -> list[str]:
        return [field for field, value in asdict(self).items() if not value]

    @property
    def all_criteria(self) -> dict[str, bool]:
        return asdict(self)

    @classmethod
    def from_json(cls, json_str: str) -> "TestCoverageChecklist":
        return cls(**json.loads(json_str))


def create_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Analyze and process expectation tests.",
        prog="analyze_exp_tests.py",
    )

    parser.add_argument(
        "--coverage-report",
        action="store_true",
        help="Analyze the coverage of expectation tests.",
    )

    parser.add_argument(
        "--broaden-coverage",
        action="store_true",
        help="Broaden coverage for existing interface by extending existing test cases using Cortex.",
    )

    parser.add_argument(
        "--tests",
        nargs="+",
        help="Specify a list of expectation tests to process. If not provided, all will be processed.",
    )

    parser.add_argument(
        "--exclude",
        nargs="+",
        help="Specify a list of expectation tests to exclude.",
    )

    parser.add_argument(
        "--connection-name",
        default=DEFAULT_CONNECTION_NAME,
        help="Snowflake connection name. Defaults to 'spark-connect'.",
    )

    return parser


def create_session(connection_name: str) -> Session:
    return Session.builder.config("connection_name", connection_name).create()


def read_expectation_tests(
    tests: list[str] | None, excluded_tests: list[str] | None
) -> Iterable[ExpectationTest]:
    for file in EXPECTATION_TESTS_DIR_PATH.iterdir():
        file_name_matches_any_provided_test = (
            any(test.lower() in file.name.lower() for test in tests) if tests else True
        )

        is_file_excluded = (
            any(test.lower() in file.name.lower() for test in excluded_tests)
            if excluded_tests
            else False
        )

        match_expectation_test_name = re.match(
            r"^(?P<category>.+)\.(?P<name>[^.]+)\.test$", file.name
        )

        if (
            not file_name_matches_any_provided_test
            or not match_expectation_test_name
            or is_file_excluded
        ):
            continue

        test_content = re.match(
            r"## TEST CASE\n(?P<test_case>.*?)\n## EXPECTED OUTPUT",
            file.read_text(),
            re.DOTALL,
        )
        if not test_content:
            raise ValueError(f"Unexpected expectation test format for file {file.name}")

        yield ExpectationTest(
            name=match_expectation_test_name.group("name"),
            category=match_expectation_test_name.group("category"),
            file_name=file.name,
            test_case=test_content.group("test_case"),
        )


def create_coverage_checklist(
    expectation_test: ExpectationTest,
    session: Session,
    _attempt: int = 1,
) -> TestCoverageChecklist:
    llm_raw_checklist = cortex_complete(
        DEFAULT_MODEL,
        PROMPT_ANALYZE_COVERAGE.format(
            function_name=expectation_test.file_name,
            test_case=expectation_test.test_case,
        ),
        session=session,
    )

    try:
        return TestCoverageChecklist.from_json(llm_raw_checklist)
    except json.decoder.JSONDecodeError as exc:
        if _attempt > 1:
            raise ValueError(
                f"LLM failed to generate a checklist in a valid JSON format for {expectation_test.file_name} after "
                f"{_attempt} attempts. Try excluding this file from the next run using --exclude [TESTS...]\n"
                f"Raw LLM output: {llm_raw_checklist}"
            ) from exc

        return create_coverage_checklist(
            expectation_test, session, _attempt=_attempt + 1
        )


def broaden_test_coverage(
    expectation_test: ExpectationTest,
    checklist: TestCoverageChecklist,
    session: Session,
) -> str:
    checklist_str = "\n".join(
        [
            f"- {CHECKLIST_ITEM_TO_EXTEND_TEST_CASE_PROMPT_BULLET_POINT_MAP[value]}"
            for value in checklist.unsatisfied_criteria
        ]
    )

    return cortex_complete(
        DEFAULT_MODEL,
        PROMPT_EXTEND_TEST_CASE.format(
            function_name=expectation_test.file_name,
            test_case=expectation_test.test_case,
            unsatisfied_criteria=checklist_str,
        ),
        session=session,
    )


def print_coverage_summary(stats: dict[str, int]) -> None:
    print("Coverage summary:")

    total_tests = stats["total_tests"]
    if total_tests == 0:
        print("No tests found.")
        return

    for field, value in stats.items():
        if field == "total_tests":
            continue

        print(f"{field}: {value / total_tests:.1%}")


def run_code_snyk_scan(code: str) -> tuple[int, str, str]:
    with tempfile.NamedTemporaryFile(suffix=".py") as fp:
        fp.write(rf"{code}".encode())
        fp.flush()

        result = subprocess.run(
            ["snyk", "code", "test", f"--org={SNYK_SCAN_ORG_ID}", f"{fp.name}"],
            capture_output=True,
            text=True,
            check=False,
        )

    return result.returncode, result.stdout, result.stderr


def run_coverage_analysis(
    expectation_tests: Iterable[ExpectationTest],
    coverage_report: bool,
    broaden_coverage: bool,
    session: Session,
) -> None:
    stats = collections.defaultdict(int)

    for test in expectation_tests:
        checklist = create_coverage_checklist(test, session)

        if coverage_report:
            stats["total_tests"] += 1

            for field, value in checklist.all_criteria.items():
                stats[field] += int(value)

            if not checklist.all_criteria_satisfied:
                print("Test:", test.file_name)
                print(
                    f"Unsatisfied criteria: {', '.join(checklist.unsatisfied_criteria)}",
                    end="\n\n",
                )

        if not checklist.all_criteria_satisfied and broaden_coverage:
            extended_test_case = broaden_test_coverage(test, checklist, session)

            test_file_path = EXPECTATION_TESTS_DIR_PATH / test.file_name
            test_file_path.write_text(
                f"## TEST CASE\n{extended_test_case}\n\n## EXPECTED OUTPUT"
            )

            scan_return_code, output, error = run_code_snyk_scan(extended_test_case)

            match scan_return_code:
                case 0:
                    pass  # No security vulnerabilities found
                case 1:
                    raise RuntimeError(
                        f"Snyk scan found vulnerabilities for test {test.file_name}. "
                        f"Please review it manually before proceeding. Scan result: {output}"
                    )
                case _:
                    raise RuntimeError(
                        f"Snyk scan failed for test {test.file_name} Error: {error}"
                    )

    if coverage_report:
        print_coverage_summary(stats)


def main() -> None:
    parser = create_parser()
    args = parser.parse_args()

    snowpark_session = create_session(args.connection_name)

    expectation_tests_to_process = read_expectation_tests(args.tests, args.exclude)

    if args.coverage_report or args.broaden_coverage:
        run_coverage_analysis(
            expectation_tests_to_process,
            args.coverage_report,
            args.broaden_coverage,
            snowpark_session,
        )


if __name__ == "__main__":
    main()
