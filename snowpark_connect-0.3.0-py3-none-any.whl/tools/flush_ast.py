import os
import subprocess
from typing import List, Union

from control_client import ControlClient


def unparser_classpath() -> str:
    explicit = os.getenv("MONOREPO_DIR")
    default = os.path.join(os.getenv("HOME"), "Snowflake/trunk")
    base_dir = explicit or default
    unparser_dir = os.path.join(base_dir, "bazel-bin/Snowpark/unparser")

    # Grab all *.jar files from the subtree.
    jars = []
    for path, _, files in os.walk(unparser_dir):
        jars.extend(
            [os.path.join(path, file) for file in files if file.endswith(".jar")]
        )
    return ":".join(jars)


def render(
    ast_base64: Union[str, List[str]],
    unparser=unparser_classpath(),  # noqa: B008
) -> str:
    """Uses the unparser to render the AST."""
    if len(ast_base64) == 0:
        return None

    # Check if the unparser path is valid.
    if len(unparser) == 0:
        return None
    for file in unparser.split(":"):
        if not os.path.exists(file):
            raise AssertionError(f"Unparser file {file} not found")

    if isinstance(ast_base64, str):
        ast_base64 = [ast_base64]

    res = subprocess.run(
        [
            "java",
            "-cp",
            unparser,
            "com.snowflake.snowpark.unparser.UnparserCli",
            ",".join(ast_base64),
        ],
        capture_output=True,
        text=True,
        check=True,
    )

    return res.stdout


if __name__ == "__main__":
    client = ControlClient()
    for batch in client.get_request_ast():
        print(render(batch))  # noqa: T201
