from pyspark.sql import Row, SparkSession

spark = SparkSession.builder.appName("SAS_Test").getOrCreate()
df = spark.createDataFrame(
    [
        Row(a=1, b=2.0),
        Row(a=2, b=3.0),
        Row(a=4, b=5.0),
    ]
)

df.show()
