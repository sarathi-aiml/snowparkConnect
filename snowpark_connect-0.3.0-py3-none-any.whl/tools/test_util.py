import datetime
import inspect
import os
import re
from decimal import Decimal
from itertools import product

from pyspark.sql import Row
from pyspark.sql.connect.dataframe import DataFrame
from pyspark.sql.dataframe import DataFrame as PySparkDataFrame
from pyspark.sql.types import (
    ArrayType,
    BooleanType,
    DateType,
    DecimalType,
    DoubleType,
    FloatType,
    IntegerType,
    MapType,
    StringType,
    StructField,
    StructType,
)

# The offset that helps map Python stack frame line number to the original test data file line number.
LINE_OFFSET = 41


def test_prelude(spark):
    """
    The initial environment used for all tests. The entries in the returned dictionary become global variables.
    """
    prelude = {}

    # A basic dataframe example.
    prelude["df"] = spark.createDataFrame(
        [
            Row(a=1, b=2.0, c="foo"),
            Row(a=2, b=None, c="bar"),
            Row(a=None, b=5.0, c="baz"),
        ]
    )

    # A more complex example.
    # TODO: Add time types, etc.
    schema = StructType(
        [
            StructField("Name", StringType(), True),
            StructField("Age", IntegerType(), True),
            StructField("Date of Birth", DateType(), True),
            StructField("Adult", BooleanType(), True),
            StructField("Height", FloatType(), True),  # centimeters
            StructField("Weight", DecimalType(precision=3, scale=1), True),  # kg
            StructField("Salary", DoubleType(), True),
            StructField("Skills", ArrayType(StringType()), True),
            StructField("Properties", MapType(StringType(), StringType()), True),
            StructField(
                "Address",
                StructType(
                    [
                        StructField("Street", StringType(), True),
                        StructField("City", StringType(), True),
                        StructField("ZipCode", IntegerType(), True),
                    ]
                ),
                True,
            ),
        ]
    )

    data = [
        (
            "John",
            30,
            datetime.date(1994, 11, 15),
            True,
            187.3,
            Decimal("81.7"),
            100000.0,
            ["Scala", "Python"],
            {"Car": "Honda", "Bike": "Yamaha"},
            ("123 Elm St", "Somewhere", 12345),
        ),
        (
            "Jane",
            35,
            datetime.date(1989, 1, 31),
            True,
            165.9,
            Decimal("62.6"),
            120000.0,
            ["Java", "C++"],
            {"Car": "Toyota", "Bike": "Ducati"},
            ("456 Oak St", "Anywhere", 67890),
        ),
        (
            "Joe",
            40,
            datetime.date(1984, 5, 8),
            True,
            174.2,
            Decimal("73"),
            140000.0,
            ["Python", "JavaScript"],
            {"Car": "Ford", "Bike": "BMW"},
            ("789 Pine St", "Everywhere", 54321),
        ),
        (
            "Jake",
            16,
            datetime.date(2008, 8, 8),
            False,
            155.7,
            Decimal("56.9"),
            90000.0,
            ["C#", "JavaScript"],
            {"Car": "Nissan", "Bike": "Suzuki"},
            ("101 Maple St", "Nowhere", 98765),
        ),
        (
            "",
            -1,
            datetime.date(1, 1, 1),
            None,
            float("inf"),
            Decimal("nan"),
            0.0000005,
            [],
            {},
            (None, None, None),
        ),
    ]

    prelude["df2"] = spark.createDataFrame(data, schema)
    prelude["empty_df"] = spark.createDataFrame([], schema)
    prelude["simple_df"] = spark.createDataFrame(
        [(2, "Alice", 80), (3, "Eva", 100), (5, "Bob", 120), (10, None, 140)],
        ["age", "name", "height"],
    )

    current_dir = os.path.dirname(os.path.abspath(__file__))
    prelude["RESOURCES_DIR"] = current_dir + "/../tests/expectation_tests/"
    return prelude


class xfail:
    exception_marker = "### XFAIL CAUGHT EXCEPTION"
    _query_id_regex = re.compile(
        r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.IGNORECASE
    )
    _incident_regex = re.compile(r"incident \d+")

    def __init__(self, reason=None) -> None:
        self.suffix = "" if reason is None else f": {reason}"

    def __enter__(self):
        print(f"### BEGIN XFAIL{self.suffix}\n")  # noqa: T201

    def __exit__(self, exty, ex, traceback):
        # We want a successful xfail() run to cause a test failure, since it corresponds to an unexpected pass.
        if ex is None:
            ex_suffix = ""
        else:
            ex_message = self._redact_exception_message(str(ex))
            ex_suffix = " WITH EXCEPTION"
            print(f"{xfail.exception_marker} {ex_message}")  # noqa: T201

        print(f"### END XFAIL{ex_suffix}{self.suffix}\n")  # noqa: T201
        return True

    def _redact_exception_message(self, ex_message: str) -> str:
        """Removes all potential query ids and incident ids from the exception message."""

        ex_message = self._query_id_regex.sub("<query_id>", ex_message)
        ex_message = self._incident_regex.sub("incident <incident_id>", ex_message)

        return ex_message


class raises:
    def __init__(self, exception_type: type, message_re: str | None = None) -> None:
        self.exception_type = exception_type
        self.message_re = message_re

    def __enter__(self):
        pass

    def __exit__(self, exty: type | None, ex: Exception | None, traceback):
        assert exty is not None, f"Failed to raise a {self.exception_type} exception"
        print(f"### EXPECTED EXCEPTION {exty}")  # noqa: T201
        return isinstance(ex, self.exception_type) and (
            self.message_re is None or re.search(self.message_re, str(ex))
        )


def _extract_expression():
    """
    A helper to extract the expression code, to be used by _show_internal.
    """
    # Go up three levels: show(...) -> _show_internal(...) -> _extract_expression(...)
    frame = inspect.currentframe().f_back.f_back.f_back
    code = inspect.getframeinfo(frame).code_context[0]
    start = code.index("(") + 1
    end = code.rindex(")")
    expr_code = code[start:end]
    line_no = frame.f_lineno - LINE_OFFSET
    line_str = f"[Line {line_no}]"
    return expr_code, line_str


def _show_internal(
    expr, value: bool, schema: bool, truncate: bool, collect: bool = True
):
    """
    Implementation of show, show_schema_only, and show_with_schema.
    """
    assert value or schema, "Useless call to _show_internal"

    expr_code, line_str = _extract_expression()
    if isinstance(expr, (DataFrame, PySparkDataFrame)):
        if value:
            print(f"{line_str} {expr_code}:")  # noqa: T201
            expr.show(truncate=truncate)
        if collect:
            expr.collect()  # make sure collect() doesn't break
        if schema:
            print(f"{line_str} {expr_code} schema:")  # noqa: T201
            print(f"{expr.schema}\n")  # noqa: T201
    else:
        if value:
            print(f"{line_str} {expr_code} = {expr}")  # noqa: T201
        if schema:
            print(f"{line_str} {expr_code} type = {type(expr)}")  # noqa: T201
    return expr


# TODO: make this code more robust to support use cases such as:
# foo(show(a) + show(b))
def show(expr, truncate: bool = True):
    """
    Returns the value of the argument, but with the side effect of printing it in the form:
    <expr> = <value of expr>
    """
    return _show_internal(expr, value=True, schema=False, truncate=truncate)


def show_schema_only(expr, truncate: bool = True):
    """
    Prints the schema for comparison purposes. If the expression doesn't evaluate to a
    data frame, then prints the type string.
    """
    return _show_internal(expr, value=False, schema=True, truncate=truncate)


def show_with_schema(expr, truncate: bool = True, collect: bool = True):
    """
    In addition to show(), also prints the schema.
    """
    return _show_internal(
        expr, value=True, schema=True, truncate=truncate, collect=collect
    )


def show_xfail(expr, xfail_reason=None, truncate: bool = True):
    """
    Same as show(), but implicitly wrapped in an xfail().
    """
    with xfail(xfail_reason):
        _show_internal(expr, value=True, schema=False, truncate=truncate)


def power_set(*values):
    """Returns the power set of the argument."""
    result = [[]]
    for v in values:
        result.extend([subset + [v] for subset in result])
    return result


def _caller_globals():
    return inspect.currentframe().f_back.f_back.f_globals


def parametrized_tests(**kwargs):
    cartesian = list(product(*kwargs.values()))
    maps = [dict(zip(kwargs.keys(), entry)) for entry in cartesian]
    for args in maps:
        args_str = ", ".join([f"{k} = {v}" for k, v in args.items()])
        print(f"\n[Running with parameters {args_str}]")  # noqa: T201
        _caller_globals().update(args)
        yield args


def output_files_with_extension_under_path(path, extension):
    return [f for f in sorted(os.listdir(path)) if f.endswith(extension)]
