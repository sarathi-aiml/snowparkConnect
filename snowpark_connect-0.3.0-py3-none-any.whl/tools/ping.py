from control_client import ControlClient

if __name__ == "__main__":
    client = ControlClient()
    print(f"Ping response: {client.ping('foo')}")  # noqa: T201
