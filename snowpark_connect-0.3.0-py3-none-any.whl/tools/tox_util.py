import os
import random

import toml
from snowflake import snowpark

config_path = os.path.expanduser("~/.snowflake/config.toml")
TEST_DB_PREFIX = "TESTDB_SAS_TOX_"


def _replace_database_value(test_db_name: str):
    with open(config_path) as f:
        config = toml.load(f)
    config["connections"]["spark-connect"]["database"] = test_db_name
    # Write back to the file
    with open(config_path, "w") as f:
        toml.dump(config, f)


def create_test_database():
    session = snowpark.Session.builder.config(
        "connection_name", "spark-connect"
    ).create()
    os_name = os.environ.get("OS_NAME", "")
    cloud_provider = os.environ.get("CLOUD_PROVIDER", "")
    test_db_name = f"{TEST_DB_PREFIX}{os_name}_{cloud_provider}_{''.join(random.choices('0123456789', k=15))}"
    session.sql(f"CREATE DATABASE {test_db_name}").show()
    _replace_database_value(test_db_name)


def _read_database_value():
    with open(config_path) as f:
        config = toml.load(f)
    database = config["connections"]["spark-connect"].get("database")
    assert database is not None
    return database


def _read_jdbc_connection_values():
    with open(config_path) as f:
        config = toml.load(f)
    host = config["connections"]["spark-connect"].get("host")
    user = config["connections"]["spark-connect"].get("user")
    password = config["connections"]["spark-connect"].get("password")
    database = config["connections"]["spark-connect"].get("database")
    schema = config["connections"]["spark-connect"].get("schema")
    warehouse = config["connections"]["spark-connect"].get("warehouse")
    role = config["connections"]["spark-connect"].get("role")
    return host, user, password, database, schema, warehouse, role


def drop_test_database():
    test_db_name = _read_database_value()
    # Only drop database created by this util.
    if test_db_name.startswith(TEST_DB_PREFIX):
        session = snowpark.Session.builder.config(
            "connection_name", "spark-connect"
        ).create()
        session.sql("DROP DATABASE IF EXISTS " + test_db_name).show()
