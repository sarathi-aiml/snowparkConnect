import threading
from typing import Dict, Tuple

from snowflake import snowpark

# global cache mapping  (sessionID, planID) -> cached snowpark df .
df_cache_map: Dict[Tuple[str, int], snowpark.DataFrame] = {}

# lock for thread safety
_cache_map_lock = threading.Lock()


def df_cache_map_get(key: Tuple[str, int]) -> snowpark.DataFrame | None:
    with _cache_map_lock:
        return df_cache_map.get(key)


def df_cache_map_set(key: Tuple[str, int], value: snowpark.DataFrame) -> None:
    with _cache_map_lock:
        df_cache_map[key] = value


def df_cache_map_pop(key: Tuple[str, int]) -> None:
    with _cache_map_lock:
        df_cache_map.pop(key, None)
