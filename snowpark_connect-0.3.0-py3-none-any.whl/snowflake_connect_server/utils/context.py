import threading
from typing import Any, Mapping

from snowflake import snowpark

# TODO: remove session id from context when we host SAS in Snowflake server

# Create a thread-local object to hold the execution context
_thread_local = threading.local()


def set_context(key: str, value: Any) -> None:
    """Set the execution context for the current thread."""
    if not hasattr(_thread_local, "context"):
        _thread_local.context = {}
    _thread_local.context[key] = value


def get_context(key: str) -> Any:
    """Get the execution context for the current thread."""
    if not hasattr(_thread_local, "context"):
        _thread_local.context = {}
    return _thread_local.context.get(key)


def set_plan_id_map(plan_id: int, df: snowpark.DataFrame) -> None:
    """Set the plan id map for the current thread."""
    if not hasattr(_thread_local, "plan_id_map"):
        _thread_local.plan_id_map = {}
    _thread_local.plan_id_map[plan_id] = df


def get_plan_id_map(plan_id: int) -> snowpark.DataFrame | None:
    """Set the plan id map for the current thread."""
    if not hasattr(_thread_local, "plan_id_map"):
        _thread_local.plan_id_map = {}
    return _thread_local.plan_id_map.get(plan_id)


def get_alias_map() -> Mapping[str, snowpark.DataFrame | None]:
    """Set the alias map for the current thread."""
    if not hasattr(_thread_local, "alias_map"):
        _thread_local.alias_map = {}
    return _thread_local.alias_map


def clear_thread_local_data() -> None:
    if hasattr(_thread_local, "context"):
        _thread_local.context = {}
    if hasattr(_thread_local, "plan_id_map"):
        _thread_local.plan_id_map = {}
    if hasattr(_thread_local, "alias_map"):
        _thread_local.alias_map = {}
