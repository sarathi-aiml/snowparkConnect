import pandas
import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
import pyspark.sql.connect.proto.relations_pb2 as relation_proto
import sqlglot
import sqlglot.expressions
from snowflake import snowpark

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark._internal.analyzer.analyzer_utils import unquote_if_quoted
from snowflake_connect_server.column_name_handler import ColumnNameMap, build_column_map

from ..utils.telemetry import NotImplementedErrorWithTelemetry
from .utils import column_name_generator


def rewrite_ast(node: sqlglot.expressions.Expression) -> None:
    explode_of_numeric_sequence_rule(node)


def explode_of_numeric_sequence_rule(node: sqlglot.expressions.Expression) -> None:
    """
    Rewrite the AST to handle the explode of a numeric sequence.

    In SparkSQL, calling explode on a sequence of integers will create a column with the
    IntegerType. In Snowpark, the column will be created with the VariantType, which
    is eventually cast to a string when collected. To handle this, we create a rule here
    to cast the column to an integer if the sequence we are exploding contains all integers.
    """
    if isinstance(node, sqlglot.expressions.Explode):
        for child in list(node.args.values()):
            if isinstance(child, sqlglot.expressions.GenerateSeries) and all(
                isinstance(arg, sqlglot.expressions.Literal) and arg.is_int
                for arg in child.args.values()
            ):
                # We are going to replace this node with a cast node in the parent.
                # We have to manually do this since we are extending the current node.
                parent = node.parent
                arg_key = node.arg_key
                index = node.index
                # Cast Explode node to integer
                cast_node = sqlglot.expressions.Cast(
                    this=node.pop(), to=sqlglot.expressions.DataType.build("INTEGER")
                )
                parent.set(arg_key, cast_node, index)
                # Sequence is usually a leaf node, so we return here.
                return


def rename_column_rule(
    node: sqlglot.expressions.Expression, column_count: dict
) -> None:
    """
    Rename the column names in the AST to deduplicate them.
    """
    match type(node):
        case sqlglot.expressions.Column | sqlglot.expressions.Alias:
            column_name = node.alias_or_name
            if column_name == "*":
                # Don't rename the column if it is a wildcard.
                return
            if column_name in column_count:
                column_count[column_name] += 1
            else:
                column_count[column_name] = 0
            node.set("alias", f"{column_name.upper()}SES{column_count[column_name]}")
        case sqlglot.expressions.TableAlias:
            node.this.set("SES", "NO_RENAME")
            for column in node.columns:
                rename_column_rule(column, column_count)
        case sqlglot.expressions.Identifier:
            if not isinstance(node.parent, sqlglot.expressions.TableAlias):
                return
            column_name = node.name
            if column_name in column_count:
                column_count[column_name] += 1
            else:
                column_count[column_name] = 0
            if "SES" in node.args.keys():
                return
            node.set("this", f"{column_name.upper()}SES{column_count[column_name]}")
            # Assign this to flag that we've already changed the names. This is ignored when the SQL
            # is generated.
            node.set("SES", "RENAMED")


def get_original_column_names(
    parsed_sql: sqlglot.expressions.Expression,
) -> tuple[list[str], bool]:
    """
    Traverse the AST to get the original column names.

    Sometimes, there are nested SELECT * queries in the AST. In these cases, the `alias_or_name`
    will be "*", which is not the actual column name. Because of this, we need to traverse the
    tree to get the original column names.
    """
    column_names = []
    star_found = False

    def traverse(node: sqlglot.expressions.Expression) -> None:
        nonlocal star_found

        match type(node):
            case sqlglot.expressions.Column | sqlglot.expressions.Alias:
                if node.alias_or_name != "*":
                    column_names.append(node.alias_or_name)
                    return
                else:
                    star_found = True
            case sqlglot.expressions.TableAlias:
                column_names.extend([c.alias_or_name for c in node.columns])
                return
            case sqlglot.expressions.Star:
                star_found = True
        for child in node.args.values():
            if child is not None:
                if isinstance(child, list):
                    for sub_child in child:
                        traverse(sub_child)
                elif isinstance(child, sqlglot.expressions.Expression):
                    traverse(child)

    traverse(parsed_sql)
    return list(column_names), star_found


def walk_ast_and_convert_columns(
    sql_ast: sqlglot.expressions.Expression, column_mapping: ColumnNameMap
) -> sqlglot.expressions.Expression:
    """
    Walk the AST and convert the columns to the Snowpark names.
    """

    def traverse_tree(node):
        """
        Traverse the entire tree and rewrite the AST.
        """
        match type(node):
            case sqlglot.expressions.Identifier:
                if node.alias_or_name in column_mapping.get_spark_columns():
                    # This will replace the Spark name with the Snowpark name in the sqlglot AST
                    node.set(
                        "this",
                        # sqlGlot will auto quote the identifier when translating to Snowflake SQL
                        unquote_if_quoted(
                            column_mapping.get_snowpark_column_name_from_spark_column_name(
                                node.alias_or_name
                            )
                        ),
                    )
                    node.set("quoted", True)
                    return
        for child in list(node.args.values()):
            if isinstance(child, list):
                for sub_child in child:
                    traverse_tree(sub_child)
            elif isinstance(child, sqlglot.expressions.Expression):
                traverse_tree(child)

    traverse_tree(sql_ast)
    return sql_ast


def parse_and_rewrite_ast(
    sql_string: str,
) -> tuple[sqlglot.expressions.Expression, list[str], bool]:
    """
    Parse the SQL string and add aliases in the AST to deduplicate column names.

    We take two passes in the tree. The first pass is to collect the unmodified column names
    from the AST. The second pass is to rewrite the AST with the rules we have listed above.
    """
    parsed_sql = sqlglot.parse_one(sql_string, dialect="spark")
    # We need to track the original column names from Spark so that we can map them to
    # the Snowpark names.
    correct_column_names, star_found = get_original_column_names(parsed_sql)

    # Dictionary to keep track of column name occurrences.
    column_count = {}

    def traverse_tree(node):
        """
        Traverse the entire tree and rewrite the AST.
        """
        rename_column_rule(node, column_count)
        rewrite_ast(node)
        for child in list(node.args.values()):
            if isinstance(child, list):
                for sub_child in child:
                    traverse_tree(sub_child)
            elif isinstance(child, sqlglot.expressions.Expression):
                traverse_tree(child)

    # Traverse and modify the parsed SQL, first by changing the column names and then
    # by casting the necessary nodes.
    traverse_tree(parsed_sql)

    return parsed_sql, correct_column_names, star_found


def map_sql_string_to_snowpark_df(
    sql_string: str, plan_id: int = None
) -> tuple[snowpark.DataFrame, str, str]:
    """
    Convert a sql string into a snowpark DataFrame.

    The Snowpark DataFrame has a column map attached to it that contains the Spark
    column names.
    The key is a unique expression key name, which is useful to identify the SQL command.
    The name is a unique expression name, which is useful to identify the SQL command.
    """
    session = snowpark.Session.builder.getOrCreate()
    parsed_sql, correct_column_names, star_found = parse_and_rewrite_ast(sql_string)
    snowflake_sql = parsed_sql.sql(dialect="snowflake")
    snowpark_df = build_column_map(
        session.sql(snowflake_sql), correct_column_names, True, star_found
    )
    return snowpark_df, parsed_sql.key, parsed_sql.name


def map_sql(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Map a SQL string to a DataFrame.

    The SQL string is executed and the resulting DataFrame is returned.
    """
    if len(rel.sql.args) > 0 or len(rel.sql.pos_args) > 0:
        raise NotImplementedErrorWithTelemetry("SQL arguments are not implemented")

    snowpark_df, sql_key, sql_expression_name = map_sql_string_to_snowpark_df(
        rel.sql.query, rel.common.plan_id
    )
    return snowpark_df


def map_sql_expr(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
) -> tuple[str, snowpark.Column]:
    # This is the Spark name for the column.
    parsed_expr = sqlglot.parse_one(exp.expression_string.expression.replace("'", ""))
    sql_ast = walk_ast_and_convert_columns(
        sqlglot.parse_one(exp.expression_string.expression, dialect="spark"),
        column_mapping,
    )
    snowflake_sql = sql_ast.sql(dialect="snowflake")

    new_column_name = column_name_generator(parsed_expr)
    return new_column_name, snowpark_fn.sql_expr(snowflake_sql)


def map_sql_to_pandas_df(
    sql_string: str,
) -> tuple[pandas.DataFrame, str] | tuple[None, None]:
    """
    Convert a sql string into a pandas DataFrame and its json schema.
    returns a tuple of empty Pandas DataFrame and schema string in case of DDL statements.
    returns a tuple of None for SELECT queries to enable lazy evaluation
    """
    snowpark_df, sql_key, sql_expression_name = map_sql_string_to_snowpark_df(
        sql_string
    )

    # spark.sql("select..") queries should be executed lazily
    if sql_key.lower() == "select":
        return None, None

    # spark.sql DDLs ("create table...") should be executed eagerly
    non_select_rows = snowpark_df.collect()

    # spark returns dataframe for DESCRIBE, SHOW SQL commands
    if sql_key.lower() == "describe" or (
        sql_key.lower() == "command" and sql_expression_name.lower() == "show"
    ):
        if len(non_select_rows) > 0:
            return pandas.DataFrame(non_select_rows), ""

    # spark returns empty dataframe for DDLs
    return pandas.DataFrame({"": [""]}), ""
