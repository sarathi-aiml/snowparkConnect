import numpy as np
import pandas
import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

import snowflake.snowpark.functions as fn
from snowflake_connect_server.column_name_handler import build_column_map
from snowflake_connect_server.relation.map_relation import map_relation


def map_corr(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Find the correlation of two columns in the input DataFrame.

    Returns a pandas DataFrame because the correlation of two columns produces
    a scalar value.
    """
    input_df: snowpark.DataFrame = map_relation(rel.corr.input)
    col1 = input_df._column_map.get_snowpark_column_name_from_spark_column_name(
        rel.corr.col1
    )
    col2 = input_df._column_map.get_snowpark_column_name_from_spark_column_name(
        rel.corr.col2
    )
    # TODO: Handle method, Snowpark does not support this yet.
    # if rel.corr.HasField("method"):
    #     method = rel.corr.method
    # else:
    #     method = "pearson"
    result: float = input_df.corr(col1, col2)
    return pandas.DataFrame({"corr": [result]})


def map_cov(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Find the covariance of two columns in the input DataFrame.

    Returns a pandas DataFrame because the corvariance of two columns produces
    a scalar value.
    """
    input_df: snowpark.DataFrame = map_relation(rel.cov.input)
    col1 = input_df._column_map.get_snowpark_column_name_from_spark_column_name(
        rel.cov.col1
    )
    col2 = input_df._column_map.get_snowpark_column_name_from_spark_column_name(
        rel.cov.col2
    )
    result: float = input_df.cov(col1, col2)
    return pandas.DataFrame({"cov": [result]})


def map_approx_quantile(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Find one or more approximate quantiles in the input DataFrame.

    Returns a pandas DataFrame because the approximate quantile produces a
    list of scalar values.
    """
    input_df: snowpark.DataFrame = map_relation(rel.approx_quantile.input)
    cols = input_df._column_map.get_snowpark_column_names_from_spark_column_names(
        list(rel.approx_quantile.cols)
    )
    quantile = list(rel.approx_quantile.probabilities)
    # TODO: Handle relative_error, Snowpark does not support this yet.
    result: list[float] = input_df.approxQuantile(cols, quantile)
    # Wrap result in list here to pack the result into a single cell
    return pandas.DataFrame({"approx_quantile": [result]})


def map_describe(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Computes basic statistics for numeric columns, which includes count, mean, stddev, min, and max.
    If no columns are provided, this function computes statistics for all numerical or string columns.
    Non-numeric and non-string columns will be ignored.

    Returns a new DataFrame that provides basic statistics for the given DataFrame
    """
    input_df: snowpark.DataFrame = map_relation(rel.describe.input)
    cols = []
    if rel.describe.cols:
        cols = input_df._column_map.get_snowpark_column_names_from_spark_column_names(
            list(rel.describe.cols)
        )
    desc_df: snowpark.DataFrame = input_df.describe(cols)

    return build_column_map_helper(rel, desc_df, input_df)


# TODO: track missing Snowpark feature
def map_summary(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Computes specified statistics for numeric or string columns. Available statistics are: count, mean, stddev, min,
    max, arbitrary approximate percentiles specified as a percentage (e.g., 75%), count_distinct, and
    approx_count_distinct. If no statistics are given, this function computes count, mean, stddev, min, approximate
    quartiles (percentiles at 25%, 50%, and 75%), and max.

    Returns a new DataFrame that provides specified statistics for the given DataFrame.
    """
    session = snowpark.Session.builder.getOrCreate()
    input_df: snowpark.DataFrame = map_relation(rel.summary.input)
    # retrieve 5 statistics from describe
    desc_df: snowpark.DataFrame = input_df.describe([])
    quantiles = []
    percentages = []
    if rel.summary.statistics:
        statistics = list(rel.summary.statistics)
    else:
        # default statistics
        statistics = ["count", "mean", "stddev", "min", "25%", "50%", "75%", "max"]

    # filter out non-requested statistics
    summary_df = desc_df.filter(desc_df.SUMMARY.isin(statistics))

    # convert percentages into decimal
    for stat in statistics:
        if stat[-1] == "%":
            quantiles.append(int(stat[:-1]) / 100)
            percentages.append(stat)
        elif stat == "count_distinct":
            # include "count_distinct" as it's the row name
            distinct_list_values = ["count_distinct"] + [
                input_df.select(column).distinct().count()
                for column in input_df.columns
            ]
            summary_df = add_stat_to_df(session, summary_df, [distinct_list_values])
        elif stat == "approx_count_distinct":
            approx_count_distinct_list_values = [
                fn.approx_count_distinct(column) for column in input_df.columns
            ]
            approx_count_distinct_df = input_df.select(
                *approx_count_distinct_list_values
            )
            approx_count_distinct_df_rows = approx_count_distinct_df.collect()
            # convert approx_count_distinct rows into values
            approx_count_distinct_list_values = [
                value
                for row in approx_count_distinct_df_rows
                for value in row.as_dict().values()
            ]
            # insert "approx_count_distinct" as it's the row name
            approx_count_distinct_list_values.insert(0, "approx_count_distinct")
            summary_df = add_stat_to_df(
                session, summary_df, [approx_count_distinct_list_values]
            )

    if len(quantiles) > 0:
        approx_quantile_values = input_df.approx_quantile(
            input_df.columns, percentile=quantiles
        )
        approx_quantile_values_transposed = np.transpose(approx_quantile_values)
        # the first parameter includes each percentage as the row name
        approx_quantile_list_values = np.hstack(
            (np.array(percentages).reshape(-1, 1), approx_quantile_values_transposed)
        ).tolist()
        summary_df = add_stat_to_df(session, summary_df, approx_quantile_list_values)

    # return the statistics in the requested order
    ordered_statistics = []
    df_rows = summary_df.collect()
    for stat in statistics:
        for row in df_rows:
            if stat == row.SUMMARY:
                ordered_statistics.append(row)
    ordered_summary_df = session.create_dataframe(ordered_statistics)

    return build_column_map_helper(rel, ordered_summary_df, input_df)


def add_stat_to_df(
    session,
    summary_df,
    stat_values,
) -> snowpark.DataFrame:
    df_data = [tuple(row) for row in stat_values]
    return summary_df.union(session.createDataFrame(df_data, summary_df.columns))


def build_column_map_helper(
    rel: relation_proto.Relation,
    desc_df: snowpark.DataFrame,
    input_df: snowpark.DataFrame,
) -> snowpark.DataFrame:
    spark_col_names = ["summary"]
    sp_col_names = ["SUMMARY"]
    for sp_col_name in desc_df.columns:
        if sp_col_name != "SUMMARY":
            spark_col_names.append(
                input_df._column_map.get_spark_column_name_from_snowpark_column_name(
                    sp_col_name
                )
            )
            sp_col_names.append(sp_col_name)

    return build_column_map(
        desc_df,
        spark_col_names,
    )
