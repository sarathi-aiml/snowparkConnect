import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

from snowflake_connect_server.column_name_handler import build_column_map
from snowflake_connect_server.relation.map_relation import map_relation
from snowflake_connect_server.utils.context import get_alias_map


def map_alias(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Returns an aliased dataframe in which the columns can now be referenced to using col(<df alias>, <column name>).
    """
    alias: str = rel.subquery_alias.alias
    input_df: snowpark.DataFrame = map_relation(rel.subquery_alias.input)
    get_alias_map()[alias] = input_df

    return build_column_map(
        input_df,
        input_df._column_map.get_spark_columns(),
    )
