import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

from snowflake_connect_server.expression.literal import get_literal_field_and_name
from snowflake_connect_server.expression.map_expression import map_expression
from snowflake_connect_server.relation.map_relation import map_relation


def map_sample_by(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Sample by an expression on the input DataFrame.
    """
    input_df: snowpark.DataFrame = map_relation(rel.sample_by.input)
    exp: expressions_proto.Expression = rel.sample_by.col
    _, col_expr = map_expression(exp, input_df._column_map)
    fractions = {
        get_literal_field_and_name(frac.stratum)[0]: frac.fraction
        for frac in rel.sample_by.fractions
    }
    result: snowpark.DataFrame = input_df.sampleBy(col_expr, fractions)
    result._column_map = input_df._column_map
    return result
