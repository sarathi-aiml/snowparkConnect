import io
import re

import pandas
import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

from snowflake_connect_server.relation.map_relation import map_relation


def map_show_string(rel: relation_proto.Relation) -> pandas.DataFrame:
    """
    Generate the string representation of the input dataframe.

    We return a pandas DataFrame object here because the `show_string` relation
    message creates a string. The client expects this string to be packed into an Arrow
    Buffer object as a single cell.
    """
    input_df: snowpark.DataFrame = map_relation(rel.show_string.input)
    show_string = input_df._show_string(
        rel.show_string.num_rows,
        max_width=1000,
        _emit_ast=snowpark.Session.builder.getOrCreate().ast_enabled,  # _show_string is internal api, thus requires _emit_ast
    )

    def replace_column_names(column_name: str | pandas.Series):
        if isinstance(column_name, pandas.Series):
            # This can happen because of DF alias, pick the first one of the series which is non-aliased.
            column_name = column_name.iloc[0]
        else:
            # We have a Snowpark column name that maps to multiple Spark column names.
            assert isinstance(column_name, str), f"Got {type(column_name)}"

        def func(match):
            old = match.group(0)
            new = " " * (len(old) - len(column_name)) + column_name
            return new

        return func

    # We have to replace the column names in the `show_string` with the "Spark"
    # column names. We also right-align the column names in this step.
    lines = show_string.split("\n")
    show_string_columns = lines[1]
    for c in input_df.columns:
        show_string_columns = re.sub(
            r"\s*\"?" + re.escape(c) + r"\"?\s+",
            replace_column_names(
                input_df._column_map.get_spark_column_name_from_snowpark_column_name(c)
            ),
            show_string_columns,
        )

    # This will right-align the data.
    corrected_lines = [re.sub(r"\|(.+?)(\s\s+)", r"|\2\1", line) for line in lines[3:]]

    # Special handling for empty dataframes. Snowpark emits an extra line.
    if len(corrected_lines) == 3 and all(
        cell.strip() == "" for cell in corrected_lines[0].split("|")
    ):
        del corrected_lines[0]

    # Special case handling to match empty dataframe returned by native spark on spark.sql() DDL operations
    if (
        len(corrected_lines) == 2
        and corrected_lines[0] == "------"
        and corrected_lines[1] == ""
    ):
        corrected_lines[0] = ""
        show_string_columns = ""
        for i in range(0, len(lines)):
            lines[i] = ""

    # Rebuild the show string after aligning the columns.
    show_string = (
        lines[0]
        + "\n"
        + show_string_columns
        + "\n"
        + lines[2]
        + "\n"
        + "\n".join(corrected_lines)
    )
    length_per_column = [
        len(cell) for cell in show_string.split("\n")[1].split("|")[1:-1]
    ]
    min_number_of_spaces_per_column = length_per_column.copy()
    string_io = io.StringIO(show_string)
    for line in string_io:
        if not line.startswith("|"):
            continue
        for j, cell in enumerate(line.split("|")[1:-1]):
            match = re.match(r"^( *)", cell)
            if match is not None:
                min_number_of_spaces_per_column[j] = min(
                    min_number_of_spaces_per_column[j],
                    len(match.group(1)),
                )

    # Reset the StringIO object to loop back over the string and remove extraneous spaces.
    string_io.seek(0)

    # Spark will always show at least 3 character width for each column.
    min_cell_width = 3
    final_show_string = ""
    for i, line in enumerate(string_io):
        # The first, third, and last lines are rebuilt here.
        if i in [0, 2, len(show_string.split("\n")) - 2]:
            # Subtract the number of spaces from the line length.
            final_show_string += (
                "+"
                + "+".join(
                    [
                        "-"
                        * max(
                            length_per_column[j] - min_number_of_spaces_per_column[j],
                            min_cell_width,
                        )
                        for j in range(len(length_per_column))
                    ]
                )
                + "+\n"
            )
            continue
        else:
            final_show_string += "|" + "|".join(
                [
                    cell[
                        min(
                            min_number_of_spaces_per_column[j],
                            len(cell) - min_cell_width,
                        ) :
                    ]
                    for j, cell in enumerate(line.split("|")[1:-1])
                ]
            )
            final_show_string += "|\n"
    if rel.show_string.num_rows < input_df.count():
        final_show_string += f"only showing top {rel.show_string.num_rows} rows\n"
    return pandas.DataFrame({"show_string": [final_show_string]})
