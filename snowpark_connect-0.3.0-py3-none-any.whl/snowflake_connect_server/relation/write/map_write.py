import pyspark.sql.connect.proto.base_pb2 as proto_base
import pyspark.sql.connect.proto.commands_pb2 as commands_proto
from snowflake import snowpark

from snowflake.snowpark._internal.analyzer.analyzer_utils import unquote_if_quoted
from snowflake.snowpark.functions import col, lit, object_construct
from snowflake_connect_server.config import str_to_bool
from snowflake_connect_server.relation.io_utils import is_cloud_path
from snowflake_connect_server.relation.map_relation import map_relation
from snowflake_connect_server.relation.stage_locator import get_paths_from_stage
from snowflake_connect_server.relation.utils import random_string
from snowflake_connect_server.utils.telemetry import NotImplementedErrorWithTelemetry


def get_param_from_options(params, options, source):
    match source:
        case "csv":
            params["format_type_options"]["FILE_EXTENSION"] = source
            if "header" in options:
                params["header"] = str_to_bool(options["header"])
            params["single"] = False
        case "json":
            params["format_type_options"]["FILE_EXTENSION"] = source
        case "parquet":
            params["header"] = True

    if (
        source in ("csv", "parquet", "json") and "nullValue" in options
    ):  # TODO: Null value handling if not specified
        params["format_type_options"]["NULL_IF"] = options["nullValue"]


def map_write(request: proto_base.ExecutePlanRequest):
    write_op = request.plan.command.write_operation

    write_mode = None
    match write_op.mode:
        case commands_proto.WriteOperation.SaveMode.SAVE_MODE_APPEND:
            write_mode = "append"
        case (commands_proto.WriteOperation.SaveMode.SAVE_MODE_ERROR_IF_EXISTS):
            write_mode = "errorifexists"
        case commands_proto.WriteOperation.SaveMode.SAVE_MODE_OVERWRITE:
            write_mode = "overwrite"
        case commands_proto.WriteOperation.SaveMode.SAVE_MODE_IGNORE:
            write_mode = "ignore"

    input_df: snowpark.DataFrame = map_relation(write_op.input)
    session: snowpark.Session = snowpark.Session.builder.getOrCreate()

    # When saving, we need to use the real names
    if hasattr(input_df, "_column_map"):
        column_map = input_df._column_map

        # TODO(SNOW-1786686): Column naming code will be refactored.
        for column in input_df.columns:
            input_df = input_df.withColumnRenamed(
                column,
                '"'
                + unquote_if_quoted(
                    column_map.get_spark_column_name_from_snowpark_column_name(column)
                )
                + '"',
            )

    match write_op.source:
        case "csv" | "parquet" | "json":
            write_path = get_paths_from_stage(
                [write_op.path],
                session=session,
            )[0]

            temp_file_on_stage = random_string(10, "sas_file_") + f".{write_op.source}"

            parameters = {
                "location": f"{write_path}/{temp_file_on_stage}",
                "file_format_type": write_op.source,
                "format_type_options": {
                    "COMPRESSION": "NONE",
                },
                "overwrite": (
                    write_op.mode
                    == commands_proto.WriteOperation.SaveMode.SAVE_MODE_OVERWRITE
                ),
            }

            rewritten_df = rewrite_df(input_df, write_op.source)

            get_param_from_options(parameters, write_op.options, write_op.source)

            rewritten_df.write.copy_into_location(**parameters)

            if not is_cloud_path(write_op.path):
                snowpark.file_operation.FileOperation(session).get(
                    f"{write_path}/{temp_file_on_stage}", write_op.path
                )
        case _:
            match write_op.table.save_method:
                case (
                    commands_proto.WriteOperation.SaveTable.TableSaveMethod.TABLE_SAVE_METHOD_SAVE_AS_TABLE
                ):
                    input_df.write.saveAsTable(
                        table_name=write_op.table.table_name, mode=write_mode
                    )

                case other:
                    raise NotImplementedErrorWithTelemetry(
                        f"Save command not supported: {other}"
                    )


def rewrite_df(input_df: snowpark.DataFrame, source: str) -> snowpark.DataFrame:
    """
    Rewrite dataframe if needed.
        json: construct the dataframe to 1 column in json format
            1. Append columns which represents the column name
            2. Use object_construct to aggregate the dataframe into 1 column

    """
    if source != "json":
        return input_df

    rand_salt = random_string(10, "_")

    rewritten_df = input_df.with_columns(
        [co + rand_salt for co in input_df.columns],
        [lit(unquote_if_quoted(co)) for co in input_df.columns],
    )

    construct_key_values = []
    for co in input_df.columns:
        construct_key_values.append(col(co + rand_salt))
        construct_key_values.append(col(co))

    return rewritten_df.select(object_construct(*construct_key_values))
