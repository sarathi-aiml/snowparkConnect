import copy

import pandas
import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

from snowflake_connect_server.utils.cache import df_cache_map_get
from snowflake_connect_server.utils.context import (
    get_context,
    get_plan_id_map,
    set_plan_id_map,
)
from snowflake_connect_server.utils.ses_logging import logger
from snowflake_connect_server.utils.telemetry import NotImplementedErrorWithTelemetry


def map_relation(rel: relation_proto.Relation) -> snowpark.DataFrame | pandas.DataFrame:
    """Map a Spark Protobuf Relation message to a Snowpark DataFrame or pandas DataFrame.

    NOTE: We return a pandas DataFrame object when the return value of the operation is a
    scalar value. The client expects these as an Arrow buffer with this return value packed
    into a single cell. Rather than do what Spark does (which is put the data back into
    Spark and then convert it to an Arrow buffer), we leave the value we have already extracted
    from Snowflake here in the TCM as a pandas DataFrame and convert it to an Arrow Buffer.

    Args:
        rel (relation_proto.Relation): The Spark Protobuf Relation message to map.

    Returns:
        snowpark.DataFrame | pandas.DataFrame: The Snowpark DataFrame or pandas DataFrame
        that corresponds to the input Spark Protobuf Relation message.
    """
    # TODO: from snowflake_connect_server.relation import map_extension
    from snowflake_connect_server.relation import (
        map_aggregate,
        map_column_ops,
        map_crosstab,
        map_extension,
        map_join,
        map_local_relation,
        map_map_partitions,
        map_row_ops,
        map_sample_by,
        map_show_string,
        map_sql,
        map_stats,
        map_subquery_alias,
        read,
    )

    # TODO: remove get_context().session_id when we host SAS in Snowflake server
    # Check for cached relation
    cache_entry = df_cache_map_get((get_context("session_id"), rel.common.plan_id))
    if cache_entry is not None:
        return cache_entry

    # If df is not cached, check if we have parsed the plan
    parsed_plan = get_plan_id_map(rel.common.plan_id)
    if parsed_plan is not None:
        result = copy.copy(parsed_plan)
        result._column_map = copy.deepcopy(parsed_plan._column_map)
        return result

    if rel.WhichOneof("rel_type") is not None:
        logger.info(rel.WhichOneof("rel_type").upper())
    else:
        # This happens when the relation is empty, usually because the incoming message
        # type was incorrectly routed here.
        raise NotImplementedErrorWithTelemetry("No Relation Type")

    result: snowpark.DataFrame | pandas.DataFrame
    match rel.WhichOneof("rel_type"):
        case "show_string":
            result = map_show_string.map_show_string(rel)
        case "html_string":
            raise NotImplementedErrorWithTelemetry("HTML_STRING")
        case "read":
            result = read.map_read(rel)
        case "project":
            result = map_column_ops.map_project(rel)
        case "filter":
            result = map_row_ops.map_filter(rel)
        case "limit":
            result = map_row_ops.map_limit(rel)
        case "offset":
            result = map_row_ops.map_offset(rel)
        case "tail":
            result = map_row_ops.map_tail(rel)
        case "join":
            result = map_join.map_join(rel)
        case "as_of_join":
            raise NotImplementedErrorWithTelemetry("AS_OF_JOIN")
        case "deduplicate":
            result = map_row_ops.map_deduplicate(rel)
        case "set_op":
            match rel.set_op.set_op_type:
                case relation_proto.SetOperation.SetOpType.SET_OP_TYPE_INTERSECT:
                    result = map_row_ops.map_intersect(rel)
                case relation_proto.SetOperation.SetOpType.SET_OP_TYPE_UNION:
                    result = map_row_ops.map_union(rel)
                case relation_proto.SetOperation.SetOpType.SET_OP_TYPE_EXCEPT:
                    result = map_row_ops.map_except(rel)
                case other:
                    raise NotImplementedErrorWithTelemetry(f"SET_OP {other}")
        case "sort":
            result = map_column_ops.map_sort(
                rel.sort
            )  # TODO: follow this pattern elsewhere.
        case "drop":
            result = map_column_ops.map_drop(rel)
        case "aggregate":
            match rel.aggregate.group_type:
                case relation_proto.Aggregate.GroupType.GROUP_TYPE_GROUPBY:
                    result = map_aggregate.map_group_by_aggregate(rel)
                case relation_proto.Aggregate.GroupType.GROUP_TYPE_ROLLUP:
                    result = map_aggregate.map_rollup_aggregate(rel)
                case relation_proto.Aggregate.GroupType.GROUP_TYPE_CUBE:
                    result = map_aggregate.map_cube_aggregate(rel)
                case relation_proto.Aggregate.GroupType.GROUP_TYPE_PIVOT:
                    result = map_aggregate.map_pivot_aggregate(rel)
                case other:
                    raise NotImplementedErrorWithTelemetry(f"AGGREGATE {other}")
        case "sql":
            result = map_sql.map_sql(rel)
        case "with_relations":
            raise NotImplementedErrorWithTelemetry("WITH_RELATIONS")
        case "local_relation":
            result = map_local_relation.map_local_relation(rel)
        case "sample":
            result = map_row_ops.map_sample(rel)
        case "range":
            result = map_local_relation.map_range(rel)
        case "subquery_alias":
            result = map_subquery_alias.map_alias(rel)
        case "repartition":
            # TODO: Snowpark df identity transform with annotation
            result = map_relation(rel.repartition.input)
        case "fill_na":
            result = map_row_ops.map_fillna(rel)
        case "drop_na":
            result = map_row_ops.map_dropna(rel)
        case "replace":
            result = map_row_ops.map_replace(rel)
        case "summary":
            result = map_stats.map_summary(rel)
        case "describe":
            result = map_stats.map_describe(rel)
        case "cov":
            result = map_stats.map_cov(rel)
        case "corr":
            result = map_stats.map_corr(rel)
        case "approx_quantile":
            result = map_stats.map_approx_quantile(rel)
        case "crosstab":
            result = map_crosstab.map_crosstab(rel)
        case "freq_items":
            # TODO: Snowpark does not yet support `freqItems`
            raise NotImplementedErrorWithTelemetry("FREQ_ITEMS")
        case "sample_by":
            result = map_sample_by.map_sample_by(rel)
        case "to_df":
            result = map_column_ops.map_to_df(rel)
        case "to_schema":
            result = map_column_ops.map_to_schema(rel)
        case "with_columns_renamed":
            result = map_column_ops.map_with_columns_renamed(rel)
        case "with_columns":
            result = map_column_ops.map_with_columns(rel)
        case "map_partitions":
            result = map_map_partitions.map_map_partitions(rel)
        case "extension":
            result = map_extension.map_extension(rel)
        case "unpivot":
            result = map_column_ops.map_unpivot(rel)
        case other:
            raise NotImplementedErrorWithTelemetry(f"Other Relation {other}")

    if isinstance(result, snowpark.DataFrame):
        set_plan_id_map(rel.common.plan_id, result)
    return result
