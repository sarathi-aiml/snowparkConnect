import random
import string
import time
from typing import Sequence

from snowflake import snowpark
from sqlglot import Expression

import snowflake.snowpark.functions as snowpark_fn
from snowflake_connect_server.column_name_handler import (
    make_column_names_snowpark_compatible,
)

SYMBOLS_MAPPING = {
    "add": "+",
    "sub": "-",
    "mul": "*",
    "div": "/",
    "mod": "%",
}


def get_df_with_partition_row_number(
    df: snowpark.DataFrame, row_number_column_name: str
) -> snowpark.DataFrame:
    """
    Add a row number for each row in each partition for the given df, where
    the df is partition based on all columns.
    For example:
    +---+---+         will become           +---+---+------------+
    | C1| C2|                               | C1| C2| ROW_NUMBER |
    +---+---+                               +---+---+------------+
    |  a|  1|                               |  a|  1|  0         |
    |  a|  1|                               |  a|  1|  1         |
    |  a|  2|                               |  a|  2|  0         |
    |  c|  4|                               |  c|  4|  0         |
    +---+---+                               +---+---+------------+
    """
    row_number_snowpark_column_name = make_column_names_snowpark_compatible(
        [row_number_column_name]
    )[0]
    row_number_snowpark_column = (
        snowpark_fn.row_number()
        .over(
            snowpark.window.Window.partition_by(
                *df._column_map.get_snowpark_columns()
            ).order_by(snowpark_fn.lit(1))
        )
        .alias(row_number_snowpark_column_name)
    )

    df_with_partition_number = df.select(
        *df._column_map.get_snowpark_columns(), row_number_snowpark_column
    )
    return df_with_partition_number


def column_name_generator(expr: Expression) -> str:
    expr_key = expr.key.lower()
    match expr_key:
        case "sqrt" | "floor" | "ceil":
            return f"{expr.key.upper()}({column_name_generator(expr.this)})"
        case "length" | "abs":
            return f"{expr.key.lower()}({column_name_generator(expr.this)})"
        case "pow":
            return f"pow({column_name_generator(expr.this)}, {column_name_generator(expr.expression)})"
        case "ln":
            return f"{expr_key}({column_name_generator(expr.this)})"
        case "log":
            if expr.this.key == "literal":
                return f"LOG{expr.this}({column_name_generator(expr.expression)})"
            else:
                return f"LOG(E(), {column_name_generator(expr.this)})"
        case "add" | "sub" | "mul" | "div" | "mod":
            return f"({column_name_generator(expr.this)} {SYMBOLS_MAPPING[expr_key]} {column_name_generator(expr.expression)})"
        case "paren":
            return f"{column_name_generator(expr.this)}"
        case "anonymous":
            match expr.this:
                case "sin" | "cos" | "tan" | "asin" | "acos" | "atan" | "atan2" | "atanh" | "asinh" | "acosh" | "atanh" | "sinh" | "cosh" | "cot":
                    return f"{expr.this.upper()}({column_name_generator(expr.expressions[0])})"
                case _:
                    # TODO: keep adding cases to support new logics
                    return str(expr)
        case "round":
            if "decimals" not in expr.args:
                decimal = 0
            else:
                decimal = expr.args["decimals"].this
            return f"round({column_name_generator(expr.this)}, {decimal})"
        case "alias":
            return expr.args["alias"].this
        case _:
            # TODO: keep adding cases to support new logics
            return str(expr)


def random_string(
    length: int,
    prefix: str = "",
    suffix: str = "",
    choices: Sequence[str] = string.ascii_lowercase,
) -> str:
    """Our convenience function to generate random string for object names.

    Args:
        length: How many random characters to choose from choices.
            length would be at least 6 for avoiding collision
        prefix: Prefix to add to random string generated.
        suffix: Suffix to add to random string generated.
        choices: A generator of things to choose from.
    """
    random_part = "".join([random.choice(choices) for _ in range(length)]) + str(
        time.time_ns()
    )

    return "".join([prefix, random_part, suffix])
