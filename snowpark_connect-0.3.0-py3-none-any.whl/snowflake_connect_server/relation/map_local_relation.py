import json

import numpy as np
import pyarrow as pa
import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

import snowflake.snowpark.functions as snowpark_fn
from snowflake_connect_server.column_name_handler import (
    build_column_map,
    make_column_names_snowpark_compatible,
)
from snowflake_connect_server.type_mapping import (
    map_json_schema_to_snowpark,
    map_simple_types,
)
from snowflake_connect_server.utils.telemetry import NotImplementedErrorWithTelemetry


def parse_local_relation_schema_string(rel: relation_proto.Relation):
    # schema_str can be a dict, or just a type string, e.g. INTEGER.
    schema_str = rel.local_relation.schema
    assert schema_str
    schema_dict = json.loads(schema_str)
    if isinstance(schema_dict, dict):
        spark_column_names = [field["name"] for field in schema_dict["fields"]]
        new_columns = make_column_names_snowpark_compatible(spark_column_names)

        fields = schema_dict.get("fields", None)
        if fields is not None:
            for i, c in enumerate(new_columns):
                fields[i]["name"] = c
            schema_dict["fields"] = fields
        snowpark_schema = map_json_schema_to_snowpark(schema_dict)
    else:
        # the schema_dict is just a type string without field name.
        spark_column_names = [
            "value"
        ]  # give a default name "value" when no name is provided
        new_columns = make_column_names_snowpark_compatible(spark_column_names)
        snowpark_type = map_simple_types(
            schema_dict
        )  # schema_dict should be a simple type string, like "STRING"

        snowpark_schema = snowpark.types.StructType(
            [
                snowpark.types.StructField(new_columns[0], snowpark_type),
            ]
        )
    return snowpark_schema, spark_column_names, new_columns


def map_pylist_cell_to_python_object(cell, type: pa.lib.DataType):
    """
    Pylist means python list, which comes from pyarrow column.to_pylist(). Pylist is preferred over pandas_df in the
    conversion from pyarrow table to snowpark_df because it keeps more accurate information. E.g., NaN and None are
    untouched in pylist_df, but are both NaN in pandas_df. Though to_pylist may have lower performance when data size is
    large, map_local_relation usually applies to small data size.
    """
    match type:
        case list_type if cell and isinstance(type, pa.lib.ListType):
            return [
                map_pylist_cell_to_python_object(obj, list_type.value_type)
                for obj in cell
            ]
        case map_type if cell and isinstance(type, pa.lib.MapType) and all(
            isinstance(obj, tuple) and len(obj) == 2 for obj in cell
        ):
            # the MapType in arrow becomes list in pylist_df,
            # e.g. {"Car": "Honda", "Bike": "Yamaha"} --> [("Car", "Honda"), ("Bike", "Yamaha")] , and causes some
            # trouble in the following snowpark dataframe creation, which expects MapType but pylist_df only provides
            # list (not dict).
            return {
                map_pylist_cell_to_python_object(
                    k, map_type.key_type
                ): map_pylist_cell_to_python_object(v, map_type.item_type)
                for k, v in cell
            }
        case _:
            return cell


def map_pandas_cell_to_python_object(cell):
    match cell:
        case arr if isinstance(arr, np.ndarray):
            res = [map_pandas_cell_to_python_object(obj) for obj in cell]
        case [*_] if all(isinstance(obj, tuple) and len(obj) == 2 for obj in cell):
            # The conversion from arrow_table to pandas_df loses information. we need to re-think what's the correct way, e.g. skip pandas_df?
            #
            # 1. For the MapType in arrow, it becomes list in pandas_df,
            # e.g. {"Car": "Honda", "Bike": "Yamaha"} --> [("Car", "Honda"), ("Bike", "Yamaha")] , and causes some
            # trouble in the following snowpark dataframe creation, which expects MapType but pandas_df only provides
            # list (not dict).
            #
            # 2. For null in arrow, it becomes nan in pandas_df

            # pyspark MapType becomes a list of tuples with two elements each. Other pyspark type doesn't seem to use list, e.g. ArrayType becomes np.ndarray
            res = {
                map_pandas_cell_to_python_object(k): map_pandas_cell_to_python_object(v)
                for k, v in cell
            }
        case _:
            # Snowpark doesn't accept numpy generic type, e.g. numpy.int32
            res = cell.item() if isinstance(cell, np.generic) else cell
    # when NaN (NaN != NaN), res = None, cause Snowpark doesn't support NaN in Row objects
    return res if res == res else None


def map_local_relation(rel: relation_proto.Relation) -> snowpark.DataFrame:
    if rel.local_relation.HasField("data"):
        data = pa.BufferReader(rel.local_relation.data)
        with pa.ipc.open_stream(data) as reader:
            batches = [batch for batch in reader]
            table = pa.Table.from_batches(batches)
        session = snowpark.Session.builder.getOrCreate()
        if rel.local_relation.schema == "":
            snowpark_schema = {}
            spark_column_names = table.column_names
            new_columns = make_column_names_snowpark_compatible(spark_column_names)
        else:
            (
                snowpark_schema,
                spark_column_names,
                new_columns,
            ) = parse_local_relation_schema_string(rel)
        # Snowpark ignores the schema when you pass in a pandas DataFrame, so
        # unfortunately we have to convert it to a list of tuples and pass the schema
        # so that Snowpark respects this schema. This is particularly problematic for
        # array type columns, which always because variants due to the conversion from
        # pandas "object" dtype.
        if snowpark_schema == {}:
            # TODO: we should use pylist here too and we need to get snowpark schema from pyarrow table schema
            pandas_df = table.to_pandas()
            snowpark_df: snowpark.DataFrame = session.create_dataframe(pandas_df)
        else:
            pylist_df = [
                list(row)
                for row in zip(*(col.to_pylist() for col in table.itercolumns()))
            ]
            data_for_snowpark = [
                snowpark.Row(
                    **dict(
                        zip(
                            new_columns,
                            [
                                (
                                    map_pylist_cell_to_python_object(
                                        cell, table.schema.types[i]
                                    )
                                )
                                for i, cell in enumerate(row)
                            ],
                        )
                    )
                )
                for row in pylist_df
            ]
            snowpark_df: snowpark.DataFrame = session.create_dataframe(
                data_for_snowpark,
                snowpark_schema,
            )
        return build_column_map(snowpark_df, spark_column_names)
    elif rel.local_relation.HasField("schema") and rel.local_relation.schema != "":
        (
            snowpark_schema,
            spark_column_names,
            new_columns,
        ) = parse_local_relation_schema_string(rel)

        session = snowpark.Session.builder.getOrCreate()
        snowpark_df: snowpark.DataFrame = session.create_dataframe(
            [],
            snowpark_schema,
        )
        return build_column_map(snowpark_df, spark_column_names)
    else:
        raise NotImplementedErrorWithTelemetry(
            "LocalRelation without data & schema is not supported"
        )


def map_range(rel: relation_proto.Relation) -> snowpark.DataFrame:
    session = snowpark.Session.builder.getOrCreate()
    params_df = session.create_dataframe(
        [(rel.range.start, rel.range.end, rel.range.step)],
        ["RANGE_START", "RANGE_END", "RANGE_STEP"],
    )
    snowpark_name = "ID"
    spark_name = "id"
    # We have to use this approach because explode does not accept the result
    # of the array_generate_range function.
    result = (
        params_df.select(
            snowpark_fn.array_generate_range(
                "RANGE_START", "RANGE_END", "RANGE_STEP"
            ).alias(snowpark_name)
        )
        .select(snowpark_fn.explode(snowpark_name).alias(snowpark_name))
        .select(
            snowpark_fn.cast(snowpark_name, snowpark.types.LongType()).as_(
                snowpark_name
            )
        )
    )
    return build_column_map(result, [spark_name])
