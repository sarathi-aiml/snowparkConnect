import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

from snowflake_connect_server.column_name_handler import ColumnNameMap, build_column_map
from snowflake_connect_server.config import global_config
from snowflake_connect_server.error.error_utils import SparkException
from snowflake_connect_server.expression.map_expression import map_expression
from snowflake_connect_server.relation.map_relation import map_relation
from snowflake_connect_server.utils.telemetry import NotImplementedErrorWithTelemetry


def map_join(rel: relation_proto.Relation) -> snowpark.DataFrame:
    using_columns = rel.join.using_columns
    if len(using_columns) > 0:
        raise NotImplementedErrorWithTelemetry("Using columns in Join is not supported")
    left_input: snowpark.DataFrame = map_relation(rel.join.left)
    right_input: snowpark.DataFrame = map_relation(rel.join.right)

    match rel.join.join_type:
        case relation_proto.Join.JOIN_TYPE_UNSPECIFIED:
            # TODO: Understand what UNSPECIFIED Join type is
            raise NotImplementedErrorWithTelemetry("Unspecified Join Type")
        case relation_proto.Join.JOIN_TYPE_INNER:
            join_type = "inner"
        case relation_proto.Join.JOIN_TYPE_FULL_OUTER:
            join_type = "full_outer"
        case relation_proto.Join.JOIN_TYPE_LEFT_OUTER:
            join_type = "left"
        case relation_proto.Join.JOIN_TYPE_RIGHT_OUTER:
            join_type = "right"
        case relation_proto.Join.JOIN_TYPE_LEFT_ANTI:
            join_type = "leftanti"
        case relation_proto.Join.JOIN_TYPE_LEFT_SEMI:
            join_type = "leftsemi"
        case relation_proto.Join.JOIN_TYPE_CROSS:
            join_type = "cross"
        case other:
            raise NotImplementedErrorWithTelemetry(f"Other Join Type: {other}")

    # We are building a dictionary here to map the Spark column names to the Snowpark
    # names. Because there can be collisions in the column names, we need to handle
    # those cases by passing a plan_id in the map to Expression mapper.
    spark_columns_dictionary = dict()
    for left_spark_col in left_input._column_map.get_spark_columns():
        if left_spark_col not in right_input._column_map.get_spark_columns():
            # Two level mapping with plan_id is not necessary to disambiguate between same name columns
            snowpark_col: str = (
                left_input._column_map.get_snowpark_column_name_from_spark_column_name(
                    left_spark_col
                )
            )
            spark_columns_dictionary[left_spark_col] = snowpark_col
        else:
            # Two level mapping with plan_id IS necessary to disambiguate between same name columns
            by_plan_columns_map = dict()
            left_snowpark_col: str = (
                left_input._column_map.get_snowpark_column_name_from_spark_column_name(
                    left_spark_col
                )
            )
            by_plan_columns_map[rel.join.left.common.plan_id] = left_snowpark_col
            right_snowpark_col: str = (
                right_input._column_map.get_snowpark_column_name_from_spark_column_name(
                    left_spark_col
                )
            )
            by_plan_columns_map[rel.join.right.common.plan_id] = right_snowpark_col
            # Second level map by plan_ids to disambiguate between same name columns
            spark_columns_dictionary[left_spark_col] = by_plan_columns_map
    for right_spark_col in right_input._column_map.get_spark_columns():
        # We already added columns from the right DF that were common with the left DF above.
        if right_spark_col not in left_input._column_map.get_spark_columns():
            snowpark_col: str = (
                right_input._column_map.get_snowpark_column_name_from_spark_column_name(
                    right_spark_col
                )
            )
            spark_columns_dictionary[right_spark_col] = snowpark_col

    if rel.join.HasField("join_condition"):
        _, join_expression = map_expression(
            rel.join.join_condition,
            column_mapping=ColumnNameMap(
                list(spark_columns_dictionary.keys()),
                list(spark_columns_dictionary.values()),
            ),
        )
        result: snowpark.DataFrame = left_input.join(
            right=right_input,
            on=join_expression,
            how=join_type,
        )
    else:
        if join_type == "cross" or (
            hasattr(global_config, "spark_sql_crossJoin_enabled")
            and global_config.spark_sql_crossJoin_enabled
        ):
            result: snowpark.DataFrame = left_input.crossJoin(right_input)
        else:
            raise SparkException.implicit_cartesian_product("inner")

    # Add Spark columns and plan_ids from left DF
    spark_cols_after_join: list[str] = list(left_input._column_map.get_spark_columns())
    # Add Spark columns and plan_ids from right DF
    spark_cols_after_join.extend(right_input._column_map.get_spark_columns())

    return build_column_map(
        result,
        spark_cols_after_join,
    )
