import socket

import pandas
import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

from snowflake_connect_server.column_name_handler import build_column_map
from snowflake_connect_server.utils.telemetry import NotImplementedErrorWithTelemetry

# Full data is used at the moment to store all the data that has been read
# from the socket. This is a temporary solution for demonstration purposes
# and not scalable.
# TODO: Use a stage in Snowflake to store the data.
full_data = b""


def map_read_socket(
    rel: relation_proto.Relation,
    session: snowpark.Session,
    options: dict[str, str],
) -> snowpark.DataFrame:
    if rel.read.is_streaming is True:
        global full_data
        host = options.get("host", None)
        port = options.get("port", None)
        if not host or not port:
            raise ValueError("Host and port must be provided in options.")
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.connect((host, int(port)))
                data = s.recv(1024)
                full_data += data
                while data:
                    s.settimeout(1.25)
                    try:
                        data = s.recv(1024)
                        full_data += data
                    except socket.timeout:
                        break
                s.settimeout(None)
                dataframe_data = full_data.decode("utf-8")
                spark_cname = "value"
                df = session.create_dataframe(
                    pandas.DataFrame({spark_cname: dataframe_data.split("\n")})
                ).rename({f'"{spark_cname}"': spark_cname.upper()})
                return build_column_map(df, [spark_cname])
            except OSError as e:
                raise Exception(f"Error connecting to {host}:{port} - {e}")
    else:
        raise NotImplementedErrorWithTelemetry(
            "Socket reads are only supported in streaming mode."
        )
