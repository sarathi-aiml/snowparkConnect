from snowflake import snowpark

from snowflake.snowpark._internal.analyzer import analyzer_utils


def rename_columns_as_snowflake_standard(df: snowpark.DataFrame) -> snowpark.DataFrame:
    if df.columns is None or len(df.columns) == 0:
        return df
    return df.select(
        *[
            df.col(df.columns[i]).alias(
                f"{analyzer_utils.unquote_if_quoted(df.columns[i])}-{i}"
            )
            for i in range(len(df.columns))
        ]
    )
