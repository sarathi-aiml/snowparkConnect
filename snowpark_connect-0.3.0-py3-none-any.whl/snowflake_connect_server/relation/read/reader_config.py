from copy import copy
from typing import Any

from snowflake_connect_server.config import GlobalConfig


class ReaderConfig(GlobalConfig):

    default_global_config = {
        # TODO: Snowpark does not support mode argument
        # "mode": "PERMISSIVE",
        # TODO: Snowpark does not support locale argument
        # "locale": "en-US",
        "compression": "none",
    }

    boolean_config_list = []

    int_config_list = []

    float_config_list = []

    def __init__(self, options: dict[str, str]) -> None:
        super().__init__()
        for key, value in options.items():
            self.set(key, value)

    def convert_to_snowpark_args(self) -> dict[str, Any]:
        snowpark_config = copy(self.global_config)

        for key in snowpark_config.keys():
            snowpark_config[key] = super()._get_config_setting(key)
        return snowpark_config


class CsvReaderConfig(ReaderConfig):

    default_global_config = dict(
        ReaderConfig.default_global_config,
        **{
            "header": "false",
            "inferSchema": "true",
            "delimiter": ",",
            "quote": '"',
            "comment": "#",
            "nullValue": "",
            # TODO: Snowpark does not support NaN value argument.
            # "nanValue": "NaN",
            "dateFormat": "yyyy-MM-dd",
            "timestampFormat": "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
            # TODO: Snowpark does not support maxColumns argument
            # "maxColumns": "20480",
            # TODO: Snowpark does not support maxCharsPerColumn argument
            # "maxCharsPerColumn": "1000000",
            # TODO: Snowpark does not support maxMalformedLogPerPartition argument
            # "maxMalformedLogPerPartition": "10",
            "charset": "UTF-8",
            # TODO: Snowpark does not support multiLine argument
            # "multiLine": "false",
            # TODO: Snowpark does not support ignoreLeadingWhiteSpace argument
            # "ignoreLeadingWhiteSpace": "false",
            # TODO: Snowpark does not support ignoreTrailingWhiteSpace argument
            # "ignoreTrailingWhiteSpace": "false",
            # TODO: Snowpark does not support samplingRatio argument
            # "samplingRatio": "1.0",
            # TODO: Snowpark does not support emptyValue argument
            # "emptyValue": "",
            "lineSep": "\n",
            "sep": ",",
            # TODO: Snowpark does not support escapeQuotes argument
            # "escapeQuotes": "true",
            # TODO: Snowpark does not support quoteAll argument
            # "quoteAll": "false",
        }
    )

    boolean_config_list = ReaderConfig.boolean_config_list + [
        "header",
        "inferSchema",
        "multiLine",
        "ignoreLeadingWhiteSpace",
        "ignoreTrailingWhiteSpace",
        "escapeQuotes",
        "quoteAll",
    ]

    int_config_list = ReaderConfig.int_config_list + [
        "maxColumns",
        "maxCharsPerColumn",
        "maxMalformedLogPerPartition",
    ]

    float_config_list = ReaderConfig.float_config_list + ["samplingRatio"]

    def __init__(self, options: dict[str, str]) -> None:
        super().__init__(options)

    def convert_to_snowpark_args(self) -> dict[str, Any]:
        renamed_args = {
            "charset": "ENCODING",
            "inferSchema": "INFER_SCHEMA",
            "delimiter": "FIELD_DELIMITER",
            "quote": "FIELD_OPTIONALLY_ENCLOSED_BY",
            "nullValue": "NULL_IF",
            "dateFormat": "DATE_FORMAT",
            "timestampFormat": "TIMESTAMP_FORMAT",
            "lineSep": "RECORD_DELIMITER",
            "sep": "FIELD_DELIMITER",
            "header": "PARSE_HEADER",
        }
        snowpark_config = super().convert_to_snowpark_args()
        # Rename the keys to match the Snowpark configuration.
        for spark_arg, snowpark_arg in renamed_args.items():
            if spark_arg not in snowpark_config:
                continue
            snowpark_config[snowpark_arg] = snowpark_config[spark_arg]
            del snowpark_config[spark_arg]
        return snowpark_config


class JsonReaderConfig(ReaderConfig):

    default_global_config = dict(
        ReaderConfig.default_global_config,
        **{
            # TODO: primitivesAsString: Union[bool, str, None] = None,
            # TODO: prefersDecimal: Union[bool, str, None] = None,
            # TODO: allowComments: Union[bool, str, None] = None,
            # TODO: allowUnquotedFieldNames: Union[bool, str, None] = None,
            # TODO: allowSingleQuotes: Union[bool, str, None] = None,
            # TODO: allowNumericLeadingZero: Union[bool, str, None] = None,
            # TODO: allowBackslashEscapingAnyCharacter: Union[bool, str, None] = None,
            # TODO: columnNameOfCorruptRecord: Optional[str] = None,
            "dateFormat": "auto",
            "timestampFormat": "auto",
            # TODO: multiLine: Union[bool, str, None] = None,
            # TODO: allowUnquotedControlChars: Union[bool, str, None] = None,
            # TODO: lineSep: Optional[str] = None,
            # TODO: samplingRatio: Union[str, float, None] = None,
            # TODO: dropFieldIfAllNull: Union[bool, str, None] = None,
            # TODO: encoding: Optional[str] = None,
            # TODO: pathGlobFilter: Union[bool, str, None] = None,
            # TODO: recursiveFileLookup: Union[bool, str, None] = None,
            # TODO: modifiedBefore: Union[bool, str, None] = None,
            # TODO: modifiedAfter: Union[bool, str, None] = None,
            # TODO: allowNonNumericNumbers: Union[bool, str, None] = None,
        }
    )

    boolean_config_list = ReaderConfig.boolean_config_list + []

    int_config_list = ReaderConfig.int_config_list + []

    float_config_list = ReaderConfig.float_config_list + ["samplingRatio"]

    def __init__(self, options: dict[str, str]) -> None:
        super().__init__(options)

    def convert_to_snowpark_args(self) -> dict[str, Any]:
        renamed_args = {
            "charset": "ENCODING",
            "inferSchema": "INFER_SCHEMA",
            "dateFormat": "DATE_FORMAT",
            "timestampFormat": "TIMESTAMP_FORMAT",
        }
        snowpark_config = super().convert_to_snowpark_args()
        # Rename the keys to match the Snowpark configuration.
        for spark_arg, snowpark_arg in renamed_args.items():
            if spark_arg not in snowpark_config:
                continue
            snowpark_config[snowpark_arg] = snowpark_config[spark_arg]
            del snowpark_config[spark_arg]
        return snowpark_config
