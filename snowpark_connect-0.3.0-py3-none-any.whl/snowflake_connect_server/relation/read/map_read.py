import json

import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

from snowflake_connect_server.relation.io_utils import is_cloud_path
from snowflake_connect_server.relation.read.map_read_table import map_read_table
from snowflake_connect_server.relation.read.reader_config import (
    CsvReaderConfig,
    JsonReaderConfig,
    ReaderConfig,
)
from snowflake_connect_server.relation.stage_locator import get_paths_from_stage
from snowflake_connect_server.type_mapping import map_json_schema_to_snowpark
from snowflake_connect_server.utils.telemetry import NotImplementedErrorWithTelemetry


def map_read(
    rel: relation_proto.Relation,
) -> snowpark.DataFrame:
    """
    Read a file into a Snowpark DataFrame.

    Currently, the supported read formats are `csv`, `json` and `parquet`.
    """
    match rel.read.WhichOneof("read_type"):
        case "named_table":
            return map_read_table(rel)

        case "data_source":
            if rel.read.data_source.HasField("format"):
                format = rel.read.data_source.format
            else:
                # TODO: This should come from the config `spark.sql.sources.default`
                format = None
            if rel.read.data_source.schema == "":
                schema = None
            else:
                try:
                    parsed_schema = json.loads(rel.read.data_source.schema)
                except json.JSONDecodeError:
                    # It's a DDL-formatted string. e.g. "a INT, b DOUBLE"
                    parsed_schema = {"fields": [], "type": "struct"}
                    for field in rel.read.data_source.schema.split(","):
                        name_and_type = field.split()
                        assert (
                            len(name_and_type) == 2
                        ), f"Schema's definition {name_and_type} is invalid"
                        parsed_schema["fields"].append(
                            {
                                "name": name_and_type[0],
                                "nullable": True,
                                "type": name_and_type[1],
                            }
                        )
                schema = map_json_schema_to_snowpark(parsed_schema)
            options = dict(rel.read.data_source.options)
            session: snowpark.Session = snowpark.Session.builder.getOrCreate()
            if len(rel.read.data_source.paths) > 0:
                paths = get_paths_from_stage(
                    list(rel.read.data_source.paths),
                    session,
                )

                upload_files_if_needed(paths, list(rel.read.data_source.paths), session)

                match format:
                    case "csv":
                        from snowflake_connect_server.relation.read.map_read_csv import (
                            map_read_csv,
                        )

                        return map_read_csv(
                            rel, schema, session, paths, CsvReaderConfig(options)
                        )
                    case "json":
                        from snowflake_connect_server.relation.read.map_read_json import (
                            map_read_json,
                        )

                        return map_read_json(
                            rel, schema, session, paths, JsonReaderConfig(options)
                        )
                    case "parquet":
                        from snowflake_connect_server.relation.read.map_read_parquet import (
                            map_read_parquet,
                        )

                        return map_read_parquet(
                            rel, schema, session, paths, ReaderConfig(options)
                        )
                    case _:
                        raise NotImplementedErrorWithTelemetry(
                            f"Unsupported format: {format}"
                        )
            else:
                match format:
                    case "socket":
                        from snowflake_connect_server.relation.read.map_read_socket import (
                            map_read_socket,
                        )

                        return map_read_socket(rel, session, options)
                    case other:
                        raise NotImplementedErrorWithTelemetry(
                            f"UNSUPPORTED FORMAT {other} WITH NO PATH"
                        )
        case other:
            # TODO: Empty data source
            raise NotImplementedErrorWithTelemetry(f"Unsupported read type: {other}")


def upload_files_if_needed(
    target_paths, source_paths, session: snowpark.Session
) -> None:
    n = len(source_paths)
    assert n == len(target_paths), "Source and target paths must have same length"
    for i in range(n):
        if not is_cloud_path(source_paths[i]):  # Upload local file
            session.file.put(source_paths[i], target_paths[i], auto_compress=False)
