import re

import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

from snowflake.snowpark._internal.analyzer import analyzer_utils
from snowflake_connect_server.column_name_handler import build_column_map
from snowflake_connect_server.relation.read.map_read import CsvReaderConfig
from snowflake_connect_server.relation.read.utils import (
    rename_columns_as_snowflake_standard,
)
from snowflake_connect_server.utils.telemetry import NotImplementedErrorWithTelemetry


def map_read_csv(
    rel: relation_proto.Relation,
    schema: snowpark.types.StructType | None,
    session: snowpark.Session,
    paths: list[str],
    options: CsvReaderConfig,
) -> snowpark.DataFrame:
    """
    Read a CSV file into a Snowpark DataFrame.

    We leverage the stage that is already created in the map_read function that
    calls this.
    """
    if rel.read.is_streaming is True:
        # TODO: Structured streaming implementation.
        raise NotImplementedErrorWithTelemetry(
            "Streaming is not supported for CSV files."
        )
    else:
        snowpark_options = options.convert_to_snowpark_args()
        if schema is None:
            reader = session.read.options(snowpark_options)
        else:
            reader = session.read.options(snowpark_options).schema(schema)
        df = reader.csv(paths[0])
        if len(paths) > 1:
            # TODO: figure out if this is what Spark does.
            for p in paths[1:]:
                df = df.union_all(session.read.options(snowpark_options).csv(p))

        def subtract_one(match):
            """Spark column names are 0 indexed, Snowpark is 1 indexed."""
            return f"_c{str(int(match.group(2)) - 1)}"

        spark_column_names = [
            analyzer_utils.unquote_if_quoted(
                re.sub(r"(^\"c)(\d+)(\"$)", subtract_one, c)
            )
            for c in df.columns
        ]

        return build_column_map(
            rename_columns_as_snowflake_standard(df), spark_column_names
        )
