import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

from snowflake.snowpark._internal.analyzer.analyzer_utils import unquote_if_quoted
from snowflake_connect_server.column_name_handler import build_column_map


def map_read_table(rel: relation_proto.Relation) -> snowpark.DataFrame:
    """
    Read a table into a Snowpark DataFrame.
    """
    session: snowpark.Session = snowpark.Session.builder.getOrCreate()
    if rel.read.HasField("named_table"):
        df = session.read.table(rel.read.named_table.unparsed_identifier)
        true_names = list(map(lambda x: unquote_if_quoted(x), df.columns))
        return build_column_map(df, true_names)
    else:
        raise ValueError("The relation must have a named_table field.")
