import pyspark.sql.connect.proto.relations_pb2 as relation_proto
from snowflake import snowpark

from snowflake.snowpark._internal.analyzer import analyzer_utils
from snowflake_connect_server.column_name_handler import build_column_map
from snowflake_connect_server.relation.read.map_read import ReaderConfig
from snowflake_connect_server.relation.read.utils import (
    rename_columns_as_snowflake_standard,
)
from snowflake_connect_server.utils.telemetry import NotImplementedErrorWithTelemetry


def map_read_parquet(
    rel: relation_proto.Relation,
    schema: str | None,
    session: snowpark.Session,
    paths: list[str],
    options: ReaderConfig,
) -> snowpark.DataFrame:
    """
    Read a Parquet file into a Snowpark DataFrame.

    We leverage the stage that is already created in the map_read function that
    calls this.
    """
    if rel.read.is_streaming is True:
        # TODO: Structured streaming implementation.
        raise NotImplementedErrorWithTelemetry(
            "Streaming is not supported for Parquet files."
        )
    else:
        snowpark_options = options.convert_to_snowpark_args()
        if schema is not None:
            reader = session.read.options(snowpark_options).schema(schema)
        else:
            reader = session.read.options(snowpark_options)
        df = reader.parquet(paths[0])
        if len(paths) > 1:
            for p in paths[1:]:
                df = df.union_all(reader.parquet(p))

        return build_column_map(
            rename_columns_as_snowflake_standard(df),
            [analyzer_utils.unquote_if_quoted(c) for c in df.columns],
        )
