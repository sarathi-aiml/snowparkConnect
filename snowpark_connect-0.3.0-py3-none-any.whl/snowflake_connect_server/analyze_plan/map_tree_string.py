import pyspark.sql.connect.proto.base_pb2 as proto_base

from snowflake_connect_server.relation.map_relation import map_relation


def map_tree_string(
    request: proto_base.AnalyzePlanRequest,
) -> proto_base.AnalyzePlanResponse:
    # TODO: tracking the difference with pyspark in SNOW-1853347
    tree_string = request.tree_string
    snowpark_df = map_relation(tree_string.plan.root)
    column_map = snowpark_df._column_map

    snowpark_tree_string = snowpark_df._format_schema(
        level=tree_string.level if tree_string.HasField("level") else None,
        translate_columns=column_map.snowpark_column_mapping.to_dict(),
    )
    proto_tree_string = proto_base.AnalyzePlanResponse.TreeString(
        tree_string=snowpark_tree_string,
    )
    return proto_base.AnalyzePlanResponse(
        session_id=request.session_id, tree_string=proto_tree_string
    )
