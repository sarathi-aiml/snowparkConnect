import pyarrow as pa
import pyspark.sql.connect.proto.types_pb2 as types_proto
import pyspark.sql.types
from pyspark.sql.connect.proto import expressions_pb2
from snowflake import snowpark

from snowflake_connect_server.column_name_handler import ColumnNameMap
from snowflake_connect_server.constants import STRUCTURED_TYPES_ENABLED
from snowflake_connect_server.expression.literal import get_literal_field_and_name
from snowflake_connect_server.utils.telemetry import NotImplementedErrorWithTelemetry


def snowpark_to_proto_type(
    data_type: snowpark.types.DataType, column_name_map: ColumnNameMap, depth: int = 0
) -> dict[str, types_proto.DataType]:
    """
    Map a Snowpark data type to a Proto data type.
    """
    match type(data_type):
        case snowpark.types.ArrayType:
            return {
                "array": types_proto.DataType.Array(
                    element_type=types_proto.DataType(
                        **dict(
                            snowpark_to_proto_type(
                                data_type.element_type, column_name_map, depth + 1
                            )
                        )
                    )
                )
            }
        case snowpark.types.BinaryType:
            return {"binary": types_proto.DataType.Binary()}
        case snowpark.types.BooleanType:
            return {"boolean": types_proto.DataType.Boolean()}
        case snowpark.types.DateType:
            return {"date": types_proto.DataType.Date()}
        case snowpark.types.DecimalType:
            return {
                "decimal": types_proto.DataType.Decimal(
                    precision=data_type.precision, scale=data_type.scale
                )
            }
        case snowpark.types.DoubleType:
            return {"double": types_proto.DataType.Double()}
        case snowpark.types.FloatType:
            return {"float": types_proto.DataType.Float()}
        case snowpark.types.IntegerType:
            return {"integer": types_proto.DataType.Integer()}
        case snowpark.types.LongType:
            return {"long": types_proto.DataType.Long()}
        case snowpark.types.NullType:
            return {"null": types_proto.DataType.NULL()}
        case snowpark.types.ShortType:
            return {"showt": types_proto.DataType.Short()}
        case snowpark.types.StringType:
            return {"string": types_proto.DataType.String()}
        case snowpark.types.StructType:
            # For attributes inside struct type (depth > 0), they don't get renamed as normal dataframe column names. Thus no need to do the conversion from snowpark column name to spark column name.
            return {
                "struct": types_proto.DataType.Struct(
                    fields=[
                        types_proto.DataType.StructField(
                            name=column_name_map.get_spark_column_name_from_snowpark_column_name(
                                field.name
                            )
                            if depth == 0
                            else field.name,
                            data_type=types_proto.DataType(
                                **snowpark_to_proto_type(
                                    field.datatype, column_name_map, depth + 1
                                )
                            ),
                            nullable=field.nullable,
                        )
                        for field in data_type.fields
                    ]
                )
            }
        case snowpark.types.TimestampType:
            match data_type.tz:
                case snowpark.types.TimestampTimeZone.NTZ:
                    return {"timestamp_ntz": types_proto.DataType.TimestampNTZ()}
                case _:
                    return {"timestamp": types_proto.DataType.Timestamp()}
        case snowpark.types.VariantType:
            # For now we are returning a string type for variant types.
            return {"string": types_proto.DataType.String()}
        case snowpark.types.MapType:
            return {
                "map": types_proto.DataType.Map(
                    key_type=types_proto.DataType(
                        **snowpark_to_proto_type(
                            data_type.key_type, column_name_map, depth + 1
                        )
                    ),
                    value_type=types_proto.DataType(
                        **snowpark_to_proto_type(
                            data_type.value_type, column_name_map, depth + 1
                        )
                    ),
                )
            }
        case _:
            raise NotImplementedErrorWithTelemetry(
                f"Unsupported snowpark data type: {data_type}"
            )


def proto_to_snowpark_type(
    data_type: types_proto.DataType,
) -> snowpark.types.DataType:
    """
    Map a Proto data type to a Snowpark data type.
    """
    match data_type.WhichOneof("kind"):
        case "array":
            return snowpark.types.ArrayType(
                proto_to_snowpark_type(data_type.array.element_type),
                structured=STRUCTURED_TYPES_ENABLED,
            )
        case "map":
            # TODO: When Snowpark MapType supports nullable, we can get it from proto by `data_type.map.value_contains_null`. The property is ignored now.
            return snowpark.types.MapType(
                key_type=proto_to_snowpark_type(data_type.map.key_type),
                value_type=proto_to_snowpark_type(data_type.map.value_type),
                structured=STRUCTURED_TYPES_ENABLED,
            )
        case "struct":
            return snowpark.types.StructType(
                [
                    snowpark.types.StructField(
                        # NOTE: The column names are not mapped to the Spark column names here.
                        field.name,
                        proto_to_snowpark_type(field.data_type),
                        field.nullable,
                    )
                    for field in data_type.struct.fields
                ],
                structured=STRUCTURED_TYPES_ENABLED,
            )
        case _:
            return map_simple_types(data_type.WhichOneof("kind"))


def map_snowpark_types_to_pyarrow_types(
    snowpark_type: snowpark.types.DataType,
) -> pa.lib.DataType:
    """
    Map a Snowpark data type to a pyarrow data type.
    """
    match type(snowpark_type):
        case snowpark.types.ArrayType:
            return pa.list_(
                map_snowpark_types_to_pyarrow_types(snowpark_type.element_type)
            )
        case snowpark.types.BinaryType:
            return pa.binary()
        case snowpark.types.BooleanType:
            return pa.bool_()
        case snowpark.types.DateType:
            return pa.date64()
        case snowpark.types.DecimalType:
            return pa.decimal128(snowpark_type.precision, snowpark_type.scale)
        case snowpark.types.DoubleType:
            return pa.float64()
        case snowpark.types.FloatType:
            return pa.float32()
        case snowpark.types.IntegerType:
            return pa.int32()
        case snowpark.types.LongType:
            return pa.int64()
        case snowpark.types.MapType:
            return pa.map_(
                key_type=map_snowpark_types_to_pyarrow_types(snowpark_type.key_type),
                item_type=map_snowpark_types_to_pyarrow_types(snowpark_type.value_type),
            )
        case snowpark.types.NullType:
            return pa.null()
        case snowpark.types.ShortType:
            return pa.int16()
        case snowpark.types.StringType:
            return pa.string()
        case snowpark.types.StructType:
            return pa.struct(
                fields=[
                    pa.field(
                        field.name,
                        map_snowpark_types_to_pyarrow_types(field.datatype),
                        nullable=field.nullable,
                    )
                    for field in snowpark_type.fields
                ]
            )
        case snowpark.types.TimestampType:
            return pa.timestamp()
        case _:
            raise NotImplementedErrorWithTelemetry(
                f"Unsupported snowpark data type: {snowpark_type}"
            )


def map_pyspark_types_to_snowpark_types(
    type_to_map: pyspark.sql.types.DataType,
) -> snowpark.types.DataType:
    """
    Map a PySpark data type to a Snowpark data type.

    This function is used to map the data types of columns in a PySpark DataFrame
    to the data types used in Snowpark. This is used in, for example, UDFs, where
    the client passes a serialized version of the client type (which will be a Pyspark
    type) and we need to map this to the Snowpark type.
    """
    if isinstance(type_to_map, pyspark.sql.types.ArrayType):
        return snowpark.types.ArrayType(
            map_pyspark_types_to_snowpark_types(type_to_map.elementType),
            structured=STRUCTURED_TYPES_ENABLED,
        )
    if isinstance(type_to_map, pyspark.sql.types.BinaryType):
        return snowpark.types.BinaryType()
    if isinstance(type_to_map, pyspark.sql.types.BooleanType):
        return snowpark.types.BooleanType()
    if isinstance(type_to_map, pyspark.sql.types.DateType):
        return snowpark.types.DateType()
    if isinstance(type_to_map, pyspark.sql.types.DecimalType):
        return snowpark.types.DecimalType()
    if isinstance(type_to_map, pyspark.sql.types.DoubleType):
        return snowpark.types.DoubleType()
    if isinstance(type_to_map, pyspark.sql.types.FloatType):
        return snowpark.types.FloatType()
    if isinstance(type_to_map, pyspark.sql.types.IntegerType):
        return snowpark.types.IntegerType()
    if isinstance(type_to_map, pyspark.sql.types.LongType):
        return snowpark.types.LongType()
    if isinstance(type_to_map, pyspark.sql.types.MapType):
        # TODO: When Snowpark MapType supports nullable, we can get it from pyspark by `type_to_map.valueContainsNull`. The property is ignored now.
        return snowpark.types.MapType(
            key_type=map_pyspark_types_to_snowpark_types(type_to_map.keyType),
            value_type=map_pyspark_types_to_snowpark_types(type_to_map.valueType),
            structured=STRUCTURED_TYPES_ENABLED,
        )
    if isinstance(type_to_map, pyspark.sql.types.NullType):
        return snowpark.types.NullType()
    if isinstance(type_to_map, pyspark.sql.types.ShortType):
        return snowpark.types.ShortType()
    if isinstance(type_to_map, pyspark.sql.types.StringType):
        return snowpark.types.StringType()
    if isinstance(type_to_map, pyspark.sql.types.StructType):
        return snowpark.types.StructType(
            [
                snowpark.types.StructField(
                    field.name,
                    map_pyspark_types_to_snowpark_types(field.dataType),
                    field.nullable,
                )
                for field in type_to_map.fields
            ],
            structured=STRUCTURED_TYPES_ENABLED,
        )
    if isinstance(type_to_map, pyspark.sql.types.TimestampType):
        return snowpark.types.TimestampType()
    raise NotImplementedErrorWithTelemetry(
        f"Unsupported spark data type: {type_to_map}"
    )


def map_snowpark_to_pyspark_types(
    type_to_map: snowpark.types.DataType,
) -> pyspark.sql.types.DataType:
    """
    Map a Snowpark data type to a PySpark data type.

    This function is used to map the data types of columns in a Snowpark DataFrame
    to the data types used in PySpark. This is used in converting a Snowpark schema
    into the expected JSON schema for LocalRelation.
    """
    if isinstance(type_to_map, snowpark.types.ArrayType):
        return pyspark.sql.types.ArrayType(
            map_snowpark_to_pyspark_types(type_to_map.element_type)
        )
    if isinstance(type_to_map, snowpark.types.BinaryType):
        return pyspark.sql.types.BinaryType()
    if isinstance(type_to_map, snowpark.types.BooleanType):
        return pyspark.sql.types.BooleanType()
    if isinstance(type_to_map, snowpark.types.DateType):
        return pyspark.sql.types.DateType()
    if isinstance(type_to_map, snowpark.types.DecimalType):
        return pyspark.sql.types.DecimalType()
    if isinstance(type_to_map, snowpark.types.DoubleType):
        return pyspark.sql.types.DoubleType()
    if isinstance(type_to_map, snowpark.types.FloatType):
        return pyspark.sql.types.FloatType()
    if isinstance(type_to_map, snowpark.types.IntegerType):
        return pyspark.sql.types.IntegerType()
    if isinstance(type_to_map, snowpark.types.LongType):
        return pyspark.sql.types.LongType()
    if isinstance(type_to_map, snowpark.types.MapType):
        # TODO: when snowpark MapType supports "valueContainsNull", get it from there instead of default to true.
        return pyspark.sql.types.MapType(
            keyType=map_snowpark_to_pyspark_types(type_to_map.key_type),
            valueType=map_snowpark_to_pyspark_types(type_to_map.value_type),
            valueContainsNull=True,
        )
    if isinstance(type_to_map, snowpark.types.NullType):
        return pyspark.sql.types.NullType()
    if isinstance(type_to_map, snowpark.types.ShortType):
        return pyspark.sql.types.ShortType()
    if isinstance(type_to_map, snowpark.types.StringType):
        return pyspark.sql.types.StringType()
    if isinstance(type_to_map, snowpark.types.StructType):
        return pyspark.sql.types.StructType(
            [
                pyspark.sql.types.StructField(
                    field.name,
                    map_snowpark_to_pyspark_types(field.datatype),
                    field.nullable,
                )
                for field in type_to_map.fields
            ]
        )
    if isinstance(type_to_map, snowpark.types.TimestampType):
        return pyspark.sql.types.TimestampType()
    raise NotImplementedErrorWithTelemetry(f"Unsupported data type: {type_to_map}")


def map_simple_types(simple_type: str) -> snowpark.types.DataType:
    """
    Map a simple type string to z Snowpark data type.
    """
    match simple_type.lower():
        case "null":
            return snowpark.types.NullType()
        case "binary":
            return snowpark.types.BinaryType()
        case "boolean":
            return snowpark.types.BooleanType()
        case "byte":
            return snowpark.types.ByteType()
        case "number":
            return snowpark.types.DoubleType()
        case "short":
            return snowpark.types.ShortType()
        case "integer" | "int":
            return snowpark.types.IntegerType()
        case "long":
            return snowpark.types.LongType()
        case "float":
            return snowpark.types.FloatType()
        case "double":
            return snowpark.types.DoubleType()
        case "decimal":
            return snowpark.types.DecimalType()
        case "string":
            return snowpark.types.StringType()
        case "char":
            return snowpark.types.StringType()
        case "var_char":
            return snowpark.types.StringType()
        case "date":
            return snowpark.types.DateType()
        case "timestamp":
            return snowpark.types.TimestampType(snowpark.types.TimestampTimeZone.LTZ)
        case "timestamp_ntz":
            return snowpark.types.TimestampType(snowpark.types.TimestampTimeZone.NTZ)
        case _:
            if simple_type.startswith("decimal"):
                precision = int(simple_type.split("(")[1].split(",")[0])
                scale = int(simple_type.split(",")[1].split(")")[0])
                return snowpark.types.DecimalType(precision, scale)
            raise NotImplementedErrorWithTelemetry(
                f"Unsupported simple type: {simple_type}"
            )


def map_json_schema_to_snowpark(schema: dict | str) -> snowpark.types.StructType:
    """
    Map a JSON schema to a Snowpark schema.

    Because of inconsistencies in how the schema is represented in the JSON,
    we need to handle both the case where the schema is a string and the case
    where it is a dictionary. We have a separate function to handle the string
    case, but it is necessary to handle both cases here because types can be nested
    json objects or strings.
    """
    if isinstance(schema, str):
        return map_simple_types(schema)
    match schema.get("type", None):
        case "struct":
            return snowpark.types.StructType(
                [
                    snowpark.types.StructField(
                        field["name"],
                        map_json_schema_to_snowpark(field["type"]),
                        field.get("nullable", True),
                    )
                    for field in schema["fields"]
                ],
                structured=STRUCTURED_TYPES_ENABLED,
            )
        case "array":
            return snowpark.types.ArrayType(
                map_json_schema_to_snowpark(schema["elementType"]),
                structured=STRUCTURED_TYPES_ENABLED,
            )
        case "map":
            # TODO: pyspark schema["valueContainsNull"] is ignored for now. Snowflake MAP supports this parameter,
            #  `MAP( <key_type> , <value_type> [ NOT NULL ] )`, while snowpark MapType hasn't supported it yet.
            return snowpark.types.MapType(
                key_type=map_json_schema_to_snowpark(schema["keyType"]),
                value_type=map_json_schema_to_snowpark(schema["valueType"]),
                structured=STRUCTURED_TYPES_ENABLED,
            )
        case _:
            return map_simple_types(schema["type"])


def parse_ddl_string(ddl_string: str) -> types_proto.DataType:
    """
    Parse a DDL string and return the Proto data type.

    This function is used to parse a DDL string and return the Proto data type.
    """
    if len(ddl_string.split(" ")) == 1:
        # This case happens when all we get is the type.
        return types_proto.DataType(
            **{
                ddl_string.lower(): list(
                    snowpark_to_proto_type(
                        map_simple_types(ddl_string), ColumnNameMap([], [])
                    ).values()
                )[0]
            }
        )
    fields = []
    for token in ddl_string.split(", "):
        name, datatype = token.split(" ")
        proto_datatype = list(
            snowpark_to_proto_type(
                map_simple_types(datatype), ColumnNameMap([], [])
            ).values()
        )[0]
        fields.append(
            types_proto.DataType.StructField(
                name=name,
                data_type=types_proto.DataType(**{datatype.lower(): proto_datatype}),
                nullable=True,
            )
        )
    return types_proto.DataType(struct=types_proto.DataType.Struct(fields=fields))


def map_spark_timestamp_format_expression(arguments: expressions_pb2.Expression) -> str:
    """
    Converts a Spark date-time format expression to a Snowflake date-time format string.

    :param arguments: Spark date-time format literal expression
    :return: Equivalent Snowflake date-time format string
    """
    match arguments.WhichOneof("expr_type"):
        case "literal":
            lit_value, _ = get_literal_field_and_name(arguments.literal)
            return _map_spark_to_snowflake_timestamp_format(lit_value)
        case other:
            raise NotImplementedErrorWithTelemetry(
                f"Unsupported expression type {other} in timestamp format argument"
            )


def _map_spark_to_snowflake_timestamp_format(spark_format: str) -> str:
    """
    Converts a Spark date-time format string to a Snowflake date-time format string.

    :param spark_format: Spark date-time format string
    :return: Equivalent Snowflake date-time format string
    """
    # Mapping of Spark format to Snowflake format
    format_mapping = {
        "yyyy": "YYYY",  # Year
        "yyy": "YYYY",  # Year
        "yy": "YY",  # 2 Digit Year
        "MM": "MM",  # Month
        "dd": "DD",  # Day
        "HH": "HH24",  # Hour (24-hour format)
        "mm": "MI",  # Minute
        "ss": "SS",  # Second
        "SSS": "FF3",  # Milliseconds (3 fractional digits)
        "XXX": "TZH:TZM",  # Timezone offset in ±HH:MM format
    }

    snowflake_format = spark_format
    for spark, snowflake in format_mapping.items():
        snowflake_format = snowflake_format.replace(spark, snowflake)

    return snowflake_format
