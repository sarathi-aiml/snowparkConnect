from typing import Tuple

import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
from snowflake import snowpark

import snowflake.snowpark.functions as snowpark_fn
from snowflake_connect_server.column_name_handler import ColumnNameMap
from snowflake_connect_server.utils.context import get_alias_map, get_plan_id_map


def map_unresolved_attribute(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
) -> tuple[str, snowpark.Column]:
    attr_name = exp.unresolved_attribute.unparsed_identifier
    if exp.unresolved_attribute.HasField("plan_id"):
        target_df = get_plan_id_map(exp.unresolved_attribute.plan_id)
        assert (
            target_df is not None
        ), f"resolving an attribute of a unresolved dataframe {exp.unresolved_attribute.plan_id}"

        snowpark_name = (
            target_df._column_map.get_snowpark_column_name_from_spark_column_name(
                attr_name
            )
        )
        return (
            attr_name,
            target_df.col(snowpark_name),
        )
    else:
        snowpark_name = column_mapping.get_snowpark_column_name_from_spark_column_name(
            attr_name, allow_non_exists=True
        )
        if snowpark_name is None:
            # check for alias
            (alias_name, col_name) = _parse_spark_column_alias(attr_name)
            if col_name is not None and alias_name in get_alias_map():
                alias_df = get_alias_map()[alias_name]
                snowpark_name = alias_df._column_map.get_snowpark_column_name_from_spark_column_name(
                    col_name
                )
                return col_name, alias_df.col(snowpark_name)
            # Column does not exist. Pass in dummy column name for lazy error throwing.
            snowpark_name = attr_name
        return attr_name, snowpark_fn.col(snowpark_name)


def _parse_spark_column_alias(attr_name: str) -> Tuple[str, str | None]:
    """Parse df_alias.col to (df_alias, col)"""
    # TODO: properly handle alias and column names that contains ` and .
    res = attr_name.split(".")
    if len(res) == 1:
        return res[0], None
    return res[0], res[1]
