import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
from snowflake import snowpark

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark.column import Column
from snowflake_connect_server.column_name_handler import ColumnNameMap
from snowflake_connect_server.expression import (
    map_udf,
    map_unresolved_attribute as map_att,
    map_unresolved_function as map_func,
    map_window_function as map_window_func,
)
from snowflake_connect_server.expression.literal import get_literal_field_and_name
from snowflake_connect_server.relation.map_sql import map_sql_expr
from snowflake_connect_server.type_mapping import proto_to_snowpark_type
from snowflake_connect_server.utils.telemetry import NotImplementedErrorWithTelemetry


def map_alias(
    alias: expressions_proto.Expression.Alias,
    column_mapping: ColumnNameMap,
) -> tuple[str, snowpark.Column]:
    """
    Map an alias expression to a Snowpark expression.

    Args:
        alias (expressions_proto.Expression.Alias): The alias expression to map.
    """
    if len(list(alias.name)) != 1:
        expression_name = map_expression(alias.expr, column_mapping)[0]
        raise ValueError(
            f"Found the unresolved operator: 'Project [{expression_name} AS ({', '.join(list(alias.name))})]'"
        )
    # Spark passes a list for alias name, but it is unclear why since alias
    # can only take a single argument.
    return alias.name[0], map_expression(alias.expr, column_mapping)[1]


def map_expression(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
) -> tuple[str, snowpark.Column]:
    """
    Map an expression to a Snowpark expression.

    Args:
        exp (expressions_proto.Expression): The expression to map.
        column_mapping (ColumnNameMapper): The mapping from column names to Snowpark
            column objects.
    """
    expr_type = exp.WhichOneof("expr_type")
    match expr_type:
        case "unresolved_attribute":
            return map_att.map_unresolved_attribute(exp, column_mapping)
        case "unresolved_extract_value":
            child_name, child_column = map_expression(
                exp.unresolved_extract_value.child, column_mapping
            )
            extract_name, extract_column = map_expression(
                exp.unresolved_extract_value.extraction, column_mapping
            )
            spark_function_name = f"{child_name}[{extract_name}]"
            result_exp = child_column.getItem(Column._to_expr(extract_column).value)
            return spark_function_name, result_exp
        case "unresolved_function":
            return map_func.map_unresolved_function(exp, column_mapping)
        case "literal":
            lit_value, lit_name = get_literal_field_and_name(exp.literal)
            return lit_name, snowpark_fn.lit(lit_value)
        case "window":
            return map_window_func.map_window_function(exp, column_mapping)
        case "alias":
            return map_alias(exp.alias, column_mapping)
        case "unresolved_star":
            return "*", snowpark_fn.col("*")
        case "expression_string":
            return map_sql_expr(exp, column_mapping)
        case "cast":
            match exp.cast.WhichOneof("cast_to_type"):
                case "type":
                    type_to_cast = proto_to_snowpark_type(exp.cast.type)
                case "type_str":
                    type_to_cast = exp.cast.type_str
                case _:
                    raise ValueError("No type to cast to")
            new_name, column = map_expression(exp.cast.expr, column_mapping)
            return new_name, snowpark.functions.cast(column, type_to_cast)
        case "common_inline_user_defined_function":
            return map_udf.map_common_inline_user_defined_udf(exp, column_mapping)
        case _:
            raise NotImplementedErrorWithTelemetry(
                f"Unsupported expression type {expr_type}"
            )
