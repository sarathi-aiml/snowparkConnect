import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
from snowflake import snowpark

import snowflake.snowpark.functions as snowpark_fn
from snowflake.snowpark.types import (
    ArrayType,
    DateType,
    LongType,
    TimestampTimeZone,
    TimestampType,
    VariantType,
)
from snowflake_connect_server.column_name_handler import ColumnNameMap
from snowflake_connect_server.config import global_config
from snowflake_connect_server.expression.literal import get_literal_field_and_name
from snowflake_connect_server.type_mapping import map_spark_timestamp_format_expression
from snowflake_connect_server.utils.telemetry import NotImplementedErrorWithTelemetry

MAX_UINT64 = 2**64 - 1
MIN_INT64 = -(2**63)
SYMBOL_FUNCTIONS = {"<", ">", "<=", ">=", "!=", "+", "-", "*", "/", "%"}


# TODO: fix tz_convert taking 2 positional arguments
# TODO: (this isn't the direct cause but some of the parameters cause the bug)
def get_timestamp_type():
    match global_config["spark.sql.timestampType"]:
        case "TIMESTAMP_LTZ":
            timestamp_type = TimestampType(TimestampTimeZone.LTZ)
        case "TIMESTAMP_NTZ":
            timestamp_type = TimestampType(TimestampTimeZone.NTZ)
        case "TIMESTAMP_TZ":
            timestamp_type = TimestampType(TimestampTimeZone.TZ)
        case _:
            timestamp_type = TimestampType(TimestampTimeZone.DEFAULT)
    return timestamp_type


def unwrap_literal(exp: expressions_proto.Expression):
    """Workaround for Snowpark functions generating invalid SQL when used with fn.lit (SNOW-1871954)"""
    return get_literal_field_and_name(exp.literal)[0]


def map_unresolved_function(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
) -> tuple[str, snowpark.Column]:
    from snowflake_connect_server.expression.map_expression import map_expression

    snowpark_arg_names, snowpark_args = (
        zip(
            *[
                map_expression(arg, column_mapping)
                for arg in exp.unresolved_function.arguments
            ]
        )
        if len(exp.unresolved_function.arguments) > 0
        else ([], [])
    )

    # default function name
    spark_function_name = (
        f"({snowpark_arg_names[0]} {exp.unresolved_function.function_name} {snowpark_arg_names[1]})"
        if exp.unresolved_function.function_name in SYMBOL_FUNCTIONS
        else f"{exp.unresolved_function.function_name}({', '.join(snowpark_arg_names)})"
    )

    function_name = exp.unresolved_function.function_name
    match function_name:
        case "!=":
            result_exp = snowpark_args[0] != snowpark_args[1]
        case "%":
            result_exp = snowpark_args[0] % snowpark_args[1]
        case "*":
            result_exp = snowpark_args[0] * snowpark_args[1]
        case "+":
            result_exp = snowpark_args[0] + snowpark_args[1]
        case "-":
            result_exp = snowpark_args[0] - snowpark_args[1]
        case "/":
            result_exp = snowpark_args[0] / snowpark_args[1]
        case "<":
            result_exp = snowpark_args[0] < snowpark_args[1]
        case "<=":
            result_exp = snowpark_args[0] <= snowpark_args[1]
        case "<=>":
            # eqNullSafe
            spark_function_name = (
                f"({snowpark_arg_names[0]} <=> {snowpark_arg_names[1]})"
            )
            result_exp = snowpark_args[0].eqNullSafe(snowpark_args[1])
        case "==":
            spark_function_name = f"({snowpark_arg_names[0]} = {snowpark_arg_names[1]})"
            result_exp = snowpark_args[0] == snowpark_args[1]
        case ">":
            result_exp = snowpark_args[0] > snowpark_args[1]
        case ">=":
            result_exp = snowpark_args[0] >= snowpark_args[1]
        case "abs":
            result_exp = snowpark_fn.abs(snowpark_args[0])
        case "add_months":
            result_exp = snowpark_fn.add_months(
                snowpark_fn.to_date(snowpark_args[0]), snowpark_args[1]
            )
        case "and":
            spark_function_name = (
                f"({snowpark_arg_names[0]} AND {snowpark_arg_names[1]})"
            )
            result_exp = snowpark_args[0] & snowpark_args[1]
        case "array":
            result_exp = snowpark_fn.array_construct(*snowpark_args)
        case "array_contains":
            result_exp = snowpark_fn.array_contains(snowpark_args[1], snowpark_args[0])
        case "array_intersect":
            result_exp = snowpark_fn.array_intersection(*snowpark_args)
        case "array_sort":
            result_exp = snowpark_fn.array_sort(*snowpark_args)
        case "asc":
            result_exp = snowpark_fn.asc(snowpark_args[0])
        case "avg":
            result_exp = snowpark_fn.avg(snowpark_args[0])
        case "ceil":
            spark_function_name = f"CEIL({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.cast(
                snowpark_fn.ceil(snowpark_args[0]), LongType()
            )
        case "coalesce":
            result_exp = snowpark_fn.coalesce(*snowpark_args)
        case "collect_list":
            result_exp = snowpark_fn.collect_list(*snowpark_args)
        case "collect_set":
            result_exp = snowpark_fn.collect_set(*snowpark_args)
        case "concat":
            result_exp = snowpark_fn.concat(*snowpark_args)
        case "concat_ws":
            result_exp = snowpark_fn.concat_ws(*snowpark_args)
        case "contains":
            result_exp = snowpark_args[0].contains(snowpark_args[1])
        case "count":
            if exp.unresolved_function.is_distinct:
                result_exp = snowpark_fn.count_distinct(*snowpark_args)
                spark_function_name = spark_function_name.replace(
                    "count(", "count(DISTINCT ", 1
                )
            else:
                result_exp = snowpark_fn.count(*snowpark_args)
        case "current_date":
            result_exp = snowpark_fn.current_date()
        case "current_timestamp":
            result_exp = snowpark_fn.cast(
                snowpark_fn.current_timestamp(),
                # TODO: fix tz_convert 2 position arguments bug
                # get_timestamp_type(),
                TimestampType(TimestampTimeZone.NTZ),
            )
        case "date_add":
            result_exp = snowpark_fn.cast(
                snowpark_fn.date_add(*snowpark_args), DateType()
            )
        case "date_format":
            assert (
                len(exp.unresolved_function.arguments) == 2
            ), "date_format takes 2 arguments"
            result_exp = snowpark_fn.date_format(
                snowpark_args[0],
                snowpark_fn.lit(
                    map_spark_timestamp_format_expression(
                        exp.unresolved_function.arguments[1]
                    )
                ),
            )
        case "date_sub":
            result_exp = snowpark_fn.to_date(
                snowpark_fn.date_sub(snowpark_args[0], snowpark_args[1])
            )
        case "date_trunc":
            part = unwrap_literal(exp.unresolved_function.arguments[0])
            result_exp = snowpark_fn.cast(
                snowpark_fn.date_trunc(
                    part, snowpark_fn.to_timestamp(snowpark_args[1])
                ),
                TimestampType(snowpark.types.TimestampTimeZone.NTZ),
            )
        case "datediff":
            result_exp = snowpark_fn.datediff("day", snowpark_args[1], snowpark_args[0])
        case "dayofmonth":
            result_exp = snowpark_fn.dayofmonth(snowpark_fn.to_date(snowpark_args[0]))
        case "dense_rank":
            result_exp = snowpark_fn.dense_rank()
        case "desc":
            result_exp = snowpark_fn.desc(snowpark_args[0])
        case "element_at":
            spark_index = snowpark_args[1]
            data = snowpark_fn.cast(snowpark_args[0], VariantType())
            # handle arrays
            array_exp = snowpark_fn.when(
                spark_index < 0,
                snowpark_fn.element_at(
                    data,
                    snowpark_fn.array_size(snowpark_fn.cast(data, ArrayType()))
                    + spark_index,
                ),
            ).otherwise(snowpark_fn.element_at(data, spark_index - 1))
            # check if array type, otherwise assume it is map type
            result_exp = snowpark_fn.when(
                snowpark_fn.typeof(data) == "ARRAY", array_exp
            ).otherwise(snowpark_fn.element_at(snowpark_args[0], spark_index))
        case "explode":
            result_exp = snowpark_fn.explode(snowpark_args[0])
        case "explode_outer":
            result_exp = snowpark_fn.explode_outer(snowpark_args[0])
        case "floor":
            spark_function_name = f"FLOOR({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.cast(
                snowpark_fn.floor(snowpark_args[0]), LongType()
            )
        case "from_json":
            # TODO: support parsing json with schema
            result_exp = snowpark_fn.parse_json(snowpark_args[0])
        case "from_unixtime":
            assert (
                len(exp.unresolved_function.arguments) == 2
            ), "from_unixtime takes 2 arguments"
            result_exp = snowpark_fn.to_char(
                snowpark_fn.to_timestamp(snowpark_args[0]),
                map_spark_timestamp_format_expression(
                    exp.unresolved_function.arguments[1]
                ),
            )
        case "greatest":
            result_exp = snowpark_fn.greatest(*snowpark_args)
        case "hour":
            result_exp = snowpark_fn.hour(snowpark_fn.to_timestamp(snowpark_args[0]))
        case "in":
            spark_function_name = (
                f"({snowpark_arg_names[0]} IN ({', '.join(snowpark_arg_names[1:])}))"
            )
            result_exp = snowpark_args[0].in_(snowpark_args[1:])
        case "isnan":
            result_exp = snowpark_fn.equal_nan(snowpark_args[0])
        case "isnotnull":
            spark_function_name = f"({snowpark_arg_names[0]} IS NOT NULL)"
            result_exp = snowpark_args[0].isNotNull()
        case "isnull":
            spark_function_name = f"({snowpark_arg_names[0]} IS NULL)"
            result_exp = snowpark_args[0].isNull()
        case "lag":
            offset = unwrap_literal(exp.unresolved_function.arguments[1])
            default = snowpark_args[2] if len(snowpark_args) > 2 else None
            result_exp = snowpark_fn.lag(snowpark_args[0], offset, default)
        case "lead":
            offset = unwrap_literal(exp.unresolved_function.arguments[1])
            default = snowpark_args[2] if len(snowpark_args) > 2 else None
            result_exp = snowpark_fn.lead(snowpark_args[0], offset, default)
        case "length":
            result_exp = snowpark_fn.length(snowpark_args[0])
        case "like":
            result_exp = snowpark_args[0].like(snowpark_args[1])
        case "ln":
            result_exp = snowpark_fn.ln(snowpark_args[0])
        case "log":
            spark_function_name = (
                f"LOG({snowpark_arg_names[0]}, {snowpark_arg_names[1]})"
            )
            result_exp = snowpark_fn.log(snowpark_args[0], snowpark_args[1])
        case "log10":
            spark_function_name = f"LOG10({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.log(10.0, snowpark_args[0])
        case "log1p":
            spark_function_name = f"LOG1P({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.ln(snowpark_args[0] + 1.0)
        case "log2":
            spark_function_name = f"LOG2({snowpark_arg_names[0]})"
            result_exp = snowpark_fn.log(2.0, snowpark_args[0])
        case "lower":
            result_exp = snowpark_fn.lower(snowpark_args[0])
        case "lpad":
            result_exp = snowpark_fn.lpad(*snowpark_args)
        case "map":
            result_exp = snowpark_fn.create_map(*snowpark_args)
        case "max":
            result_exp = snowpark_fn.max(snowpark_args[0])
        case "md5":
            result_exp = snowpark_fn.md5(snowpark_args[0])
        case "mean":
            result_exp = snowpark_fn.avg(snowpark_args[0])
        case "min":
            result_exp = snowpark_fn.min(snowpark_args[0])
        case "monotonically_increasing_id":
            result_exp = snowpark_fn.monotonically_increasing_id()
        case "minute":
            result_exp = snowpark_fn.minute(snowpark_fn.to_timestamp(snowpark_args[0]))
        case "month":
            result_exp = snowpark_fn.month(snowpark_fn.to_date(snowpark_args[0]))
        case "months_between":
            # Pyspark months_between returns a floating point number with a higher precision than Snowpark
            # and has a third optional argument (roundOff: bool = True), which allows to increase the precision even more.
            # The difference is visible after a few decimal places, but in order to have a 100% compatibility, extending the Snowpark's API is required.

            spark_function_name = f"months_between({snowpark_arg_names[0]}, {snowpark_arg_names[1]}, {str(snowpark_arg_names[2]).lower()})"
            result_exp = snowpark_fn.months_between(
                snowpark_fn.cast(snowpark_args[0], get_timestamp_type()),
                snowpark_fn.cast(snowpark_args[1], get_timestamp_type()),
            )
        case "not":
            spark_function_name = f"(NOT {snowpark_arg_names[0]})"
            result_exp = ~snowpark_args[0]
        case "ntile":
            result_exp = snowpark_fn.ntile(snowpark_args[0])
        case "or":
            spark_function_name = (
                f"({snowpark_arg_names[0]} OR {snowpark_arg_names[1]})"
            )
            result_exp = snowpark_args[0] | snowpark_args[1]
        case "rand":
            # Snowpark random() generates a 64 bit signed integer, but pyspark is [0.0, 1.0).
            # TODO: Seems like more validation of the arguments is appropriate.
            args = exp.unresolved_function.arguments
            if len(args) > 0:
                result_exp = snowpark_fn.random(unwrap_literal(args[0]))
            else:
                result_exp = snowpark_fn.random()

            # Adjust from a 64 bit integer to the pyspark range of [0.0, 1.0).
            # The result_exp is a signed int64 number, so the range is [-2**63, 2**63-1]. We add 2**63 (aka subtract
            # MIN_INT64) to shift this number into the range [0, 2**64-1], which is the uint64 range: [0, MAX_UNIT64]
            # However, in the end result, we want the range to exclude 1.0, hence, we divide by MAX_UNIT64 + 1.
            # The float conversion below is necessary, because snowpark python uses int64 for integers, but we are
            # shifting into unit64 and hence are out of the range of int64.
            result_exp = (result_exp - float(MIN_INT64)) / (float(MAX_UINT64) + 1)
        case "rank":
            result_exp = snowpark_fn.rank()
        case "regexp_extract":
            result_exp = snowpark_fn.regexp_extract(
                snowpark_args[0], snowpark_args[1], snowpark_args[2]
            )
        case "regexp_replace":
            spark_function_name = spark_function_name[:-1] + ", 1)"
            result_exp = snowpark_fn.regexp_replace(*snowpark_args)
        case "rlike":
            result_exp = snowpark_args[0].rlike(snowpark_args[1])
        case "round":
            match snowpark_args:
                case [e]:
                    result_exp = snowpark_fn.round(e, 0)
                case [e, scale]:
                    result_exp = snowpark_fn.round(e, scale)
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
        case "row_number":
            result_exp = snowpark_fn.row_number()
        case "second":
            result_exp = snowpark_fn.second(snowpark_fn.to_timestamp(snowpark_args[0]))
        case "size":
            result_exp = snowpark_fn.size(snowpark_args[0])
        case "sort_array":
            sort_asc = unwrap_literal(exp.unresolved_function.arguments[1])
            result_exp = snowpark_fn.sort_array(
                snowpark_args[0],
                sort_ascending=sort_asc,
                nulls_first=sort_asc,
            )
        case "split":
            match snowpark_args:
                case [str_, pattern]:
                    result_exp = snowpark_fn.split(str_, pattern)
                case [str_, pattern, limit]:  # noqa: F841
                    # TODO: limit
                    result_exp = snowpark_fn.split(str_, pattern)
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
        case "struct":
            spark_function_name = "struct"
            result_exp = snowpark_fn.struct(
                *[
                    map_expression(e, column_mapping)[1]
                    for e in exp.unresolved_function.arguments
                ]
            )
        case "substring":
            result_exp = snowpark_fn.substring(*snowpark_args)
        case "sum":
            result_exp = snowpark_fn.sum(snowpark_args[0])
        case "to_date":
            result_exp = snowpark_fn.to_date(*snowpark_args)
        case "to_timestamp":
            match (snowpark_args, exp.unresolved_function.arguments):
                case ([e], _):
                    result_exp = snowpark_fn.to_timestamp(e)
                case ([e, _], [_, fmt]):
                    result_exp = snowpark_fn.to_timestamp(
                        e,
                        snowpark_fn.lit(map_spark_timestamp_format_expression(fmt)),
                    )
                case _:
                    raise ValueError(f"Invalid number of arguments to {function_name}")
            result_exp = snowpark_fn.cast(
                result_exp, TimestampType(snowpark.types.TimestampTimeZone.NTZ)
            )
        case "to_utc_timestamp":
            result_exp = snowpark_fn.cast(
                snowpark_fn.to_utc_timestamp(snowpark_args[0], snowpark_args[1]),
                TimestampType(snowpark.types.TimestampTimeZone.NTZ),
            )
        case "trim":
            result_exp = snowpark_fn.trim(*snowpark_args)
        case "unix_timestamp":
            # unix_timestamp in PySpark has an optional timestamp and optional format string.
            # In Snowpark, the timestamp is not optional.
            # It is observed that the server receives the optional format string if the timestamp is specified,
            # so there are either 0 or 2 arguments.
            match exp.unresolved_function.arguments:
                case []:
                    spark_function_name = (
                        "unix_timestamp(current_timestamp(), yyyy-MM-dd HH:mm:ss)"
                    )
                    result_exp = snowpark_fn.unix_timestamp(_handle_current_timestamp())
                case [_, unresolved_format]:
                    snowpark_timestamp = snowpark_args[0]
                    result_exp = snowpark_fn.unix_timestamp(
                        snowpark_timestamp,
                        snowpark_fn.lit(
                            map_spark_timestamp_format_expression(unresolved_format)
                        ),
                    )
                case _:
                    raise NotImplementedErrorWithTelemetry(
                        "unix_timestamp expected 0 or 2 arguments."
                    )
        case "upper":
            result_exp = snowpark_fn.upper(snowpark_args[0])
        case "when":
            name_components = ["CASE"]
            name_components.append("WHEN")
            name_components.append(snowpark_arg_names[0])
            name_components.append("THEN")
            name_components.append(snowpark_arg_names[1])
            result_exp = snowpark_fn.when(snowpark_args[0], snowpark_args[1])
            for i in range(2, len(snowpark_args), 2):
                if i + 1 >= len(snowpark_args):
                    name_components.append("ELSE")
                    name_components.append(snowpark_arg_names[i])
                    result_exp = result_exp.otherwise(snowpark_args[i])
                else:
                    name_components.append("WHEN")
                    name_components.append(snowpark_arg_names[i])
                    name_components.append("THEN")
                    name_components.append(snowpark_arg_names[i + 1])
                    result_exp = result_exp.when(snowpark_args[i], snowpark_args[i + 1])
            name_components.append("END")
            spark_function_name = " ".join(name_components)
        case "year":
            result_exp = snowpark_fn.year(snowpark_fn.to_date(snowpark_args[0]))
        case other:
            # TODO: Add more here as we come across them.
            # Unfortunately the scope of function names are not documented in
            # the proto file.
            raise NotImplementedErrorWithTelemetry(f"Unsupported function name {other}")

    return spark_function_name, result_exp


def _handle_current_timestamp():
    result_exp = snowpark_fn.cast(
        snowpark_fn.current_timestamp(),
        # TODO: fix tz_convert 2 position arguments bug
        # get_timestamp_type(),
        TimestampType(TimestampTimeZone.NTZ),
    )
    return result_exp
