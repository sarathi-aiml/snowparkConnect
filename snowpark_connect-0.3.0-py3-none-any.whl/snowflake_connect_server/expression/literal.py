import datetime
import decimal
from zoneinfo import ZoneInfo

import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
from tzlocal import get_localzone

from snowflake_connect_server.config import global_config
from snowflake_connect_server.utils.telemetry import NotImplementedErrorWithTelemetry


def get_literal_field_and_name(literal: expressions_proto.Expression.Literal):
    match literal.WhichOneof("literal_type"):
        case "integer":
            return literal.integer, str(literal.integer)
        case "long":
            return literal.long, str(literal.long)
        case "float":
            return (
                literal.float,
                str(literal.float) if literal.float == literal.float else "NaN",
            )
        case "double":
            return literal.double, str(literal.double)
        case "string":
            return literal.string, str(literal.string)
        case "boolean":
            return literal.boolean, str(literal.boolean)
        case "date":
            # Both snowflake and spark Date type don't consider time zones.
            # Don't use datetime.date.fromtimestamp, which depends on local timezone
            date = datetime.datetime.fromtimestamp(
                literal.date * 86400, tz=datetime.timezone.utc
            ).date()
            return date, f"DATE '{date}'"
        case "timestamp":
            # Note - Clients need to ensure local_timezone is the same as spark_sql_session_timeZone config.
            # No need to apply timezone for lit datetime, because we set the TIMEZONE parameter in snowpark session,
            # the snowflake backend would convert the lit datetime correctly. However, for returned column name, the
            # timezone needs to be added. Pyspark has a weird behavior that datetime.datetime always gets converted
            # to local timezone before printing according to spark_sql_session_timeZone setting. Haven't found
            # official doc about it, but this behavior is based on my testings.
            tz = (
                ZoneInfo(global_config.spark_sql_session_timeZone)
                if hasattr(global_config, "spark_sql_session_timeZone")
                else get_localzone()
            )
            microseconds = literal.timestamp
            lit_dt = datetime.datetime.fromtimestamp(
                microseconds / 1_000_000
            ) + datetime.timedelta(microseconds=microseconds % 1_000_000)
            tz_dt = datetime.datetime.fromtimestamp(
                microseconds / 1_000_000, tz=tz
            ) + datetime.timedelta(microseconds=microseconds % 1_000_000)
            return lit_dt, f"TIMESTAMP '{tz_dt.strftime('%Y-%m-%d %H:%M:%S')}'"
        case "binary":
            return literal.binary, str(literal.binary)
        case "decimal":
            # literal.decimal.precision & scale are ignored, as decimal.Decimal doesn't accept them
            return decimal.Decimal(literal.decimal.value), literal.decimal.value
        case "null":
            return None, "NULL"
        case other:
            raise NotImplementedErrorWithTelemetry(f"Other Literal Type {other}")
