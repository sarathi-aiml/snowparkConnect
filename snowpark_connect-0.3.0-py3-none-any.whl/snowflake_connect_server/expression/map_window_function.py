from typing import Union

import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
from snowflake import snowpark

from snowflake_connect_server.column_name_handler import ColumnNameMap
from snowflake_connect_server.expression.literal import get_literal_field_and_name


def map_window_function(
    exp: expressions_proto.Expression,
    column_mapping: ColumnNameMap,
) -> tuple[str, snowpark.Column]:
    from snowflake_connect_server.expression.map_expression import map_expression

    def parse_frame_boundary(
        boundary: expressions_proto.Expression.Window.WindowFrame.FrameBoundary,
        is_upper: bool,
        return_column: bool,
    ) -> tuple[str, Union[int, snowpark.Column]]:
        if boundary.HasField("current_row"):
            return "CURRENT ROW", snowpark.Window.CURRENT_ROW
        elif boundary.HasField("unbounded"):
            if is_upper:
                return "UNBOUNDED FOLLOWING", snowpark.Window.UNBOUNDED_FOLLOWING
            else:
                return "UNBOUNDED PRECEDING", snowpark.Window.UNBOUNDED_PRECEDING
        elif boundary.HasField("value"):
            if return_column:
                return map_expression(boundary.value, column_mapping)
            else:
                # the expression has to be literal of int in the case of rows_between
                literal, _ = get_literal_field_and_name(boundary.value.literal)
                return f"{literal} FOLLOWING", literal

    function_name, window_func = map_expression(
        exp.window.window_function, column_mapping
    )
    partitions = [
        map_expression(p, column_mapping)[1] for p in exp.window.partition_spec
    ]

    orders = []
    orderby_name = ["ORDER BY "]
    for order in exp.window.order_spec:
        order_col_name, order_exp = map_expression(order.child, column_mapping)
        orderby_name.append(order_col_name)
        match order.direction:
            case expressions_proto.Expression.SortOrder.SortDirection.SORT_DIRECTION_ASCENDING:
                orderby_name.append(" ASC ")
                match order.null_ordering:
                    case expressions_proto.Expression.SortOrder.NullOrdering.SORT_NULLS_FIRST:
                        orderby_name.append("NULLS FIRST")
                        orders.append(order_exp.asc_nulls_first())
                    case expressions_proto.Expression.SortOrder.NullOrdering.SORT_NULLS_LAST:
                        orderby_name.append("NULLS LAST")
                        orders.append(order_exp.asc_nulls_last())
                    case _:
                        orders.append(order_exp.asc())
            case expressions_proto.Expression.SortOrder.SortDirection.SORT_DIRECTION_DESCENDING:
                orderby_name.append(" DESC ")
                match order.null_ordering:
                    case expressions_proto.Expression.SortOrder.NullOrdering.SORT_NULLS_FIRST:
                        orderby_name.append("NULLS FIRST")
                        orders.append(order_exp.desc_nulls_first())
                    case expressions_proto.Expression.SortOrder.NullOrdering.SORT_NULLS_LAST:
                        orderby_name.append("NULLS LAST")
                        orders.append(order_exp.desc_nulls_last())
                    case _:
                        orders.append(order_exp.desc())
            case _:
                # When order direction is not specified, nulls first/last is ignored, because
                # there is no order_exp.nulls_first() / order_exp.nulls_last()
                orders.append(order_exp)
        orderby_name.append(", ")

    window_df = snowpark.Window
    if len(partitions) > 0:
        window_df = window_df.partitionBy(partitions)
    if len(orders) > 0:
        window_df = window_df.orderBy(orders)

    frame_name = []
    match exp.window.frame_spec.frame_type:
        case expressions_proto.Expression.Window.WindowFrame.FrameType.FRAME_TYPE_ROW:
            frame_name.append("ROWS BETWEEN")
            lower_name, lower = parse_frame_boundary(
                exp.window.frame_spec.lower, is_upper=False, return_column=False
            )
            upper_name, upper = parse_frame_boundary(
                exp.window.frame_spec.upper, is_upper=True, return_column=False
            )
            window_df = window_df.rows_between(lower, upper)
            frame_name.append(f"{lower_name} AND {upper_name}")
        case expressions_proto.Expression.Window.WindowFrame.FrameType.FRAME_TYPE_RANGE:
            lower_name, lower = parse_frame_boundary(
                exp.window.frame_spec.lower, is_upper=False, return_column=True
            )
            upper_name, upper = parse_frame_boundary(
                exp.window.frame_spec.upper, is_upper=True, return_column=True
            )
            window_df = window_df.range_between(lower, upper)
            frame_name.append(f"{lower_name} AND {upper_name}")
        case _:
            # default column name
            frame_name.append("ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW")

    spark_col_name = (
        f"{function_name} OVER ({''.join(orderby_name[:-1])} {' '.join(frame_name)})"
    )
    return spark_col_name, window_func.over(window_df)
