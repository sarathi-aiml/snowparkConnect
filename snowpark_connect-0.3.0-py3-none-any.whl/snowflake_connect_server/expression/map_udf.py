import inspect
from types import ModuleType
from typing import Callable

import pyspark.sql.connect.proto.expressions_pb2 as expressions_proto
from pyspark.serializers import CloudPickleSerializer
from snowflake import snowpark

from snowflake_connect_server.column_name_handler import ColumnNameMap
from snowflake_connect_server.type_mapping import proto_to_snowpark_type


def infer_udf_dependencies(func: Callable) -> dict[str, ModuleType]:
    """Try to infer required packages. Doesn't guarantee 100% correctness."""

    func_code = func.__code__
    # names in the global scope
    global_names = func.__globals__
    # names accessed in func (potential module references)
    code_names = func_code.co_names

    return [
        global_names[name]
        for name in code_names
        if name in global_names
        and isinstance(global_names[name], ModuleType)
        and (
            global_names[name].__file__
            and "site-packages" in global_names[name].__file__
        )
    ]


def map_common_inline_user_defined_udf(
    exp: expressions_proto.Expression, column_mapping: ColumnNameMap
) -> tuple[str, snowpark.Column]:
    from snowflake_connect_server.expression.map_expression import map_expression

    exp_udf = exp.common_inline_user_defined_function
    match exp_udf.WhichOneof("function"):
        case "python_udf":
            udf = exp_udf.python_udf
            (
                callable_func,
                pyspark_output_type,
            ) = CloudPickleSerializer().loads(udf.command)

            # If all parameters have type hints, we rely on snowpark to infer types.
            #   Otherwise, do best effort, i.e. use Snowflake Variant type.
            # Note: variant type has below limitations
            #   1. max size 16mb
            #   2. lower performance due to json string
            #   3. variant becomes string in udf. If required type is datetime, it doesn't work.
            func_signature = inspect.signature(callable_func)
            param_count = len(inspect.signature(callable_func).parameters)
            has_param_hints = all(
                param.annotation != inspect.Parameter.empty
                for param in func_signature.parameters.values()
            )

            input_types = (
                [snowpark.types.VariantType()] * param_count
                if not has_param_hints
                else None
            )

            modules = infer_udf_dependencies(callable_func)
            packages = [module.__name__ for module in modules]

            # TODO: if inferred packages is incorrect, how to make session level packages a fallback?
            snowpark_udf = snowpark.functions.udf(
                func=callable_func,
                return_type=proto_to_snowpark_type(udf.output_type),
                input_types=input_types,
                replace=True,
                packages=packages,
            )

            # TODO: client provided python version in python_udf.python_ver, which helps to know what
            #  CloudPickleSerializer to use? In the future, we probably don't want to unpack and pack func in sas layer,
            #  which requires modifying Snowpark.
            snowpark_udf_args = []
            snowpark_udf_arg_names = []
            for arg_exp in exp_udf.arguments:
                snowpark_udf_arg_name, snowpark_udf_arg = map_expression(
                    arg_exp, column_mapping
                )

                snowpark_udf_args.append(
                    snowpark_udf_arg
                    if has_param_hints
                    else snowpark_udf_arg.astype(snowpark.types.VariantType())
                )
                snowpark_udf_arg_names.append(snowpark_udf_arg_name)
            return (
                f"{exp_udf.function_name}({', '.join(snowpark_udf_arg_names)})",
                snowpark_udf(*snowpark_udf_args),
            )
        case _:
            raise ValueError(
                f"Not python udf {exp.common_inline_user_defined_function.function}"
            )
