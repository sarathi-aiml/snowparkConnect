import pandas
from snowflake import snowpark

from snowflake.snowpark._internal.utils import quote_name
from snowflake_connect_server.config import global_config


def build_column_map(
    result_df: snowpark.DataFrame,
    spark_column_names: list[str],
    spark_sql: bool = False,
    star_found: bool = False,
) -> snowpark.DataFrame:
    """
    Build a mapping from the DataFrame's column names to the Spark column names.

    This is used to track the original column names and handle column naming differences
    between Spark and Snowpark.

    The elements in result_df.columns and the elements in spark_column_names must be a one-to-one mapping.

    Args:
        result_df (snowpark.DataFrame): The DataFrame to map.
        spark_column_names (list[str]): The Spark column names.
    """
    # TODO: result_df.columns will query GS, optimize this to be more efficient.
    sp_columns = result_df.columns

    # Copy SF column names as Spark column names when called from spark.sql() API and
    # no Spark columns are returned. Sqlglot parser can't parse columns in certain cases like,
    # select 1, create table, select * from table etc.
    if spark_sql and len(spark_column_names) == 0 and len(sp_columns) > 0:
        spark_column_names = sp_columns.copy()

    # SQLGlot parses whole SQL statements for columns,
    # Snowpark parses only projection columns,
    # This mismatch happens in case of query like: SELECT id, sum(quantity) FROM sqlglot_dealer2 GROUP BY id ORDER BY id
    # Column map needs same number of columns in spark and snowflake,
    # Keep only projections columns in spark columns to mitigate the issue.
    # Ideally we should get projection columns of spark from sqlglot parsing but not finding a way to detect it.
    if len(spark_column_names) > len(sp_columns):
        spark_column_names = spark_column_names[: len(sp_columns)]

    # SELECT * from mytable where col1 is null
    if spark_sql and len(spark_column_names) < len(sp_columns) and star_found:
        spark_column_names = sp_columns.copy()

    assert len(sp_columns) == len(
        spark_column_names
    ), "Number of Spark column names must match number of columns in DataFrame"
    result_df._column_map = ColumnNameMap(spark_column_names, sp_columns)
    return result_df


def make_column_names_snowpark_compatible(
    names: list[str], offset: int = 0
) -> list[str]:
    """
    Make a list of column names Snowpark compatible.

    Snowpark column names must be uppercase, and cannot contain SQL keywords.
    """
    return [
        # Use `-` in the name to force df.column to return double-quoted names
        quote_name(f"{name}-{i + offset}")
        for i, name in enumerate(names)
    ]


class ColumnNameMap:
    def __init__(
        self,
        spark_column_names: list[str],
        snowpark_column_names: list[str],
    ) -> None:
        # TODO: Don't use pandas Series, use an OrderedDict + defaultdict instead.
        self.spark_column_mapping: pandas.Series = pandas.Series(
            snowpark_column_names, index=spark_column_names
        )
        # TODO: Don't use pandas Series, use an OrderedDict + defaultdict instead.
        self.snowpark_column_mapping: pandas.Series = pandas.Series(
            spark_column_names, index=snowpark_column_names
        )

    def _handle_case_sensitivity(
        self, spark_column_names: str | list[str]
    ) -> tuple[str, pandas.Series]:
        """
        Handle case sensitivity for the column names during mapping.
        """
        if global_config.spark_sql_caseSensitive:
            return spark_column_names, self.spark_column_mapping
        else:
            if isinstance(spark_column_names, str):
                spark_column_names = spark_column_names.upper()
            else:
                spark_column_names = [name.upper() for name in spark_column_names]
            spark_column_mapping = self.spark_column_mapping.set_axis(
                self.spark_column_mapping.index.map(str.upper)
            )
            return spark_column_names, spark_column_mapping

    def get_snowpark_column_names_from_spark_column_names(
        self,
        spark_column_names: list[str],
    ) -> list[str]:
        assert isinstance(spark_column_names, list)
        if isinstance(spark_column_names, str):
            spark_column_names = [spark_column_names]
        snowpark_column_names = []
        spark_column_names, spark_column_mapping = self._handle_case_sensitivity(
            spark_column_names
        )
        for n in spark_column_names:
            names_to_add = spark_column_mapping.get(n, default=None)
            if isinstance(names_to_add, pandas.Series):
                snowpark_column_names.extend(names_to_add.to_list())
            elif names_to_add is not None:
                snowpark_column_names.append(names_to_add)
        return snowpark_column_names

    def get_snowpark_column_name_from_spark_column_name(
        self,
        spark_column_name: str,
        *,
        allow_non_exists: bool = False,
    ) -> str | None:
        assert isinstance(spark_column_name, str)
        spark_column_name, spark_column_mapping = self._handle_case_sensitivity(
            spark_column_name
        )
        snowpark_names = self.get_snowpark_column_names_from_spark_column_names(
            [spark_column_name]
        )
        snowpark_names_len = len(snowpark_names)
        if snowpark_names_len > 1:
            raise KeyError(f"Ambiguous column name {spark_column_name}")
        elif snowpark_names_len == 0:
            if allow_non_exists:
                return None
            else:
                raise KeyError(f"Column name {spark_column_name} does not exist")
        return snowpark_names[0]

    def get_spark_column_names_from_snowpark_column_names(
        self,
        snowpark_column_names: list[str],
    ) -> list[str]:
        assert isinstance(snowpark_column_names, list)
        return list(self.snowpark_column_mapping.loc[snowpark_column_names].to_numpy())

    def get_spark_column_name_from_snowpark_column_name(
        self, snowpark_column_name: str
    ) -> str:
        assert isinstance(snowpark_column_name, str)
        return self.get_spark_column_names_from_snowpark_column_names(
            [snowpark_column_name]
        )[0]

    def get_spark_columns(self) -> list[str]:
        return self.spark_column_mapping.index.to_list()

    def get_snowpark_columns(self) -> list[str]:
        return self.snowpark_column_mapping.index.to_list()
