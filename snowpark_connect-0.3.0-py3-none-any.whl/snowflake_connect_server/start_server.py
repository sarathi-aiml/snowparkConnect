#!/usr/bin/env python3
import argparse

if __name__ == "__main__":
    import snowflake_connect_server as sas

    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--tcp-port", type=int)
    group.add_argument("--unix-domain-socket", type=str)

    args = parser.parse_args()
    unix_domain_socket = args.unix_domain_socket
    tcp_port = args.tcp_port
    if not unix_domain_socket and not tcp_port:
        tcp_port = 15002  # default spark connect server port

    sas.init_snowflake_spark_connect_session(
        is_daemon=False, tcp_port=tcp_port, unix_domain_socket=unix_domain_socket
    )
