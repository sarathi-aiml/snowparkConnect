import atexit
import os
import tempfile
import threading
import traceback
import urllib.parse
from concurrent import futures
from typing import Any, Callable, Dict, List, Optional, Tuple

import grpc
import pandas
import pyspark.sql.connect.proto.base_pb2 as proto_base
import pyspark.sql.connect.proto.base_pb2_grpc as proto_base_grpc
import pyspark.sql.connect.proto.common_pb2 as common_proto
import pyspark.sql.connect.proto.types_pb2 as types_proto
from grpc_status import rpc_status
from pyspark import StorageLevel
from pyspark.errors import PySparkValueError
from pyspark.sql.connect.client.core import ChannelBuilder
from pyspark.sql.connect.session import SparkConf, SparkSession
from snowflake import snowpark

import snowflake_connect_server.proto.control_pb2_grpc as control_grpc
from snowflake_connect_server.analyze_plan.map_tree_string import map_tree_string
from snowflake_connect_server.config import init_snowpark_session, route_config_proto
from snowflake_connect_server.constants import (
    DEFAULT_CONNECTION_NAME,
    SERVER_SIDE_SESSION_ID,
)
from snowflake_connect_server.control_server import ControlServicer
from snowflake_connect_server.error.error_utils import build_grpc_error_response
from snowflake_connect_server.execute_plan.map_execution_command import (
    map_execution_command,
)
from snowflake_connect_server.execute_plan.map_execution_root import map_execution_root
from snowflake_connect_server.execute_plan.utils import is_streaming
from snowflake_connect_server.relation.map_relation import map_relation
from snowflake_connect_server.type_mapping import (
    parse_ddl_string,
    snowpark_to_proto_type,
)
from snowflake_connect_server.utils.cache import (
    df_cache_map_get,
    df_cache_map_pop,
    df_cache_map_set,
)
from snowflake_connect_server.utils.context import clear_thread_local_data, set_context
from snowflake_connect_server.utils.ses_logging import (
    log_waring_once_storage_level,
    logger,
)
from snowflake_connect_server.utils.telemetry import (
    NotImplementedErrorWithTelemetry,
    TelemetryClient,
)


class SnowflakeConnectServicer(proto_base_grpc.SparkConnectServiceServicer):
    def __init__(self, log_request_fn: Callable[[bytearray], None] = None) -> None:
        self.log_request_fn = log_request_fn

    def ExecutePlan(self, request: proto_base.ExecutePlanRequest, context):
        """Executes a request that contains the query and returns a stream of [[Response]].

        It is guaranteed that there is at least one ARROW batch returned even if the result set is empty.
        """
        logger.info("ExecutePlan")
        if self.log_request_fn is not None:
            self.log_request_fn(request.SerializeToString())
        # TODO: remove session id context when we host this in Snowflake server
        # set the thread-local context of session id
        clear_thread_local_data()
        set_context("session_id", request.session_id)
        result = []
        streaming_relation = False
        while True:
            try:
                match request.plan.WhichOneof("op_type"):
                    case "root":
                        logger.info("ROOT")
                        result += map_execution_root(request)
                    case "command":
                        logger.info("COMMAND")
                        command_result = map_execution_command(request)
                        if command_result is not None:
                            result.append(command_result)
            except Exception as e:
                import traceback

                traceback.print_exc()
                rich_status = build_grpc_error_response(e)
                context.abort_with_status(rpc_status.to_status(rich_status))

            if not (is_streaming(request.plan.root) or streaming_relation):
                return iter(
                    result
                    + [
                        proto_base.ExecutePlanResponse(
                            session_id=request.session_id,
                            operation_id=SERVER_SIDE_SESSION_ID,
                            result_complete=proto_base.ExecutePlanResponse.ResultComplete(),
                        ),
                    ]
                )

    def AnalyzePlan(self, request: proto_base.AnalyzePlanRequest, context):
        """Analyzes a query and returns a [[AnalyzeResponse]] containing metadata about the query."""
        logger.info(f"AnalyzePlan: {request.WhichOneof('analyze')}")
        try:
            # TODO: remove session id context when we host this in Snowflake server
            # set the thread-local context of session id
            clear_thread_local_data()
            set_context("session_id", request.session_id)
            match request.WhichOneof("analyze"):
                case "schema":
                    snowpark_df = map_relation(request.schema.plan.root)
                    snowpark_schema: snowpark.types.StructType = snowpark_df.schema
                    schema = proto_base.AnalyzePlanResponse.Schema(
                        schema=types_proto.DataType(
                            **snowpark_to_proto_type(
                                snowpark_schema, snowpark_df._column_map
                            )
                        )
                    )
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        schema=schema,
                    )
                case "tree_string":
                    return map_tree_string(request)
                case "is_local":
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        is_local=proto_base.AnalyzePlanResponse.IsLocal(is_local=False),
                    )
                case "ddl_parse":
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        ddl_parse=proto_base.AnalyzePlanResponse.DDLParse(
                            parsed=parse_ddl_string(request.ddl_parse.ddl_string)
                        ),
                    )
                case "get_storage_level":
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        get_storage_level=proto_base.AnalyzePlanResponse.GetStorageLevel(
                            storage_level=common_proto.StorageLevel(
                                use_disk=True, use_memory=True
                            )
                        ),
                    )
                case "persist":
                    plan_id = request.persist.relation.common.plan_id
                    # cache the plan if it is not already in the map
                    if df_cache_map_get((request.session_id, plan_id)) is None:
                        # parse the cached dataframe plan
                        df: snowpark.DataFrame | pandas.DataFrame = map_relation(
                            request.persist.relation
                        )
                        # only cache snowpark Dataframe, but not pandas result.
                        # Pandas result is only returned when df.show() is called, where we convert
                        # a dataframe to a string representation.
                        # We don't expect map_relation would return pandas df here because that would
                        # be equivalent to calling df.show().cache(), which is not allowed.
                        if not isinstance(df, pandas.DataFrame):
                            cached_df = df.cache_result()
                            # caching does not change the column name map
                            cached_df._column_map = df._column_map
                            df_cache_map_set((request.session_id, plan_id), cached_df)
                        else:
                            # This is not expected, but we will just log a warning
                            logger.warning(
                                "Unexpected pandas dataframe returned for caching. Ignoring the cache call."
                            )

                    storage_level = request.persist.storage_level
                    if storage_level != StorageLevel.DISK_ONLY:
                        log_waring_once_storage_level(storage_level)

                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        persist=proto_base.AnalyzePlanResponse.Persist(),
                    )
                case "unpersist":
                    plan_id = request.persist.relation.common.plan_id
                    # unpersist the cached plan
                    df_cache_map_pop((request.session_id, plan_id))

                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        unpersist=proto_base.AnalyzePlanResponse.Unpersist(),
                    )
                case "explain":
                    # TODO: Implement explain string.
                    # We will need to generate the same string as Spark would generate.
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        explain=proto_base.AnalyzePlanResponse.Explain(
                            explain_string=""
                        ),
                    )
                case "spark_version":
                    return proto_base.AnalyzePlanResponse(
                        session_id=request.session_id,
                        spark_version=proto_base.AnalyzePlanResponse.SparkVersion(
                            version="3.5.3"
                        ),
                    )
                case _:
                    raise NotImplementedErrorWithTelemetry(
                        f"ANALYZE PLAN NOT IMPLEMENTED:\n{request}"
                    )
        except Exception as e:
            import traceback

            traceback.print_exc()
            rich_status = build_grpc_error_response(e)
            context.abort_with_status(rpc_status.to_status(rich_status))

    @staticmethod
    def Config(
        request: proto_base.ConfigRequest,
        context,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        """Update or fetch the configurations and returns a [[ConfigResponse]] containing the result."""
        logger.info("Config")
        return route_config_proto(request, snowpark.Session.builder.getOrCreate())

    def AddArtifacts(self, request_iterator, context):
        """Add artifacts to the session and returns a [[AddArtifactsResponse]] containing metadata about
        the added artifacts.
        """
        logger.info("AddArtifacts")
        raise NotImplementedErrorWithTelemetry(
            f"ADD ARTIFACTS NOT IMPLEMENTED:\n{request_iterator}"
        )

    def ArtifactStatus(self, request, context):
        """Check statuses of artifacts in the session and returns them in a [[ArtifactStatusesResponse]]"""
        logger.info("ArtifactStatus")
        raise NotImplementedErrorWithTelemetry(
            f"ARTIFACT STATUS NOT IMPLEMENTED:\n{request}"
        )

    def Interrupt(self, request, context):
        """Interrupts running executions"""
        logger.info("Interrupt")
        raise NotImplementedErrorWithTelemetry(f"INTERRUPT NOT IMPLEMENTED:\n{request}")

    def ReattachExecute(self, request: proto_base.ReattachExecuteRequest, context):
        """Reattach to an existing reattachable execution.
        The ExecutePlan must have been started with ReattachOptions.reattachable=true.
        If the ExecutePlanResponse stream ends without a ResultComplete message, there is more to
        continue. If there is a ResultComplete, the client should use ReleaseExecute with
        """
        logger.info("ReattachExecute")
        return iter(
            [
                proto_base.ReattachExecuteRequest(
                    session_id=request.session_id,
                )
            ]
        )

    def ReleaseExecute(self, request: proto_base.ReleaseExecuteRequest, context):
        """Release an reattachable execution, or parts thereof.
        The ExecutePlan must have been started with ReattachOptions.reattachable=true.
        Non reattachable executions are released automatically and immediately after the ExecutePlan
        RPC and ReleaseExecute may not be used.
        """
        logger.info("ReleaseExecute")
        return proto_base.ReleaseExecuteResponse(
            session_id=request.session_id,
            operation_id=SERVER_SIDE_SESSION_ID,
        )

    # TODO: These are required in Spark 4.x.
    # def ReleaseSession(self, request, context):
    #     """Release a session.
    #     All the executions in the session will be released. Any further requests for the session with
    #     that session_id for the given user_id will fail. If the session didn't exist or was already
    #     released, this is a noop.
    #     """
    #     logger.info("ReleaseSession")
    #     return super().ReleaseSession(request, context)
    #
    # def FetchErrorDetails(self, request, context):
    #     """FetchErrorDetails retrieves the matched exception with details based on a provided error id."""
    #     logger.info("FetchErrorDetails")
    #     return super().FetchErrorDetails(request, context)


_server_running: threading.Event = threading.Event()
_server_url: Optional[str] = None
_client_url: Optional[str] = None
_server_error: bool = False


def _stop_server(stop_event: threading.Event, server: grpc.Server):
    stop_event.wait()
    server.stop(0)
    logger.info("server stop sent")


def _serve(stop_event: threading.Event = None, session: snowpark.Session = None):
    global _server_running, _server_error
    # TODO: factor out the Snowflake connection code.
    try:
        config_snowpark()
        if session is None:
            session = snowpark.Session.builder.config(
                "connection_name", DEFAULT_CONNECTION_NAME
            ).create()
            session._sas_telemetry_client = TelemetryClient(session._conn._conn)
        init_snowpark_session(session)
        server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
        control_servicer = ControlServicer(session)
        proto_base_grpc.add_SparkConnectServiceServicer_to_server(
            SnowflakeConnectServicer(control_servicer.log_spark_connect_batch), server
        )
        control_grpc.add_ControlServiceServicer_to_server(control_servicer, server)
        server_url = get_server_url()
        server.add_insecure_port(server_url)
        server.start()
        logger.info(f"Snowflake Spark Connect Server started on {server_url}")
        _server_running.set()
        session._sas_telemetry_client.send_server_started_telemetry()
        if stop_event is not None:
            # start a background thread to listen for stop event and terminate the server
            threading.Thread(
                target=_stop_server, args=(stop_event, server), daemon=True
            ).start()
        server.wait_for_termination()
    except Exception as e:
        _server_error = True
        _server_running.set()  # unblock any client sessions
        logger.error(e)
        logger.error(traceback.format_exc())


def _set_remote_url(remote_url: str):
    global _server_url, _client_url
    if remote_url.startswith("sc://"):
        _client_url = remote_url[5:]
        _server_url = _client_url.split("/")[0]
    elif remote_url.startswith("unix:/"):
        _client_url = remote_url
        _server_url = remote_url.split("/;")[0]
    else:
        raise RuntimeError(f"Invalid Spark Connect URL: {remote_url}")


def _set_server_tcp_port(server_port: int):
    global _server_url, _client_url
    _server_url = f"[::]:{server_port}"
    _client_url = f"sc://localhost:{server_port}"


def _set_server_unix_domain_socket(path: str):
    global _server_url, _client_url
    _server_url = f"unix:{path}"
    _client_url = f"unix:{path}"


def get_server_url() -> str:
    global _server_url
    if not _server_url:
        raise RuntimeError("Server URL not set")
    return _server_url


def get_client_url() -> str:
    global _client_url
    if not _client_url:
        raise RuntimeError("Client URL not set")
    return _client_url


def _make_unix_domain_socket() -> str:
    parent_dir = tempfile.mkdtemp()
    server_path = os.path.join(parent_dir, "snowflake_sas_grpc.sock")
    atexit.register(_cleanup_unix_domain_socket, server_path)
    return server_path


def _cleanup_unix_domain_socket(server_path: str) -> None:
    parent_dir = os.path.dirname(server_path)
    if os.path.exists(server_path):
        os.remove(server_path)
    if os.path.exists(parent_dir):
        os.rmdir(parent_dir)


class UnixDomainSocketChannelBuilder(ChannelBuilder):
    """
    Spark Connect gRPC channel builder for Unix domain sockets
    """

    def __init__(self, channelOptions: Optional[List[Tuple[str, Any]]] = None) -> None:
        url: str = get_client_url()
        if url[:6] != "unix:/" or len(url) < 7:
            raise PySparkValueError(
                error_class="INVALID_CONNECT_URL",
                message_parameters={
                    "detail": "The URL must start with 'unix://'. Please update the URL to follow the correct format, e.g., 'unix://unix_domain_socket_path'.",
                },
            )

        # Rewrite the URL to use http as the scheme so that we can leverage
        # Python's built-in parser to parse URL parameters
        fake_url = "http://" + url[6:]
        self.url = urllib.parse.urlparse(fake_url)
        self.params: Dict[str, str] = {}
        self._extract_attributes()

        # Now parse the real unix domain socket URL
        self.url = urllib.parse.urlparse(url)

        GRPC_DEFAULT_OPTIONS = [
            ("grpc.max_send_message_length", ChannelBuilder.MAX_MESSAGE_LENGTH),
            ("grpc.max_receive_message_length", ChannelBuilder.MAX_MESSAGE_LENGTH),
        ]

        if channelOptions is None:
            self._channel_options = GRPC_DEFAULT_OPTIONS
        else:
            self._channel_options = GRPC_DEFAULT_OPTIONS + channelOptions

    @property
    def endpoint(self) -> str:
        return f"{self.url.scheme}:{self.url.path}"

    def toChannel(self) -> grpc.Channel:
        return grpc.insecure_channel(self.endpoint, options=self._channel_options)


def config_snowpark() -> None:
    """
    Some snowpark configs required by SAS.
    """

    # Enable structType. Require snowpark 1.27.0 or snowpark main branch after commit 888cec55c4
    import snowflake.snowpark.context as context

    context._should_use_structured_type_semantics = True


def init_snowflake_spark_connect_session(
    is_daemon: bool = True,
    tcp_port: Optional[int] = None,
    unix_domain_socket: Optional[str] = None,
    stop_event: threading.Event = None,
    snowpark_session: Optional[snowpark.Session] = None,
) -> threading.Thread | None:
    """
    Starts Spark Connect server connected to Snowflake. No-op if the Server is already running.

    Parameters:
        is_daemon (bool): Should run the server as daemon or not. use True to automatically shut the Spark connect
                          server down when the main program (or test) finishes. use False to start the server in a
                          stand-alone, long-running mode.
        tcp_port (Optional[int]): TCP port on which to start the Spark Connect server. This option is incompatible with
                                  the unix_domain_socket parameter.
        unix_domain_socket (Optional[str]): Path to the unix domain socket on which to start the Spark Connect server.
                                            This option is incompatible with the tcp_port parameter.
        stop_event (Optional[threading.Event]): Stop the SAS server when stop_event.set() is called.
                                                Only works when is_daemon=True.
        snowpark_session: A Snowpark session to use for this connection; currently the only applicable use of this is to
                          pass in the session created by the stored proc environment.
    """
    global _server_running
    if _server_running.is_set():
        url = get_client_url()
        logger.warning(f"Snowflake Spark Connect Server is already running at {url}")
        return
    if tcp_port and unix_domain_socket:
        raise RuntimeError(
            "Can not specify both tcp_port and unix_domain_socket at the same time"
        )

    remote_url_from_env = os.environ.get("SPARK_REMOTE")
    if remote_url_from_env:
        _set_remote_url(remote_url_from_env)
    elif tcp_port:
        _set_server_tcp_port(tcp_port)
    else:
        if not unix_domain_socket:
            # If neither are specified, create ephemeral unique unix domain socket
            unix_domain_socket = _make_unix_domain_socket()
        _set_server_unix_domain_socket(unix_domain_socket)

    if is_daemon:
        # daemon=True ensure the server thread exits when script finishes
        arguments = (stop_event, snowpark_session)
        server_thread = threading.Thread(target=_serve, args=arguments, daemon=True)
        server_thread.start()
        _server_running.wait()
        if _server_error:
            raise RuntimeError("Snowflake Spark Connect Server failed to start")
        return server_thread
    else:
        _serve(snowpark_session)  # launch in foreground

    # wait for server to start


def get_snowflake_spark_session(
    url: Optional[str] = None, conf: SparkConf = None
) -> SparkSession:
    """
    Returns spark connect session

    Parameters:
        url (Optional[str]): Spark connect server URL. Uses default server URL if none is provided.

    Returns:
        A new spark connect session

    Raises:
        RuntimeError: If Spark Connect server is not started.
    """
    global _server_error
    if not url:
        url = get_client_url()

    if url.startswith("unix:/"):
        b = SparkSession.builder.channelBuilder(UnixDomainSocketChannelBuilder())
    else:
        b = SparkSession.builder.remote(url)

    if conf is not None:
        b.config(conf)

    return b.getOrCreate()
