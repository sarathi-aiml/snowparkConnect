from snowflake import snowpark

from snowflake_connect_server.column_name_handler import ColumnNameMap


class EmptyDataFrame(snowpark.DataFrame):

    __name__ = "DataFrame"

    def __init__(self) -> None:
        self._column_map = ColumnNameMap([], [])

    columns = []
    schema = snowpark.types.StructType([])
