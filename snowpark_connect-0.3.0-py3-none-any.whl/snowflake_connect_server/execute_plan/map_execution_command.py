import pyspark.sql.connect.proto.base_pb2 as proto_base
import pyspark.sql.connect.proto.relations_pb2 as relation_proto

from snowflake_connect_server.constants import SERVER_SIDE_SESSION_ID
from snowflake_connect_server.execute_plan.utils import pandas_to_arrow_batches_bytes
from snowflake_connect_server.relation.map_relation import map_relation
from snowflake_connect_server.relation.map_sql import map_sql_to_pandas_df
from snowflake_connect_server.relation.write.map_write import map_write
from snowflake_connect_server.utils.ses_logging import logger
from snowflake_connect_server.utils.telemetry import NotImplementedErrorWithTelemetry


def map_execution_command(
    request: proto_base.ExecutePlanRequest,
) -> proto_base.ExecutePlanResponse | None:
    logger.info(request.plan.command.WhichOneof("command_type").upper())
    match request.plan.command.WhichOneof("command_type"):
        case "create_dataframe_view":
            input_df = map_relation(request.plan.command.create_dataframe_view.input)
            # Use real column names when writing to sf.
            assert hasattr(
                input_df, "_column_map"
            ), "input_df does not have the _column_map attribute"
            column_map = input_df._column_map
            for column in input_df.columns:
                input_df = input_df.withColumnRenamed(
                    column,
                    column_map.get_spark_column_name_from_snowpark_column_name(column),
                )
            input_df.create_or_replace_temp_view(
                request.plan.command.create_dataframe_view.name
            )
        case "write_stream_operation_start":
            match request.plan.command.write_stream_operation_start.format:
                case "console":
                    # TODO: Make the console output work with Spark style formatting.
                    # result_df: pandas.DataFrame = map_relation(
                    #     relation_proto.Relation(
                    #         show_string=relation_proto.ShowString(
                    #             input=request.plan.command.write_stream_operation_start.input,
                    #             num_rows=100,
                    #             truncate=False,
                    #         )
                    #     )
                    # )
                    # logger.info(result_df.iloc[0, 0])
                    map_relation(
                        request.plan.command.write_stream_operation_start.input
                    ).show()
        case "sql_command":
            pandas_df, schema = map_sql_to_pandas_df(
                request.plan.command.sql_command.sql
            )
            # SELECT query in SQL command will return None instead of Pandas DF to enable lazy evaluation
            if pandas_df is None:
                return None
            return proto_base.ExecutePlanResponse(
                session_id=request.session_id,
                operation_id=SERVER_SIDE_SESSION_ID,
                sql_command_result=proto_base.ExecutePlanResponse.SqlCommandResult(
                    relation=relation_proto.Relation(
                        local_relation=relation_proto.LocalRelation(
                            data=pandas_to_arrow_batches_bytes(pandas_df),
                            schema=schema,
                        )
                    )
                ),
            )
        case "write_operation":
            map_write(request)

        case other:
            raise NotImplementedErrorWithTelemetry(
                f"Command type {other} not implemented"
            )
