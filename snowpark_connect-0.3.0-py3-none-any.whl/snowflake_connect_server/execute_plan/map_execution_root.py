import pandas
import pyspark.sql.connect.proto.base_pb2 as proto_base
from snowflake import snowpark

from snowflake_connect_server.constants import SERVER_SIDE_SESSION_ID
from snowflake_connect_server.execute_plan.utils import (
    fix_pandas_df_types,
    pandas_to_arrow_batches_bytes,
)
from snowflake_connect_server.relation.map_relation import map_relation
from snowflake_connect_server.type_mapping import snowpark_to_proto_type


def map_execution_root(
    request: proto_base.ExecutePlanRequest,
) -> list[proto_base.ExecutePlanResponse]:
    result_df: snowpark.DataFrame | pandas.DataFrame = map_relation(request.plan.root)
    if isinstance(result_df, snowpark.DataFrame):
        pandas_df = result_df.to_pandas()
        snowpark_schema = result_df.schema
        pandas_df = fix_pandas_df_types(pandas_df, snowpark_schema)
        schema = snowpark_to_proto_type(snowpark_schema, result_df._column_map)
    else:
        pandas_df = result_df
        schema = None
    return [
        proto_base.ExecutePlanResponse(
            session_id=request.session_id,
            operation_id=SERVER_SIDE_SESSION_ID,
            arrow_batch=proto_base.ExecutePlanResponse.ArrowBatch(
                row_count=len(pandas_df),
                data=pandas_to_arrow_batches_bytes(pandas_df),
            ),
            schema=schema,
        ),
    ]
