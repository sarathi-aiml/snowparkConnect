import pytest
from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession

import snowflake_connect_server as sas

# Use any time zone other than America/Los_Angeles and UTC, to minimize the
# odds of tests passing by luck.
TEST_TIMEZONE = "America/New_York"


@pytest.fixture(scope="session")
def spark_conf():
    conf = SparkConf()
    conf.set("spark.sql.session.timeZone", TEST_TIMEZONE)
    conf.set("spark.sql.catalogImplementation", "hive")

    return conf


@pytest.fixture(scope="session")
def sas_spark():
    sas.init_snowflake_spark_connect_session()
    spark = sas.get_snowflake_spark_session()
    spark.conf.set("spark.sql.session.timeZone", TEST_TIMEZONE)

    yield spark
    spark.stop()


@pytest.fixture(scope="session")
def native_spark(spark_conf):
    # start local pyspark
    sc = SparkContext("local[2]", "Native_PySpark", conf=spark_conf)
    yield SparkSession(sc)
    sc.stop()
