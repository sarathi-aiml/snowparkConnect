import os

import snowflake_connect_server as sas

# Make pyspark imports work in the original namespace.
os.environ["SPARK_CONNECT_MODE_ENABLED"] = "1"

sas.init_snowflake_spark_connect_session()
