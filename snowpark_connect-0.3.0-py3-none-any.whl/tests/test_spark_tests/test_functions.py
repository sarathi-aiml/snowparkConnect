import pyspark.sql.connect.functions as spark_fn
import pytest  # noqa: E402
from pyspark.sql import Row
from pyspark.sql.connect.window import Window
from pyspark.sql.tests import test_functions  # noqa: E402
from pyspark.testing.sqlutils import ReusedSQLTestCase  # noqa: E402

import snowflake_connect_server as sas


class TestSparkFunctionsTests(ReusedSQLTestCase, test_functions.FunctionsTestsMixin):
    @classmethod
    def setUpClass(cls):
        cls.testData = [Row(key=i, value=str(i)) for i in range(100)]
        cls.spark = sas.get_snowflake_spark_session()
        cls.df = cls.spark.createDataFrame(cls.testData)

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_array_repeat(self):
        super().test_array_repeat()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_assert_true(self):
        super().test_assert_true()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_basic_functions(self):
        super().test_basic_functions()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_binary_math_function(self):
        super().test_binary_math_function()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_bit_length_function(self):
        super().test_bit_length_function()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_collect_functions(self):
        super().test_collect_functions()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_crosstab(self):
        super().test_crosstab()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_dayofweek(self):
        super().test_dayofweek()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_explode(self):
        super().test_explode()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_first_last_ignorenulls(self):
        super().test_first_last_ignorenulls()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_function_parity(self):
        super().test_function_parity()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_functions_broadcast(self):
        super().test_functions_broadcast()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_inline(self):
        super().test_inline()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_input_file_name_reset_for_rdd(self):
        super().test_input_file_name_reset_for_rdd()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_input_file_name_udf(self):
        super().test_input_file_name_udf()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_inverse_trig_functions(self):
        super().test_inverse_trig_functions()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_least(self):
        super().test_least()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_levenshtein_function(self):
        super().test_levenshtein_function()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_lit_day_time_interval(self):
        super().test_lit_day_time_interval()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_lit_list(self):
        super().test_lit_list()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_lit_np_scalar(self):
        super().test_lit_np_scalar()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_make_date(self):
        super().test_make_date()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_map_functions(self):
        super().test_map_functions()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_math_functions(self):
        super().test_math_functions()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_ndarray_input(self):
        super().test_ndarray_input()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_nested_higher_order_function(self):
        super().test_nested_higher_order_function()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_np_scalar_input(self):
        super().test_np_scalar_input()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_nth_value(self):
        super().test_nth_value()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_octet_length_function(self):
        super().test_octet_length_function()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_overlay(self):
        super().test_overlay()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_raise_error(self):
        super().test_raise_error()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_rand_functions(self):
        super().test_rand_functions()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_reciprocal_trig_functions(self):
        super().test_reciprocal_trig_functions()

    @pytest.mark.skip
    def test_sampleby(self):
        super().test_sampleby()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_shiftleft(self):
        super().test_shiftleft()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_shiftright(self):
        super().test_shiftright()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_shiftrightunsigned(self):
        super().test_shiftrightunsigned()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_slice(self):
        super().test_slice()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_sorting_functions_with_column(self):
        super().test_sorting_functions_with_column()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_string_functions(self):
        super().test_string_functions()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_sum_distinct(self):
        super().test_sum_distinct()

    def test_window_functions(self):
        # Copied from super().test_window_functions(). Only modified expected output.
        df = self.spark.createDataFrame(
            [(1, "1"), (2, "2"), (1, "2"), (1, "2")], ["key", "value"]
        )
        w = Window.partitionBy("value").orderBy("key")

        sel = df.select(
            df.value,
            df.key,
            spark_fn.max("key").over(w.rowsBetween(0, 1)),
            spark_fn.min("key").over(w.rowsBetween(0, 1)),
            spark_fn.count("key").over(w.rowsBetween(float("-inf"), float("inf"))),
            spark_fn.row_number().over(w),
            spark_fn.rank().over(w),
            spark_fn.dense_rank().over(w),
            spark_fn.ntile(2).over(w),
        )
        rs = sorted(sel.collect())
        expected = [
            ("1", 1, 1, 1, 1, 1, 1, 1, 1),
            ("2", 1, 1, 1, 3, 2, 1, 1, 1),
            ("2", 1, 2, 1, 3, 1, 1, 1, 1),
            ("2", 2, 2, 2, 3, 3, 3, 2, 2),
        ]
        # Spark's output is:
        #  ("1", 1, 1, 1, 1, 1, 1, 1, 1),
        #  ("2", 1, 1, 1, 3, 1, 1, 1, 1),
        #  ("2", 1, 2, 1, 3, 2, 1, 1, 1),
        #  ("2", 2, 2, 2, 3, 3, 3, 2, 2),
        # Snowflake's SQL engine behaves differently from Spark's engine.
        # And I believe Spark's output is correct, because looking at column MAX and ROW_NUMBER:
        # Snowflake's engine appears to be first partitioning, then perform MAX and ROW_NUMBER, then sort.
        # Spark's engine appears to be first partitioning, then sort, then perform MAX and ROW_NUMBER.
        # The generated SQL is correct, so there is nothing we can do to fix it:
        # SELECT "VALUESES1", "KEYSES0",
        #     max("KEYSES0") OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST  ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING  ),
        #     min("KEYSES0") OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST  ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING  ),
        #     count("KEYSES0") OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST  ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING ),
        #     row_number() OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST ),
        #     rank() OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST ),
        #     dense_rank() OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST ),
        #     ntile(2) OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST )
        #       FROM ( SELECT "KEYSES0" AS "KEYSES0", "VALUESES1" AS "VALUESES1" FROM
        #       ( SELECT $1 AS "KEYSES0", $2 AS "VALUESES1" FROM  VALUES (1 :: INT, '1' :: STRING), (2 :: INT, '2' :: STRING), (1 :: INT, '2' :: STRING), (1 :: INT, '2' :: STRING)));
        for r, ex in zip(rs, expected):
            self.assertEqual(tuple(r), ex[: len(r)])

    @pytest.mark.xfail(reason="Does not work in Snowpark")
    def test_window_functions_cumulative_sum(self):
        # GS throws error: 002305 Window frame requires an ORDER BY clause.
        # TODO: We might need to add a special inference that when the input function
        #   only have one argument, we should use that argument as the ordering column.
        #   This seems to be Spark's behavior when orderBy is not provided.
        super().test_window_functions_cumulative_sum()

    def test_window_functions_without_partitionBy(self):
        # Copied from super().test_window_functions_without_partitionBy().
        # Only modified expected output.
        df = self.spark.createDataFrame(
            [(1, "1"), (2, "2"), (1, "2"), (1, "2")], ["key", "value"]
        )
        w = Window.orderBy("key", df.value)

        sel = df.select(
            df.value,
            df.key,
            spark_fn.max("key").over(w.rowsBetween(0, 1)),
            spark_fn.min("key").over(w.rowsBetween(0, 1)),
            spark_fn.count("key").over(w.rowsBetween(float("-inf"), float("inf"))),
            spark_fn.row_number().over(w),
            spark_fn.rank().over(w),
            spark_fn.dense_rank().over(w),
            spark_fn.ntile(2).over(w),
        )
        rs = sorted(sel.collect())
        expected = [
            ("1", 1, 1, 1, 4, 1, 1, 1, 1),
            ("2", 1, 1, 1, 4, 3, 2, 2, 2),
            ("2", 1, 2, 1, 4, 2, 2, 2, 1),
            ("2", 2, 2, 2, 4, 4, 4, 3, 2),
        ]
        # Same issue in expected output described in test_window_functions
        for r, ex in zip(rs, expected):
            self.assertEqual(tuple(r), ex[: len(r)])

    @pytest.mark.xfail(reason="Does not work in Snowpark")
    def test_window_time(self):
        # Snowpark does not have function.window, but Spark have.
        super().test_window_time()
