import pytest
from pyspark.sql.tests.connect.test_parity_dataframe import DataFrameParityTests

from tests.test_spark_tests.connect.utils import (
    setup_class_for_reused_connect_test_case,
)


class SASDataFrameParityTests(DataFrameParityTests):
    @classmethod
    def setUpClass(cls):
        setup_class_for_reused_connect_test_case(cls)

    @pytest.mark.xfail
    def test_cache_dataframe(self):
        super().test_cache_dataframe()

    @pytest.mark.xfail
    def test_cache_table(self):
        super().test_cache_table()

    @pytest.mark.xfail
    def test_create_dataframe_from_pandas_with_day_time_interval(self):
        super().test_create_dataframe_from_pandas_with_day_time_interval()

    @pytest.mark.xfail
    def test_drop(self):
        super().test_drop()

    @pytest.mark.xfail
    def test_drop_column_name_with_dot(self):
        super().test_drop_column_name_with_dot()

    @pytest.mark.xfail
    def test_duplicate_field_names(self):
        super().test_duplicate_field_names()

    @pytest.mark.xfail
    def test_duplicated_column_names(self):
        super().test_duplicated_column_names()

    @pytest.mark.xfail
    def test_extended_hint_types(self):
        super().test_extended_hint_types()

    @pytest.mark.xfail
    def test_freqItems(self):
        super().test_freqItems()

    @pytest.mark.xfail
    def test_generic_hints(self):
        super().test_generic_hints()

    @pytest.mark.xfail
    def test_input_files(self):
        super().test_input_files()

    @pytest.mark.xfail
    def test_print_schema(self):
        super().test_print_schema()

    @pytest.mark.xfail
    def test_repr_behaviors(self):
        super().test_repr_behaviors()

    @pytest.mark.xfail
    def test_sample_with_random_seed(self):
        super().test_sample_with_random_seed()

    @pytest.mark.xfail
    def test_to(self):
        super().test_to()

    @pytest.mark.xfail
    def test_to_pandas(self):
        super().test_to_pandas()

    @pytest.mark.xfail
    def test_to_pandas_for_array_of_struct(self):
        super().test_to_pandas_for_array_of_struct()

    @pytest.mark.xfail
    def test_to_pandas_from_empty_dataframe(self):
        super().test_to_pandas_from_empty_dataframe()

    @pytest.mark.xfail
    def test_to_pandas_from_mixed_dataframe(self):
        super().test_to_pandas_from_mixed_dataframe()

    @pytest.mark.xfail
    def test_to_pandas_from_null_dataframe(self):
        super().test_to_pandas_from_null_dataframe()

    @pytest.mark.xfail
    def test_to_pandas_on_cross_join(self):
        super().test_to_pandas_on_cross_join()

    @pytest.mark.xfail
    def test_to_pandas_with_duplicated_column_names(self):
        super().test_to_pandas_with_duplicated_column_names()


# Remove these from the namespace so pytest doesn't detect them and try to run them.
del DataFrameParityTests
