import os
import tempfile

from pyspark.sql import Row
from pyspark.sql.session import SparkSession as PySparkSession
from pyspark.sql.types import StringType, StructField, StructType

import snowflake_connect_server as sas


def setup_class_for_reused_connect_test_case(cls: type) -> None:
    cls.spark = sas.get_snowflake_spark_session()
    cls.tempdir = tempfile.NamedTemporaryFile(delete=False)
    cls.testData = [Row(key=i, value=str(i)) for i in range(100)]
    cls.df = cls.spark.createDataFrame(cls.testData)


def setup_class_for_sql_test_case(cls: type) -> None:
    cls.tbl_name = "test_connect_basic_table_1"
    cls.tbl_name2 = "test_connect_basic_table_2"
    cls.tbl_name3 = "test_connect_basic_table_3"
    cls.tbl_name4 = "test_connect_basic_table_4"
    cls.tbl_name_empty = "test_connect_basic_table_empty"

    cls.spark = sas.get_snowflake_spark_session()
    cls.tempdir = tempfile.NamedTemporaryFile(delete=False)
    # Cleanup test data for spark connect
    cls.spark_connect_clean_up_test_data()

    df = cls.spark.createDataFrame([(x, f"{x}") for x in range(100)], ["id", "name"])
    # Since we might create multiple Spark sessions, we need to create global temporary view
    # that is specifically maintained in the "global_temp" schema.
    df.write.saveAsTable(cls.tbl_name)
    df2 = cls.spark.createDataFrame(
        [(x, f"{x}", 2 * x) for x in range(100)], ["col1", "col2", "col3"]
    )
    df2.write.saveAsTable(cls.tbl_name2)
    df3 = cls.spark.createDataFrame(
        [(x, f"{x}") for x in range(100)], ["id", "test\n_column"]
    )
    df3.write.saveAsTable(cls.tbl_name3)
    df4 = cls.spark.createDataFrame(
        [(x, {"a": x}, [x, x * 2]) for x in range(100)],
        ["id", "map_column", "array_column"],
    )
    df4.write.saveAsTable(cls.tbl_name4)
    empty_table_schema = StructType(
        [
            StructField("firstname", StringType(), True),
            StructField("middlename", StringType(), True),
            StructField("lastname", StringType(), True),
        ]
    )

    # Create an empty DataFrame with the specified schema
    empty_df = cls.spark.createDataFrame(data=[], schema=empty_table_schema)
    empty_df.write.saveAsTable(cls.tbl_name_empty)

    # Disable the shared namespace so pyspark.sql.functions, etc point the regular
    # PySpark libraries.
    os.environ["PYSPARK_NO_NAMESPACE_SHARE"] = "1"

    cls.connect = cls.spark  # Switch Spark Connect session and regular PySpark session.
    # Disable Spark connect to create a local Spark Session.
    del os.environ["SPARK_CONNECT_MODE_ENABLED"]
    cls.spark = PySparkSession.builder.master("local[*]").getOrCreate()
    os.environ["SPARK_CONNECT_MODE_ENABLED"] = "true"
    assert cls.spark is not None

    cls.testData = [Row(key=i, value=str(i)) for i in range(100)]
    cls.testDataStr = [Row(key=str(i)) for i in range(100)]
    cls.df = cls.spark.sparkContext.parallelize(cls.testData).toDF()
    cls.df_text = cls.spark.sparkContext.parallelize(cls.testDataStr).toDF()

    # Cleanup test data for native spark
    cls.spark_connect_clean_up_test_data()
    # Load test data for native spark
    cls.spark_connect_load_test_data()
