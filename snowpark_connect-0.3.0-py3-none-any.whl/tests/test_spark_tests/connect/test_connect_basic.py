import sys
from typing import Any

import pytest
from pyspark.errors.exceptions.connect import (
    QueryExecutionException,
    SparkConnectGrpcException,
)
from pyspark.sql.tests.connect.test_connect_basic import SparkConnectBasicTests
from pyspark.testing.pandasutils import PandasOnSparkTestUtils

from tests.test_spark_tests.connect.utils import setup_class_for_sql_test_case


class SASSparkConnectBasicTests(SparkConnectBasicTests):
    """
    Tests are run via the parent class `SparkConnectBasicTests`. Any tests we
    expect to fail are defined here and marked with `@pytest.mark.xfail`. When
    a test passes, it should be removed here and run in via parent class.
    """

    def custom_assert_eq(
        self,
        left: Any,
        right: Any,
        check_exact: bool = True,
        almost: bool = False,
        rtol: float = 1e-5,
        atol: float = 1e-8,
        check_row_order: bool = True,
    ):
        """
        Custom implementation of assert_eq that handles snowpark and spark differences:
        1. Long vs integer type differences
        2. Different row ordering
        3. Float64/int64 vs object type differences.
        while maintaining the same behavior as the original for all other cases.

        TODO: This is a temporary solution until we resolve all the differences b/w sas and spark
        """
        try:
            if hasattr(left, "dtypes") and hasattr(right, "dtypes"):
                left_modified = left.copy()
                right_modified = right.copy()

                left_cols = list(left_modified.columns)
                right_cols = list(right_modified.columns)

                # Sort DataFrames if they have the same columns. Used for validating joins, distinct function etc.
                if set(left_cols) == set(right_cols):
                    left_modified = left_modified.sort_values(by=left_cols).reset_index(
                        drop=True
                    )
                    right_modified = right_modified.sort_values(
                        by=right_cols
                    ).reset_index(drop=True)

                for col in left.columns:
                    left_type = str(left[col].dtype)
                    right_type = str(right[col].dtype)

                    # Check if we have a long vs int mismatch
                    if "int64" in (left_type, right_type) and "int32" in (
                        left_type,
                        right_type,
                    ):
                        # Convert both to int64 for comparison
                        left_modified[col] = left_modified[col].astype("int64")
                        right_modified[col] = right_modified[col].astype("int64")

                    # float vs object mismatch
                    elif "float64" in (left_type, right_type) and "object" in (
                        left_type,
                        right_type,
                    ):
                        left_modified[col] = left_modified[col].astype("float64")
                        right_modified[col] = right_modified[col].astype("float64")

                    # int vs object mismatch
                    elif "int64" in (left_type, right_type) and "object" in (
                        left_type,
                        right_type,
                    ):
                        left_modified[col] = left_modified[col].astype("int64")
                        right_modified[col] = right_modified[col].astype("int64")

                    # int vs double mismatch
                    elif "int64" in (left_type, right_type) and "float64" in (
                        left_type,
                        right_type,
                    ):
                        left_modified[col] = left_modified[col].astype("float64")
                        right_modified[col] = right_modified[col].astype("float64")

                # Call original assert_eq with modified DataFrames
                original_assert_eq = self._original_assert_eq
                original_assert_eq(
                    left_modified,
                    right_modified,
                    check_exact,
                    almost,
                    rtol,
                    atol,
                    check_row_order,
                )
            else:
                original_assert_eq = self._original_assert_eq
                original_assert_eq(
                    left, right, check_exact, almost, rtol, atol, check_row_order
                )

        except AssertionError as e:
            raise e

    @classmethod
    def setUpClass(cls):
        setup_class_for_sql_test_case(cls)
        cls._original_assert_eq = PandasOnSparkTestUtils.assert_eq
        PandasOnSparkTestUtils.assert_eq = cls.custom_assert_eq

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        # Restore original assert_eq
        PandasOnSparkTestUtils.assert_eq = cls._original_assert_eq

    @pytest.mark.xfail
    def test_array_has_nullable(self):
        super().test_array_has_nullable()

    @pytest.mark.xfail
    def test_cast_with_ddl(self):
        super().test_cast_with_ddl()

    @pytest.mark.xfail
    def test_collect(self):
        super().test_collect()

    @pytest.mark.xfail
    def test_collect_nested_type(self):
        super().test_collect_nested_type()

    @pytest.mark.xfail
    def test_collect_timestamp(self):
        super().test_collect_timestamp()

    @pytest.mark.xfail
    def test_column_regexp(self):
        super().test_column_regexp()

    @pytest.mark.xfail
    def test_create_dataframe_from_pandas_with_ns_timestamp(self):
        super().test_create_dataframe_from_pandas_with_ns_timestamp()

    def test_create_empty_df(self):
        super().test_create_empty_df()

    @pytest.mark.xfail
    def test_create_global_temp_view(self):
        super().test_create_global_temp_view()

    @pytest.mark.xfail
    def test_create_session_local_temp_view(self):
        super().test_create_session_local_temp_view()

    @pytest.mark.xfail
    def test_csv(self):
        super().test_csv()

    def test_deduplicate(self):
        super().test_deduplicate()

    @pytest.mark.xfail
    def test_deduplicate_within_watermark_in_batch(self):
        super().test_deduplicate_within_watermark_in_batch()

    @pytest.mark.xfail
    def test_describe(self):
        super().test_describe()

    def test_df_get_item(self):
        super().test_df_get_item()

    def test_drop_na(self):
        super().test_drop_na()

    def test_empty_dataset(self):
        # same as super.test_empty_dataset() except that this uses assert_eq instead of equals on Pandas object.
        self.assert_eq(
            self.connect.sql("SELECT 1 AS X LIMIT 0").toPandas(),
            self.spark.sql("SELECT 1 AS X LIMIT 0").toPandas(),
        )

        pdf = self.connect.sql("SELECT 1 AS X LIMIT 0").toPandas()
        self.assertEqual(0, len(pdf))  # empty dataset
        self.assertEqual(1, len(pdf.columns))  # one column
        self.assertEqual("X", pdf.columns[0])

    def test_error_handling(self):
        with self.assertRaises(QueryExecutionException):
            super().test_error_handling()

    @pytest.mark.xfail
    def test_explain_string(self):
        super().test_explain_string()

    @pytest.mark.xfail
    def test_extended_hint_types(self):
        super().test_extended_hint_types()

    def test_fill_na(self):
        super().test_fill_na()

    @pytest.mark.xfail
    def test_grouped_data(self):
        super().test_grouped_data()

    @pytest.mark.xfail
    def test_hint(self):
        super().test_hint()

    @pytest.mark.xfail
    def test_input_files(self):
        super().test_input_files()

    def test_invalid_column(self):
        with self.assertRaises(SparkConnectGrpcException) as context:
            super().test_invalid_column()

        self.assertIn(
            "(AssertionError) resolving an attribute of a unresolved dataframe".lower(),
            str(context.exception).lower(),
        )

    @pytest.mark.xfail
    def test_is_local(self):
        super().test_is_local()

    @pytest.mark.xfail
    def test_is_streaming(self):
        super().test_is_streaming()

    def test_join_condition_column_list_columns(self):
        super().test_join_condition_column_list_columns()

    @pytest.mark.xfail
    def test_join_hint(self):
        super().test_join_hint()

    @pytest.mark.xfail
    def test_json(self):
        super().test_json()

    @pytest.mark.xfail
    def test_large_client_data(self):
        super().test_large_client_data()

    @pytest.mark.xfail
    def test_map_has_nullable(self):
        super().test_map_has_nullable()

    @pytest.mark.xfail
    def test_multi_paths(self):
        super().test_multi_paths()

    @pytest.mark.xfail
    def test_namedargs_with_global_limit(self):
        super().test_namedargs_with_global_limit()

    @pytest.mark.xfail
    def test_nested_type_create_from_rows(self):
        super().test_nested_type_create_from_rows()

    @pytest.mark.xfail
    def test_numeric_aggregation(self):
        super().test_numeric_aggregation()

    @pytest.mark.xfail
    def test_observe(self):
        super().test_observe()

    @pytest.mark.xfail
    def test_orc(self):
        super().test_orc()

    @pytest.mark.xfail
    def test_parquet(self):
        super().test_parquet()

    @pytest.mark.xfail
    def test_print_schema(self):
        super().test_print_schema()

    @pytest.mark.xfail
    def test_random_split(self):
        super().test_random_split()

    def test_repartition(self):
        super().test_repartition()

    @pytest.mark.xfail
    def test_repartition_by_expression(self):
        super().test_repartition_by_expression()

    @pytest.mark.xfail
    def test_repartition_by_range(self):
        super().test_repartition_by_range()

    def test_replace(self):
        with self.assertRaises(SparkConnectGrpcException) as context:
            super().test_replace()

        self.assertIsInstance(context.exception, SparkConnectGrpcException)
        self.assertIn(
            "Column name X does not exist".lower(), str(context.exception).lower()
        )

    @pytest.mark.xfail
    def test_same_semantics(self):
        super().test_same_semantics()

    @pytest.mark.xfail
    def test_schema(self):
        super().test_schema()

    @pytest.mark.xfail
    def test_schema_has_nullable(self):
        super().test_schema_has_nullable()

    def test_select_expr(self):
        super().test_select_expr()

    @pytest.mark.xfail
    def test_select_star(self):
        super().test_select_star()

    @pytest.mark.xfail
    def test_semantic_hash(self):
        super().test_semantic_hash()

    def test_session(self):
        super().test_session()

    @pytest.mark.xfail
    def test_simple_datasource_read(self):
        super().test_simple_datasource_read()

    @pytest.mark.xfail
    def test_simple_explain_string(self):
        super().test_simple_explain_string()

    @pytest.mark.xfail
    def test_simple_read_without_schema(self):
        super().test_simple_read_without_schema()

    @pytest.mark.xfail
    def test_simple_udt(self):
        super().test_simple_udt()

    @pytest.mark.xfail
    def test_simple_udt_from_read(self):
        super().test_simple_udt_from_read()

    def test_sort(self):
        super().test_sort()

    def test_sql(self):
        super().test_sql()

    @pytest.mark.xfail
    def test_sql_with_command(self):
        super().test_sql_with_command()

    @pytest.mark.xfail
    def test_sql_with_named_args(self):
        super().test_sql_with_named_args()

    @pytest.mark.xfail
    def test_sql_with_pos_args(self):
        super().test_sql_with_pos_args()

    @pytest.mark.xfail(
        sys.platform in ["darwin"],
        reason="Fails on macOS and local environments",
    )
    def test_stat_cov(self):
        super().test_stat_cov()

    @pytest.mark.xfail
    def test_stat_freq_items(self):
        super().test_stat_freq_items()

    @pytest.mark.xfail
    def test_stat_sample_by(self):
        super().test_stat_sample_by()

    @pytest.mark.xfail
    def test_streaming_local_relation(self):
        super().test_streaming_local_relation()

    @pytest.mark.xfail
    def test_struct_has_nullable(self):
        super().test_struct_has_nullable()

    @pytest.mark.xfail
    def test_subquery_alias(self):
        super().test_subquery_alias()

    def test_subtract(self):
        super().test_subtract()

    @pytest.mark.xfail(
        sys.platform in ["darwin"],
        reason="Fails on macOS and local environments",
    )
    def test_tail(self):
        super().test_tail()

    @pytest.mark.xfail
    def test_text(self):
        super().test_text()

    @pytest.mark.xfail
    def test_timestampe_create_from_rows(self):
        super().test_timestampe_create_from_rows()

    @pytest.mark.xfail
    def test_to(self):
        super().test_to()

    @pytest.mark.xfail
    def test_to_pandas(self):
        super().test_to_pandas()

    def test_unpivot(self):
        super().test_unpivot()

    @pytest.mark.xfail
    def test_with_atom_type(self):
        super().test_with_atom_type()

    @pytest.mark.xfail
    def test_with_columns(self):
        super().test_with_columns()

    @pytest.mark.xfail
    def test_with_local_list(self):
        super().test_with_local_list()

    @pytest.mark.xfail
    def test_with_local_ndarray(self):
        super().test_with_local_ndarray()

    @pytest.mark.xfail
    def test_with_metadata(self):
        super().test_with_metadata()

    @pytest.mark.xfail
    def test_with_none_and_nan(self):
        super().test_with_none_and_nan()

    @pytest.mark.xfail
    def test_write_operations(self):
        super().test_write_operations()


# Remove these from the namespace so pytest doesn't detect them and try to run them.
del SparkConnectBasicTests
