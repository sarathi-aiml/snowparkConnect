import pytest
from pyspark.sql.tests.connect.test_connect_column import SparkConnectColumnTests

from tests.test_spark_tests.connect.utils import setup_class_for_sql_test_case


class SASSparkConnectColumnTests(SparkConnectColumnTests):
    @classmethod
    def setUpClass(cls):
        setup_class_for_sql_test_case(cls)

    @pytest.mark.xfail
    def test_cast(self):
        super().test_cast()

    @pytest.mark.xfail
    def test_column_accessor(self):
        super().test_column_accessor()

    @pytest.mark.xfail
    def test_column_arithmetic_ops(self):
        super().test_column_arithmetic_ops()

    @pytest.mark.xfail
    def test_column_bitwise_ops(self):
        super().test_column_bitwise_ops()

    @pytest.mark.xfail
    def test_column_field_ops(self):
        super().test_column_field_ops()

    @pytest.mark.xfail
    def test_column_string_ops(self):
        super().test_column_string_ops()

    @pytest.mark.xfail
    def test_columns(self):
        super().test_columns()

    @pytest.mark.xfail
    def test_decimal(self):
        # Got different column name in below case, where column b is integer.
        # Probably spark does a type conversion in this case, which converts literal decimal 2.5 to integer 3.
        # self.assert_eq(
        #     cdf.select(cdf.b < decimal.Decimal(2.5)).toPandas(),
        #     sdf.select(sdf.b < decimal.Decimal(2.5)).toPandas(),
        # )
        # left =   (b < 2.5)
        # 0      True
        # 1      None
        # 2     False
        # right =   (b < 3)
        # 0    True
        # 1    None
        # 2   False
        super().test_decimal()

    @pytest.mark.xfail
    def test_distributed_sequence_id(self):
        super().test_distributed_sequence_id()

    @pytest.mark.xfail
    def test_isin(self):
        super().test_isin()

    @pytest.mark.xfail
    def test_literal_integers(self):
        super().test_literal_integers()

    @pytest.mark.xfail
    def test_literal_null(self):
        super().test_literal_null()

    @pytest.mark.xfail
    def test_with_field_column_name(self):
        super().test_with_field_column_name()


# Remove these from the namespace so pytest doesn't detect them and try to run them.
del SparkConnectColumnTests
