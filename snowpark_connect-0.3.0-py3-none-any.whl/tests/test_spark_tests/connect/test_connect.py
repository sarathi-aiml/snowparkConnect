import os

from pyspark.testing.connectutils import ReusedConnectTestCase
from pyspark.testing.pandasutils import PandasOnSparkTestUtils
from pyspark.testing.sqlutils import SQLTestUtils

from tests.test_spark_tests.connect.utils import (
    setup_class_for_reused_connect_test_case,
    setup_class_for_sql_test_case,
)

os.environ["SPARK_CONNECT_MODE_ENABLED"] = "true"


class SASReusedConnectTestCase(ReusedConnectTestCase):
    @classmethod
    def setUpClass(cls):
        setup_class_for_reused_connect_test_case(cls)


class SASSparkConnectSQLTestCase(
    SASReusedConnectTestCase, SQLTestUtils, PandasOnSparkTestUtils
):
    @classmethod
    def setUpClass(cls):
        setup_class_for_sql_test_case(cls)


# Remove these from the namespace so pytest doesn't detect them and try to run them.
del ReusedConnectTestCase, PandasOnSparkTestUtils, SQLTestUtils
