import os

import pytest
from pyspark.sql.session import SparkSession as PySparkSession
from pyspark.sql.tests.connect.test_connect_function import SparkConnectFunctionTests

from tests.test_spark_tests.connect.utils import (
    setup_class_for_reused_connect_test_case,
)


class SASSparkConnectFunctionTests(SparkConnectFunctionTests):
    @classmethod
    def setUpClass(cls):
        setup_class_for_reused_connect_test_case(cls)
        cls.connect = cls.spark
        # Disable the shared namespace so pyspark.sql.functions, etc point the regular
        # PySpark libraries.
        os.environ["PYSPARK_NO_NAMESPACE_SHARE"] = "1"
        # Disable Spark connect to create a local Spark Session.
        del os.environ["SPARK_CONNECT_MODE_ENABLED"]
        cls.spark = PySparkSession.builder.master("local[*]").getOrCreate()
        os.environ["SPARK_CONNECT_MODE_ENABLED"] = "true"
        assert cls.spark is not None

    @pytest.mark.xfail
    def test_aggregation_functions(self):
        super().test_aggregation_functions()

    @pytest.mark.xfail
    def test_broadcast(self):
        super().test_broadcast()

    @pytest.mark.xfail
    def test_call_udf(self):
        super().test_call_udf()

    @pytest.mark.xfail
    def test_collection_functions(self):
        super().test_collection_functions()

    @pytest.mark.xfail
    def test_csv_functions(self):
        super().test_csv_functions()

    @pytest.mark.xfail
    def test_date_ts_functions(self):
        super().test_date_ts_functions()

    @pytest.mark.xfail
    def test_generator_functions(self):
        super().test_generator_functions()

    @pytest.mark.xfail
    def test_json_functions(self):
        super().test_json_functions()

    @pytest.mark.xfail
    def test_lambda_functions(self):
        super().test_lambda_functions()

    @pytest.mark.xfail
    def test_map_collection_functions(self):
        super().test_map_collection_functions()

    @pytest.mark.xfail
    def test_math_functions(self):
        super().test_math_functions()

    @pytest.mark.xfail
    def test_misc_functions(self):
        super().test_misc_functions()

    @pytest.mark.xfail
    def test_nested_lambda_function(self):
        super().test_nested_lambda_function()

    @pytest.mark.xfail
    def test_normal_functions(self):
        super().test_normal_functions()

    @pytest.mark.xfail
    def test_sort_with_nulls_order(self):
        super().test_sort_with_nulls_order()

    @pytest.mark.xfail
    def test_string_functions_multi_args(self):
        super().test_string_functions_multi_args()

    @pytest.mark.xfail
    def test_string_functions_one_arg(self):
        super().test_string_functions_one_arg()

    @pytest.mark.xfail
    def test_time_window_functions(self):
        super().test_time_window_functions()

    @pytest.mark.xfail
    def test_udf(self):
        super().test_udf()

    @pytest.mark.xfail
    def test_udtf(self):
        super().test_udtf()

    @pytest.mark.xfail
    def test_window_functions(self):
        super().test_window_functions()

    @pytest.mark.xfail
    def test_window_order(self):
        super().test_window_order()


# Remove these from the namespace so pytest doesn't detect them and try to run them.
del SparkConnectFunctionTests
