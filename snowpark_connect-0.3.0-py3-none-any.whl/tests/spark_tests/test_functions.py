import io
from contextlib import redirect_stdout

import pyspark.sql.connect.functions as spark_fn
import pytest  # noqa: E402
from pyspark.errors import SparkRuntimeException
from pyspark.sql import Row
from pyspark.sql.connect.column import Column
from pyspark.sql.connect.window import Window
from pyspark.sql.tests import test_functions  # noqa: E402
from pyspark.testing.sqlutils import ReusedSQLTestCase  # noqa: E402

import snowpark_connect as sas
from tests.spark_tests.base_test import SasBaseTest


class TestSparkFunctionsTests(
    ReusedSQLTestCase, test_functions.FunctionsTestsMixin, SasBaseTest
):
    @classmethod
    def setUpClass(cls):
        cls.testData = [Row(key=i, value=str(i)) for i in range(100)]
        cls.spark = sas.get_session()
        cls.df = cls.spark.createDataFrame(cls.testData)
        SasBaseTest.setUpClass()

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()
        SasBaseTest.tearDownClass()

    def test_assert_true(self):
        # Apply the fix from
        # https://github.com/apache/spark/commit/578931678f5a6d6b33ebdae4bf866871e46fbb83#diff-a4984706554eae562eb0c7a66d284b1855d9bc463b03474f73493c7694244b66
        self.check_assert_true(SparkRuntimeException)

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_basic_functions(self):
        super().test_basic_functions()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_collect_functions(self):
        super().test_collect_functions()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_explode(self):
        super().test_explode()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_function_parity(self):
        super().test_function_parity()

    def test_functions_broadcast(self):
        df1 = self.spark.createDataFrame([(1, "1"), (2, "2")], ("key", "value"))
        df2 = self.spark.createDataFrame([(1, "1"), (2, "2")], ("key", "value"))

        # Snowflake does not support join hint, so Broadcast won't appear in the plan
        with io.StringIO() as buf, redirect_stdout(buf):
            df1.join(spark_fn.broadcast(df2), "key").explain(True)
            self.assertGreaterEqual(buf.getvalue().count("Broadcast"), 0)
            self.assertGreaterEqual(buf.getvalue().count("InnerJoin"), 1)

        # no join key -- should not be a broadcast join
        with io.StringIO() as buf, redirect_stdout(buf):
            df1.crossJoin(spark_fn.broadcast(df2)).explain(True)
            self.assertGreaterEqual(buf.getvalue().count("Broadcast"), 0)
            self.assertGreaterEqual(buf.getvalue().count("CartesianJoin"), 1)

        # planner should not crash without a join
        spark_fn.broadcast(df1).explain(True)

    @pytest.mark.skip("Not deterministic")
    def test_first_last_ignorenulls(self):
        super().test_first_last_ignorenulls()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_inline(self):
        super().test_inline()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_input_file_name_reset_for_rdd(self):
        super().test_input_file_name_reset_for_rdd()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_input_file_name_udf(self):
        super().test_input_file_name_udf()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_levenshtein_function(self):
        super().test_levenshtein_function()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_lit_day_time_interval(self):
        super().test_lit_day_time_interval()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_lit_list(self):
        super().test_lit_list()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_map_functions(self):
        super().test_map_functions()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_ndarray_input(self):
        super().test_ndarray_input()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_nested_higher_order_function(self):
        super().test_nested_higher_order_function()

    def test_raise_error(self):
        # Apply the fix from
        # https://github.com/apache/spark/commit/578931678f5a6d6b33ebdae4bf866871e46fbb83#diff-a4984706554eae562eb0c7a66d284b1855d9bc463b03474f73493c7694244b66
        self.check_raise_error(SparkRuntimeException)

    @pytest.mark.skip("TODO - take care of it, right now skipping since it's flaky")
    def test_sampleby(self):
        super().test_sampleby()

    def test_sorting_functions_with_column(self):
        # assert column to be Spark connect column
        self.check_sorting_functions_with_column(Column)

    def test_window_functions(self):
        # Copied from super().test_window_functions(). Only modified expected output.
        df = self.spark.createDataFrame(
            [(1, "1"), (2, "2"), (1, "2"), (1, "2")], ["key", "value"]
        )
        w = Window.partitionBy("value").orderBy("key")

        sel = df.select(
            df.value,
            df.key,
            spark_fn.max("key").over(w.rowsBetween(0, 1)),
            spark_fn.min("key").over(w.rowsBetween(0, 1)),
            spark_fn.count("key").over(w.rowsBetween(float("-inf"), float("inf"))),
            spark_fn.row_number().over(w),
            spark_fn.rank().over(w),
            spark_fn.dense_rank().over(w),
            spark_fn.ntile(2).over(w),
        )
        rs = sorted(sel.collect())
        expected = [
            ("1", 1, 1, 1, 1, 1, 1, 1, 1),
            ("2", 1, 1, 1, 3, 2, 1, 1, 1),
            ("2", 1, 2, 1, 3, 1, 1, 1, 1),
            ("2", 2, 2, 2, 3, 3, 3, 2, 2),
        ]
        # Spark's output is:
        #  ("1", 1, 1, 1, 1, 1, 1, 1, 1),
        #  ("2", 1, 1, 1, 3, 1, 1, 1, 1),
        #  ("2", 1, 2, 1, 3, 2, 1, 1, 1),
        #  ("2", 2, 2, 2, 3, 3, 3, 2, 2),
        # Snowflake's SQL engine behaves differently from Spark's engine.
        # And I believe Spark's output is correct, because looking at column MAX and ROW_NUMBER:
        # Snowflake's engine appears to be first partitioning, then perform MAX and ROW_NUMBER, then sort.
        # Spark's engine appears to be first partitioning, then sort, then perform MAX and ROW_NUMBER.
        # The generated SQL is correct, so there is nothing we can do to fix it:
        # SELECT "VALUESES1", "KEYSES0",
        #     max("KEYSES0") OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST  ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING  ),
        #     min("KEYSES0") OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST  ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING  ),
        #     count("KEYSES0") OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST  ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING ),
        #     row_number() OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST ),
        #     rank() OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST ),
        #     dense_rank() OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST ),
        #     ntile(2) OVER (PARTITION BY "VALUESES1"  ORDER BY "KEYSES0" ASC NULLS FIRST )
        #       FROM ( SELECT "KEYSES0" AS "KEYSES0", "VALUESES1" AS "VALUESES1" FROM
        #       ( SELECT $1 AS "KEYSES0", $2 AS "VALUESES1" FROM  VALUES (1 :: INT, '1' :: STRING), (2 :: INT, '2' :: STRING), (1 :: INT, '2' :: STRING), (1 :: INT, '2' :: STRING)));
        for r, ex in zip(rs, expected):
            self.assertEqual(tuple(r), ex[: len(r)])

    @pytest.mark.xfail(reason="Does not work in Snowpark")
    def test_window_functions_cumulative_sum(self):
        # GS throws error: 002305 Window frame requires an ORDER BY clause.
        # TODO: We might need to add a special inference that when the input function
        #   only have one argument, we should use that argument as the ordering column.
        #   This seems to be Spark's behavior when orderBy is not provided.
        super().test_window_functions_cumulative_sum()

    def test_window_functions_without_partitionBy(self):
        # Copied from super().test_window_functions_without_partitionBy().
        # Only modified expected output.
        df = self.spark.createDataFrame(
            [(1, "1"), (2, "2"), (1, "2"), (1, "2")], ["key", "value"]
        )
        w = Window.orderBy("key", df.value)

        sel = df.select(
            df.value,
            df.key,
            spark_fn.max("key").over(w.rowsBetween(0, 1)),
            spark_fn.min("key").over(w.rowsBetween(0, 1)),
            spark_fn.count("key").over(w.rowsBetween(float("-inf"), float("inf"))),
            spark_fn.row_number().over(w),
            spark_fn.rank().over(w),
            spark_fn.dense_rank().over(w),
            spark_fn.ntile(2).over(w),
        )
        rs = sorted(sel.collect())
        expected = [
            ("1", 1, 1, 1, 4, 1, 1, 1, 1),
            ("2", 1, 1, 1, 4, 3, 2, 2, 2),
            ("2", 1, 2, 1, 4, 2, 2, 2, 1),
            ("2", 2, 2, 2, 4, 4, 4, 3, 2),
        ]
        # Same issue in expected output described in test_window_functions
        for r, ex in zip(rs, expected):
            self.assertEqual(tuple(r), ex[: len(r)])

    @pytest.mark.xfail(reason="Does not work in Snowpark")
    def test_window_time(self):
        # Snowpark does not have function.window, but Spark have.
        super().test_window_time()
