import os
import time

import numpy as np
import pytest
from pyspark.errors.exceptions.connect import SparkConnectGrpcException
from pyspark.sql import Row
from pyspark.sql.tests import test_dataframe
from pyspark.testing.sqlutils import ReusedSQLTestCase

import snowpark_connect as sas
from snowflake.snowpark.exceptions import SnowparkSQLException
from tests.spark_tests.base_test import SasBaseTest


class TestSparkDataFrameTests(
    ReusedSQLTestCase, test_dataframe.DataFrameTestsMixin, SasBaseTest
):
    @classmethod
    def setUpClass(cls):
        cls.testData = [Row(key=i, value=str(i)) for i in range(100)]
        cls.spark = sas.get_session()
        cls.df = cls.spark.createDataFrame(cls.testData)
        SasBaseTest.setUpClass()

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()
        SasBaseTest.tearDownClass()

    def assertRaises(self, exception, func=None, *args, **kwargs):
        if func is None:
            return super().assertRaises((SparkConnectGrpcException, exception))
        else:
            return super().assertRaises(
                (SparkConnectGrpcException, exception), func, *args, **kwargs
            )

    def check_error(self, exception, error_class, message_parameters):
        """
        For now we are not testing the error messages.

        Spark Connect adds some additional information to the error messages, so we will
        need to override this method to check the error messages.
        """
        pass

    def check_to_pandas_with_duplicated_column_names(self):
        """This is called by `test_to_pandas_with_duplicated_column_names`."""
        sql = "select 1 v, 1 v"
        df = self.spark.sql(sql)
        pdf = df.toPandas()
        types = pdf.dtypes
        # We return `int64` instead of `int32`, so we will override this check.
        self.assertEqual(types.iloc[0], np.int64)
        self.assertEqual(types.iloc[1], np.int64)
        # Spark doesn't check the column names, but we should.
        self.assertEqual(list(df.columns), ["v", "v"])

    def check_to_pandas_on_cross_join(self):
        sql = """
                select t1.*, t2.* from (
                  select explode(sequence(1, 3)) v
                ) t1 left join (
                  select explode(sequence(1, 3)) v
                ) t2
                """
        with self.sql_conf({"spark.sql.crossJoin.enabled": True}):
            df = self.spark.sql(sql)
            pdf = df.toPandas()
            types = pdf.dtypes
            # We return `int64` instead of `int32`, so we will override this check.
            self.assertEqual(types.iloc[0], np.int64)
            self.assertEqual(types.iloc[1], np.int64)
            # Spark doesn't check the column names, but we should.
            self.assertEqual(list(df.columns), ["v", "v"])

    @pytest.mark.xfail
    def test_to_pandas_on_cross_join(self):
        super().test_to_pandas_on_cross_join()

    @pytest.mark.xfail
    def test_to_pandas_on_duplicate_columns(self):
        for arrow_enabled in [False, True]:
            with self.sql_conf(
                {"spark.sql.execution.arrow.pyspark.enabled": arrow_enabled}
            ):
                self.check_to_pandas_on_duplicate_columns()

    def check_to_pandas_on_duplicate_columns(self):
        sql = """
                  select explode(sequence(1, 3)) v, explode(sequence(1, 3)) v
                """
        with self.sql_conf({"spark.sql.crossJoin.enabled": True}):
            df = self.spark.sql(sql)
            pdf = df.toPandas()
            types = pdf.dtypes
            # We return `int64` instead of `int32`, so we will override this check.
            self.assertEqual(types.iloc[0], np.int64)
            self.assertEqual(types.iloc[1], np.int64)
            # Spark doesn't check the column names, but we should.
            self.assertEqual(list(df.columns), ["v", "v"])

    @pytest.mark.skip("Out of Scope for Sas")
    def test_help_command(self):
        return super().test_help_command()

    def test_cache_dataframe(self):
        # We don't call the test in the super class for cache, because the test cases
        # in the super class is verifying the behavior of StorageLevel.
        # In our case we are ignoring that parameter and thus there is no need to test that.
        df1 = self.spark.createDataFrame(
            [
                Row(a=1, b=2.0, c="foo"),
                Row(a=2, b=None, c="bar"),
                Row(a=None, b=5.0, c="baz"),
            ]
        )
        # Assert that cache is treated as an action
        with self.assertRaises(SnowparkSQLException):
            df1.select("dummy").cache()

        # TODO: fix error message `invalid identifier 'NO_EXIST'`
        with self.assertRaises(SnowparkSQLException):
            df1.select("dummy").persist()

        df2 = df1.select("a", "c").cache()
        df3 = df2.select("c")
        rs = df3.collect()
        expected = [
            ("foo",),
            ("bar",),
            ("baz",),
        ]
        # Same issue in expected output described in test_window_functions
        for r, ex in zip(rs, expected):
            self.assertEqual(tuple(r), ex[: len(r)])

    @pytest.mark.skip("Out of Scope for Sas")
    def test_cache_table(self):
        return super().test_cache_table()

    @pytest.mark.xfail(reason="SNOW-1883371")
    def test_create_dataframe_from_pandas_with_day_time_interval(self):
        # Snowpark does not support interval type.
        # TODO: Use pandas on Snowflake's time interval type.
        return super().test_create_dataframe_from_pandas_with_day_time_interval()

    @pytest.mark.xfail(reason="SNOW-1883371")
    def test_to_pandas(self):
        # Snowpark does not support interval type.
        return super().test_to_pandas()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_toDF_with_schema_string(self):
        # No RDD support yet.
        return super().test_toDF_with_schema_string()

    # Regression test for SPARK-23360
    def test_create_dataframe_from_pandas_with_dst(self):
        from datetime import datetime

        import pandas as pd
        from pandas.testing import assert_frame_equal

        pdf = pd.DataFrame({"time": [datetime(2015, 10, 31, 22, 30)]})

        df = self.spark.createDataFrame(pdf)
        assert_frame_equal(pdf, df.toPandas())

        orig_env_tz = os.environ.get("TZ", None)
        try:
            tz = "America/Los_Angeles"
            os.environ["TZ"] = tz
            if os.name != "nt":
                # set time.tzset() only for non-windows environment
                # Windows does not have tzset() method
                # >           time.tzset()
                # E           AttributeError: module 'time' has no attribute 'tzset'
                time.tzset()
            with self.sql_conf({"spark.sql.session.timeZone": tz}):
                df = self.spark.createDataFrame(pdf)
                assert_frame_equal(pdf, df.toPandas())
        finally:
            del os.environ["TZ"]
            if orig_env_tz is not None:
                os.environ["TZ"] = orig_env_tz
            if os.name != "nt":
                # set time.tzset() only for non-windows environment
                # Windows does not have tzset() method
                # >           time.tzset()
                # E           AttributeError: module 'time' has no attribute 'tzset'
                time.tzset()

    def test_to_local_iterator_not_fully_consumed(self):
        # removes with QuietTest(self.sc), the QuietTest tries to
        # silent the log4j logs, which accesses the jvm process. This
        # is not needed here since we do not need spark.
        self.check_to_local_iterator_not_fully_consumed()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_duplicate_field_names(self):
        return super().test_duplicate_field_names()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_extended_hint_types(self):
        return super().test_extended_hint_types()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_generic_hints(self):
        return super().test_generic_hints()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_input_files(self):
        return super().test_input_files()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_observe(self):
        return super().test_observe()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_observe_str(self):
        return super().test_observe_str()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_pandas_api(self):
        return super().test_pandas_api()

    def test_print_schema(self):
        return super().test_print_schema()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_repartitionByRange_dataframe(self):
        return super().test_repartitionByRange_dataframe()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_repr_behaviors(self):
        return super().test_repr_behaviors()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_same_semantics_error(self):
        return super().test_same_semantics_error()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_sample_with_random_seed(self):
        return super().test_sample_with_random_seed()

    @pytest.mark.xfail(reason="Mark as expected to fail to pass merge gates")
    def test_to(self):
        return super().test_to()
