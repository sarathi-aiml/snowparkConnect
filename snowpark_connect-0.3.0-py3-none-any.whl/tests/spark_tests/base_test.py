import unittest
from datetime import datetime
from typing import Any

import numpy as np
import pandas
import pandas as pd
from pyspark.sql.types import (
    ArrayType,
    IntegerType,
    LongType,
    MapType,
    Row,
    ShortType,
    StructField,
    StructType,
)
from pyspark.testing.pandasutils import PandasOnSparkTestUtils


class SasBaseTest(unittest.TestCase):
    """
    Base class for Sas Spark tests.
    """

    # if the compared pairs falls into these pairs, normalize them to the first value
    NORMALIZE_PAIRS = [
        ("int64", "int32"),  # Check if we have a long vs int mismatch
        ("int64", "int16"),  # Check if we have a long vs short mismatch
        ("int64", "int8"),  # Check if we have a long vs byte mismatch
        ("float64", "object"),  # float vs object mismatch
        ("int64", "object"),  # int vs object mismatch
        ("float64", "int64"),  # int vs double mismatch
        ("float64", "float32"),  # float vs double mismatch
    ]

    @classmethod
    def setUpClass(cls):
        cls._original_assert_eq = PandasOnSparkTestUtils.assert_eq
        PandasOnSparkTestUtils.assert_eq = cls.custom_assert_eq
        cls._original_assert_equal = unittest.TestCase.assertEqual
        unittest.TestCase.assertEqual = cls.custom_assert_equal

    @classmethod
    def tearDownClass(cls):
        # Restore original assert_eq
        PandasOnSparkTestUtils.assert_eq = cls._original_assert_eq
        unittest.TestCase.assertEqual = cls._original_assert_equal

    def normalize_type_pairs(
        self,
        left: Any,
        right: Any,
    ):
        # normalize type pairs
        _left = np.dtype(left) if isinstance(left, type) else left
        _right = np.dtype(right) if isinstance(right, type) else right
        # ^ These type -> dtype normalization is temporary solution. # TODO: SNOW-1883380
        # right = <class 'numpy.int32'>
        # np.dtype(right) = dtype('int32')

        if (
            _left == _right
            or not isinstance(_left, np.dtype)
            or not isinstance(_right, np.dtype)
        ):
            return None, None  # No need to change

        left_type = str(_left)
        right_type = str(_right)

        for super_type, sub_type in self.NORMALIZE_PAIRS:
            if super_type in (left_type, right_type) and sub_type in (
                left_type,
                right_type,
            ):
                left_type = super_type
                right_type = super_type

        return left_type, right_type

    def custom_assert_eq(
        self,
        left: Any,
        right: Any,
        check_exact: bool = True,
        almost: bool = False,
        rtol: float = 1e-5,
        atol: float = 1e-8,
        check_row_order: bool = True,
    ):
        """
        Custom implementation of assert_eq that handles snowpark and spark differences:
        1. Long vs integer type differences: SNOW-1877072
        2. Different row ordering during join or distinct functions: SNOW-1875241
        3. Float64/int64 vs object type differences.
        while maintaining the same behavior as the original for all other cases.

        TODO: This is a temporary solution until we resolve all the differences b/w sas and spark
        """
        try:
            if hasattr(left, "dtypes") and hasattr(right, "dtypes"):
                left_modified = left.copy()
                right_modified = right.copy()

                left_cols = list(left_modified.columns)
                right_cols = list(right_modified.columns)

                # Sort DataFrames if they have the same columns. Used for validating joins, distinct function etc.
                if set(left_cols) == set(right_cols):
                    left_modified = left_modified.sort_values(
                        by=self._get_hashable_columns(
                            left_modified
                        ),  # Ignore columns with non-hashable types, e.g. np.ndarray, bytearray
                    ).reset_index(drop=True)

                    right_modified = right_modified.sort_values(
                        by=self._get_hashable_columns(right_modified),
                    ).reset_index(drop=True)

                for col in left.columns:
                    new_left_type, new_right_type = self.normalize_type_pairs(
                        left[col].dtype, right[col].dtype
                    )

                    if new_left_type is None:
                        continue

                    left_modified[col] = left_modified[col].astype(new_left_type)
                    right_modified[col] = right_modified[col].astype(new_right_type)

                    if "float" in new_left_type:
                        left_modified[col] = left_modified[col].round(6)
                    if "float" in new_right_type:
                        right_modified[col] = right_modified[col].round(6)

                if set(left_cols) == set(right_cols) and isinstance(
                    left_modified, pandas.DataFrame
                ):
                    # sort the column order
                    left_modified = left_modified[left_cols]
                    right_modified = right_modified[left_cols]
                # Call original assert_eq with modified DataFrames
                original_assert_eq = self._original_assert_eq
                original_assert_eq(
                    left_modified,
                    right_modified,
                    check_exact,
                    almost,
                    rtol,
                    atol,
                    check_row_order,
                )
            else:
                original_assert_eq = self._original_assert_eq
                original_assert_eq(
                    left, right, check_exact, almost, rtol, atol, check_row_order
                )

        except AssertionError as e:
            raise e

    def custom_assert_equal(self, left, right, msg=None):
        """
        Custom assertEqual that handles:
        1. StructType comparison with int/long type equality. SNOW-1877072
        2. pandas Timestamp vs datetime.datetime equality. SNOW-1846317
        Converts different types to unified types before comparison.

        TODO: Remove this once we resolve the linked JIRA's
        """
        original_assert_equal = self._original_assert_equal

        def compare_rows(left, right):
            """Compare lists of Row objects."""
            if len(left) != len(right):
                original_assert_equal(left, right, msg)
                return

            modified_left = []
            modified_right = []

            for left_row, right_row in zip(left, right):
                left_values = list(left_row)
                right_values = list(right_row)

                if len(left_values) != len(right_values):
                    original_assert_equal(left, right, msg)
                    return

                modified_left_values = []
                modified_right_values = []

                for left_val, right_val in zip(left_values, right_values):
                    # Handle datetime conversion, where sas returns Panda's
                    # Timestamp and native spark returns datetime.datetime
                    if isinstance(left_val, (datetime, pd.Timestamp)) and isinstance(
                        right_val, (datetime, pd.Timestamp)
                    ):
                        if isinstance(left_val, pd.Timestamp):
                            if left_val.to_pydatetime() != right_val:
                                # there are a few cases pandas returns PST timestamp instead of UTC.
                                # This logic converts it back to UTC
                                left_val = (
                                    left_val.tz_localize("UTC")
                                    .tz_convert("US/Pacific")
                                    .to_pydatetime()
                                    .replace(tzinfo=None)
                                )
                            else:
                                left_val = left_val.to_pydatetime().replace(tzinfo=None)
                        if isinstance(right_val, pd.Timestamp):
                            right_val = right_val.to_pydatetime()
                        modified_left_values.append(left_val)
                        modified_right_values.append(right_val)
                    else:
                        modified_left_values.append(left_val)
                        modified_right_values.append(right_val)

                modified_left.append(Row(*modified_left_values))
                modified_right.append(Row(*modified_right_values))

            original_assert_equal(modified_left, modified_right, msg)

        def convert_field(field):
            """Convert StructField to unified types for comparison."""
            if isinstance(field.dataType, (ShortType, IntegerType, LongType)):
                return StructField(field.name, LongType(), True, field.metadata)
            elif isinstance(field.dataType, (pd.Timestamp, datetime)):
                return StructField(field.name, type(datetime), True, field.metadata)
            elif isinstance(field.dataType, StructType):
                return StructField(
                    field.name,
                    convert_struct_type(field.dataType),
                    True,
                    field.metadata,
                )
            elif isinstance(field.dataType, ArrayType) and isinstance(
                field.dataType.elementType, (LongType, IntegerType)
            ):
                return StructField(
                    field.name, ArrayType(LongType()), True, field.metadata
                )
            elif isinstance(field.dataType, MapType) and isinstance(
                field.dataType.valueType, (LongType, IntegerType)
            ):
                return StructField(
                    field.name,
                    MapType(field.dataType.keyType, LongType()),
                    True,
                    field.metadata,
                )
            return StructField(field.name, field.dataType, True, field.metadata)

        def convert_struct_type(struct_type):
            """Convert StructType to unified types for comparison."""
            return StructType([convert_field(field) for field in struct_type.fields])

        def compare_struct_types(left, right):
            """Compare StructType objects, including nested StructType."""
            if len(left.fields) != len(right.fields):
                original_assert_equal(left, right, msg)
                return
            left_modified = convert_struct_type(left)
            right_modified = convert_struct_type(right)

            original_assert_equal(left_modified, right_modified, msg)

        # Handle lists of Row objects
        if (
            isinstance(left, list)
            and isinstance(right, list)
            and left
            and right
            and isinstance(left[0], Row)
            and isinstance(right[0], Row)
        ):
            compare_rows(left, right)
            return

        # Handle StructType comparisons
        if isinstance(left, StructType) and isinstance(right, StructType):
            compare_struct_types(left, right)
            return

        # Compare list[pyspark.sql.Row] instances.
        # handle StructType comparisons
        # Test Case to match test_lit_np_scalar testing format
        # (np.int8, [("1", "tinyint")]),
        if (
            isinstance(left, list)
            and isinstance(right, list)
            and len(left) == 1
            and len(right) == 1
            and len(left[0]) == len(right[0]) == 2
        ):
            if len(left) != len(right):
                original_assert_equal(left, right, msg)
                return

            left_modified = left.copy()
            right_modified = right.copy()

            for (left_value, left_type), (right_value, right_type) in zip(left, right):
                # Check if we have a smallint vs bigint mismatch
                if "smallint" in (left_type, right_type) and "bigint" in (
                    left_type,
                    right_type,
                ):
                    # Convert both to bigint for comparison
                    left_modified[0] = left[0][:1] + ("bigint",)
                    right_modified[0] = right[0][:1] + ("bigint",)

                # Check if we have a tinyint vs bigint mismatch
                elif "tinyint" in (left_type, right_type) and "bigint" in (
                    left_type,
                    right_type,
                ):
                    # Convert both to bigint for comparison
                    left_modified[0] = left[0][:1] + ("bigint",)
                    right_modified[0] = right[0][:1] + ("bigint",)

                # Check if we have a int vs bigint mismatch
                elif "int" in (left_type, right_type) and "bigint" in (
                    left_type,
                    right_type,
                ):
                    # Convert both to bigint for comparison
                    left_modified[0] = left[0][:1] + ("bigint",)
                    right_modified[0] = right[0][:1] + ("bigint",)

                # Check if we have a double vs float mismatch
                elif "double" in (left_type, right_type) and "float" in (
                    left_type,
                    right_type,
                ):
                    # Convert both to float for comparison
                    left_modified[0] = left[0][:1] + ("float",)
                    right_modified[0] = right[0][:1] + ("float",)

                # Check if we have a True vs true mismatch
                elif "True" in (left_value, right_value) and "true" in (
                    left_value,
                    right_value,
                ):
                    # Convert both to True for comparison
                    left_modified[0] = ("True",) + left[0][1:]
                    right_modified[0] = ("True",) + right[0][1:]

                # Check if we have a False vs false mismatch
                elif "False" in (left_value, right_value) and "false" in (
                    left_value,
                    right_value,
                ):
                    # Convert both to False for comparison
                    left_modified[0] = ("False",) + left[0][1:]
                    right_modified[0] = ("False",) + right[0][1:]

                original_assert_equal(left_modified, right_modified, msg)
        else:
            if (isinstance(left, type) or isinstance(left, np.dtype)) and (
                isinstance(right, type) or isinstance(right, np.dtype)
            ):
                _left, _right = self.normalize_type_pairs(left, right)
                original_assert_equal(_left, _right, msg)
            else:
                original_assert_equal(left, right, msg)

    def _get_hashable_columns(self, df: pd.DataFrame) -> list[str]:
        """
        Returns a list of column names, which consist only of hashable values.
        """

        return [col for col in df.columns if self._is_series_hashable(df[col])]

    def _is_series_hashable(self, series: pd.Series) -> bool:
        """
        Returns a boolean indicating whether all values in the series are hashable
        """

        return all(self._is_hashable(value) for value in series)

    @staticmethod
    def _is_hashable(value: Any) -> bool:
        """
        Returns a boolean indicating whether the value is hashable.
        """

        try:
            hash(value)
            return True
        except TypeError:
            return False
