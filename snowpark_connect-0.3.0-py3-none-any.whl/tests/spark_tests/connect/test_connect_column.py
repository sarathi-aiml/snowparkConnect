import decimal

import pytest
from pyspark.errors import PySparkTypeError
from pyspark.sql.tests.connect.test_connect_column import SparkConnectColumnTests
from pyspark.sql.types import (
    BooleanType,
    ByteType,
    DecimalType,
    DoubleType,
    FloatType,
    IntegerType,
    LongType,
    ShortType,
    StringType,
)

from tests.spark_tests.base_test import SasBaseTest
from tests.spark_tests.connect.utils import setup_class_for_sql_test_case


class SASSparkConnectColumnTests(SparkConnectColumnTests, SasBaseTest):
    @classmethod
    def setUpClass(cls):
        setup_class_for_sql_test_case(cls)
        SasBaseTest.setUpClass()

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        SasBaseTest.tearDownClass()

    def test_cast(self):
        # SPARK-41412: test basic Column.cast
        df = self.connect.read.table(self.tbl_name)
        df2 = self.spark.read.table(self.tbl_name)

        self.assert_eq(
            df.select(df.id.cast("string")).toPandas(),
            df2.select(df2.id.cast("string")).toPandas(),
        )
        self.assert_eq(
            df.select(df.id.astype("string")).toPandas(),
            df2.select(df2.id.astype("string")).toPandas(),
        )

        for x in [
            StringType(),
            ShortType(),
            IntegerType(),
            LongType(),
            FloatType(),
            DoubleType(),
            ByteType(),
            DecimalType(10, 2),
            BooleanType(),
            # Snowpark is not supporitng Interval types
            # DayTimeIntervalType(),
        ]:
            self.assert_eq(
                df.select(df.id.cast(x)).orderBy("id").toPandas(),
                df2.select(df2.id.cast(x)).orderBy("id").toPandas(),
            )

        with self.assertRaises(PySparkTypeError) as pe:
            df.id.cast(10)

        self.check_error(
            exception=pe.exception,
            error_class="NOT_DATATYPE_OR_STR",
            message_parameters={"arg_name": "dataType", "arg_type": "int"},
        )

    @pytest.mark.xfail
    def test_column_accessor(self):
        super().test_column_accessor()

    @pytest.mark.xfail
    def test_column_arithmetic_ops(self):
        super().test_column_arithmetic_ops()

    @pytest.mark.xfail
    def test_column_field_ops(self):
        super().test_column_field_ops()

    def test_decimal(self):
        # Got different column name in below case, where column b is integer.
        # Probably spark does a type conversion in this case, which converts literal decimal 2.5 to integer 3.
        # self.assert_eq(
        #     cdf.select(cdf.b < decimal.Decimal(2.5)).toPandas(),
        #     sdf.select(sdf.b < decimal.Decimal(2.5)).toPandas(),
        # )
        # left =   (b < 2.5)
        # 0      True
        # 1      None
        # 2     False
        # right =   (b < 3)
        # 0    True
        # 1    None
        # 2   False
        # SPARK-41701: test decimal
        query = """
            SELECT * FROM VALUES
            (1, 1, 0, NULL), (2, NULL, 1, 2.0), (3, 3, 4, 3.5)
            AS tab(a, b, c, d)
            """
        # +---+----+---+----+
        # |  a|   b|  c|   d|
        # +---+----+---+----+
        # |  1|   1|  0|NULL|
        # |  2|NULL|  1| 2.0|
        # |  3|   3|  4| 3.5|
        # +---+----+---+----+

        cdf = self.connect.sql(query)
        sdf = self.spark.sql(query)

        self.assert_eq(
            cdf.select(cdf.a < decimal.Decimal(3)).toPandas(),
            sdf.select(sdf.a < decimal.Decimal(3)).toPandas(),
        )
        self.assert_eq(
            cdf.select(cdf.a != decimal.Decimal(2)).toPandas(),
            sdf.select(sdf.a != decimal.Decimal(2)).toPandas(),
        )
        self.assert_eq(
            cdf.select(cdf.a == decimal.Decimal(2)).toPandas(),
            sdf.select(sdf.a == decimal.Decimal(2)).toPandas(),
        )

        # sprak convert decimal.Decimal(2.5) to 3.0
        # self.assert_eq(
        #    cdf.select(cdf.b < decimal.Decimal(2.5)).toPandas(),
        #    sdf.select(sdf.b < decimal.Decimal(2.5)).toPandas(),
        # )
        self.assert_eq(
            cdf.select(cdf.d >= decimal.Decimal(3.0)).toPandas(),
            sdf.select(sdf.d >= decimal.Decimal(3.0)).toPandas(),
        )

    @pytest.mark.skip("Out of Scope for Sas")
    def test_distributed_sequence_id(self):
        super().test_distributed_sequence_id()

    def test_isin(self):
        super().test_isin()

    @pytest.mark.xfail
    def test_literal_null(self):
        super().test_literal_null()

    @pytest.mark.xfail
    def test_with_field_column_name(self):
        super().test_with_field_column_name()


# Remove these from the namespace so pytest doesn't detect them and try to run them.
del SparkConnectColumnTests
