import os

import pytest
from pyspark.sql import Row, SparkSession
from pyspark.sql.connect.session import SparkSession as SparkConnectSession

import snowpark_connect
from snowpark_connect.server import UnixDomainSocketChannelBuilder


@pytest.skip(
    "gRPC server needs to be restarted for each of these tests as they re-configure the endpoint on which gRPC server listens. Run them individually AFTER commenting snowpark_connect.start_session() in conftest.py. They should all pass.",
    allow_module_level=True,
)
def test_tcp_port_in_spark_remote_env():
    os.environ["SPARK_REMOTE"] = "sc://localhost:15002"
    snowpark_connect.start_session()
    spark = SparkSession.builder.appName("SAS").getOrCreate()
    df = spark.createDataFrame(
        [
            Row(a=1, b=2.0),
        ]
    )
    df.show()


def test_tcp_port_in_spark_remote_env_with_param():
    os.environ["SPARK_REMOTE"] = "sc://localhost:15002/;user_id=me_the_user"
    snowpark_connect.start_session()
    spark = SparkSession.builder.appName("SAS").getOrCreate()
    df = spark.createDataFrame(
        [
            Row(a=1, b=2.0),
        ]
    )
    df.show()


def test_unix_domain_socket_in_spark_remote_env():
    os.environ["SPARK_REMOTE"] = "unix:/tmp/sas-grpc.sock"
    snowpark_connect.start_session()
    spark = (
        SparkConnectSession.builder.appName("SAS")
        .channelBuilder(UnixDomainSocketChannelBuilder())
        .getOrCreate()
    )
    df = spark.createDataFrame(
        [
            Row(a=1, b=2.0),
        ]
    )
    df.show()


def test_unix_domain_socket_in_spark_remote_env_with_param():
    os.environ["SPARK_REMOTE"] = "unix:/tmp/sas-grpc.sock;user_id=me_the_user"
    snowpark_connect.start_session()
    spark = (
        SparkConnectSession.builder.appName("SAS")
        .channelBuilder(UnixDomainSocketChannelBuilder())
        .getOrCreate()
    )
    df = spark.createDataFrame(
        [
            Row(a=1, b=2.0),
        ]
    )
    df.show()


def test_tcp_port_with_remote_spark_session():
    snowpark_connect.start_session(tcp_port=15002)
    spark = SparkSession.builder.remote("sc://localhost:15002").getOrCreate()
    df = spark.createDataFrame(
        [
            Row(a=1, b=2.0),
        ]
    )
    df.show()


def test_tcp_port_with_remote_spark_session_with_param():
    snowpark_connect.start_session(tcp_port=15002)
    spark = SparkSession.builder.remote(
        "sc://localhost:15002/;user_id=me_the_user"
    ).getOrCreate()
    df = spark.createDataFrame(
        [
            Row(a=1, b=2.0),
        ]
    )
    df.show()


def test_uds_with_remote_spark_session():
    snowpark_connect.start_session(unix_domain_socket="/tmp/sas-grpc.sock")
    spark = (
        SparkConnectSession.builder.appName("SAS")
        .channelBuilder(UnixDomainSocketChannelBuilder())
        .getOrCreate()
    )
    df = spark.createDataFrame(
        [
            Row(a=1, b=2.0),
        ]
    )
    df.show()


def test_uds_with_remote_spark_session_with_param():
    snowpark_connect.start_session(
        unix_domain_socket="/tmp/sas-grpc.sock;user_id=me_the_user"
    )
    spark = (
        SparkConnectSession.builder.appName("SAS")
        .channelBuilder(UnixDomainSocketChannelBuilder())
        .getOrCreate()
    )
    df = spark.createDataFrame(
        [
            Row(a=1, b=2.0),
        ]
    )
    df.show()
