import pytest
from pyspark.sql.tests.connect.test_parity_dataframe import DataFrameParityTests

from tests.spark_tests.base_test import SasBaseTest
from tests.spark_tests.connect.utils import setup_class_for_reused_connect_test_case


class SASDataFrameParityTests(DataFrameParityTests, SasBaseTest):
    @classmethod
    def setUpClass(cls):
        setup_class_for_reused_connect_test_case(cls)
        SasBaseTest.setUpClass()

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        SasBaseTest.tearDownClass()

    @pytest.mark.xfail
    def test_cache_dataframe(self):
        super().test_cache_dataframe()

    @pytest.mark.xfail
    def test_cache_table(self):
        super().test_cache_table()

    @pytest.mark.xfail
    def test_create_dataframe_from_pandas_with_day_time_interval(self):
        super().test_create_dataframe_from_pandas_with_day_time_interval()

    def test_drop(self):
        # same as super().test_drop(), but this test fails if this test is run along with other
        # test suites in the spark_tests/connect directory. Added import pyspark.sql.connect.functions.col
        # to use connect col instead of the regular col function.
        from pyspark.sql.connect.functions import col

        df = self.spark.createDataFrame(
            [("A", 50, "Y"), ("B", 60, "Y")], ["name", "age", "active"]
        )
        self.assertEqual(df.drop("active").columns, ["name", "age"])
        self.assertEqual(
            df.drop("active", "nonexistent_column").columns, ["name", "age"]
        )
        self.assertEqual(df.drop("name", "age", "active").columns, [])
        self.assertEqual(df.drop(col("name")).columns, ["age", "active"])
        self.assertEqual(df.drop(col("name"), col("age")).columns, ["active"])
        self.assertEqual(
            df.drop(col("name"), col("age"), col("random")).columns, ["active"]
        )

    def test_drop_column_name_with_dot(self):
        # same as super().test_drop_column_name_with_dot(), but this test fails if this test is run along with other
        # test suites in the spark_tests/connect directory. Added import pyspark.sql.connect.functions.lit
        # to use connect lit instead of the regular lit function.
        from pyspark.sql.connect.functions import lit

        df = (
            self.spark.range(1, 3)
            .withColumn("first.name", lit("Peter"))
            .withColumn("city.name", lit("raleigh"))
            .withColumn("state", lit("nc"))
        )

        self.assertEqual(df.drop("first.name").columns, ["id", "city.name", "state"])
        self.assertEqual(df.drop("city.name").columns, ["id", "first.name", "state"])
        self.assertEqual(df.drop("first.name", "city.name").columns, ["id", "state"])
        self.assertEqual(
            df.drop("first.name", "city.name", "unknown.unknown").columns,
            ["id", "state"],
        )
        self.assertEqual(
            df.drop("unknown.unknown").columns,
            ["id", "first.name", "city.name", "state"],
        )

    @pytest.mark.xfail
    def test_duplicate_field_names(self):
        super().test_duplicate_field_names()

    @pytest.mark.xfail
    def test_duplicated_column_names(self):
        super().test_duplicated_column_names()

    def test_extended_hint_types(self):
        # Disabling this test as hint is no-op in SAS
        pass

    def test_generic_hints(self):
        # Disabling this test as hint is no-op in SAS
        pass

    @pytest.mark.skip("Out of Scope for Sas")
    def test_input_files(self):
        super().test_input_files()

    def test_print_schema(self):
        super().test_print_schema()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_repr_behaviors(self):
        super().test_repr_behaviors()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_sample_with_random_seed(self):
        super().test_sample_with_random_seed()

    @pytest.mark.xfail
    def test_to(self):
        super().test_to()

    @pytest.mark.xfail
    def test_to_pandas(self):
        super().test_to_pandas()

    @pytest.mark.xfail
    def test_to_pandas_on_cross_join(self):
        super().test_to_pandas_on_cross_join()


# Remove these from the namespace so pytest doesn't detect them and try to run them.
del DataFrameParityTests
