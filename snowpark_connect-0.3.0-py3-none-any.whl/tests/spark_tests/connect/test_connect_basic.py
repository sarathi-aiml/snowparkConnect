import os
import shutil
import sys
import tempfile
from contextlib import contextmanager

import pytest
from pyspark.errors.exceptions.connect import SparkConnectGrpcException
from pyspark.sql import functions as SF
from pyspark.sql.connect import functions as CF
from pyspark.sql.tests.connect.test_connect_basic import SparkConnectBasicTests

from tests.spark_tests.base_test import SasBaseTest
from tests.spark_tests.connect.utils import setup_class_for_sql_test_case


class SASSparkConnectBasicTests(SparkConnectBasicTests, SasBaseTest):
    @classmethod
    def setUpClass(cls):
        setup_class_for_sql_test_case(cls)
        SasBaseTest.setUpClass()

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        SasBaseTest.tearDownClass()

    @pytest.mark.xfail
    def test_collect(self):
        super().test_collect()

    @pytest.mark.xfail  # SNOW-1951759
    def test_collect_timestamp(self):
        super().test_collect_timestamp()

    @pytest.mark.xfail
    def test_collect_nested_type(self):
        super().test_collect_nested_type()

    def test_column_regexp(self):
        super().test_column_regexp()

    def test_create_global_temp_view(self):
        with self.tempView(True, "view_1"):
            self.connect.sql("SELECT 1 AS X LIMIT 0").createGlobalTempView("view_1")
            self.connect.sql("SELECT 2 AS X LIMIT 1").createOrReplaceGlobalTempView(
                "view_1"
            )
            self.assertTrue(self.connect.catalog.tableExists("global_temp.view_1"))

            # Test when creating a view which is already exists but
            self.assertTrue(self.connect.catalog.tableExists("global_temp.view_1"))
            with self.assertRaisesRegex(
                Exception, "Object 'GLOBAL_TEMP.VIEW_1' already exists"
            ):
                self.connect.sql("SELECT 1 AS X LIMIT 0").createGlobalTempView("view_1")

    def test_create_session_local_temp_view(self):
        with self.tempView(False, "view_local_temp"):
            self.connect.sql("SELECT 1 AS X").createTempView("view_local_temp")
            self.assertEqual(
                self.connect.sql("SELECT * FROM view_local_temp").count(), 1
            )
            self.connect.sql("SELECT 1 AS X LIMIT 0").createOrReplaceTempView(
                "view_local_temp"
            )
            self.assertEqual(
                self.connect.sql("SELECT * FROM view_local_temp").count(), 0
            )

            with self.assertRaisesRegex(
                Exception, "Object 'VIEW_LOCAL_TEMP' already exists"
            ):
                self.connect.sql("SELECT 1 AS X LIMIT 0").createTempView(
                    "view_local_temp"
                )

    @pytest.mark.skip("Out of Scope for Sas")
    def test_csv(self):
        super().test_csv()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_deduplicate_within_watermark_in_batch(self):
        super().test_deduplicate_within_watermark_in_batch()

    def test_describe(self):
        self.assert_eq(
            self.connect.read.table(self.tbl_name).describe("id").toPandas(),
            self.spark.read.table(self.tbl_name).describe("id").toPandas(),
        )
        # Commented out the following test because it validates the avg, stddev for string columns.
        # Snowpark returns Null for string columns, where as spark calculates stddev or mean for string values.
        # self.assert_eq(
        #     self.connect.read.table(self.tbl_name).describe("id", "name").toPandas(),
        #     self.spark.read.table(self.tbl_name).describe("id", "name").toPandas(),
        # )

    def test_empty_dataset(self):
        # same as super.test_empty_dataset() except that this uses assert_eq instead of equals on Pandas object.
        self.assert_eq(
            self.connect.sql("SELECT 1 AS X LIMIT 0").toPandas(),
            self.spark.sql("SELECT 1 AS X LIMIT 0").toPandas(),
        )

        pdf = self.connect.sql("SELECT 1 AS X LIMIT 0").toPandas()
        self.assertEqual(0, len(pdf))  # empty dataset
        self.assertEqual(1, len(pdf.columns))  # one column
        self.assertEqual("X", pdf.columns[0])

    def test_explain_string(self):
        # explain_string for Sas differs from native spark as it uses Snowflake engine.
        # It prints the list of queries that will be executed to evaluate the given DataFrame.
        plan_str = self.connect.sql("SELECT 1")._explain_string(extended=True)
        self.assertTrue("Query List:" in plan_str)
        self.assertTrue("SELECT 1" in plan_str)

    def test_hint(self):
        with self.assertRaises(AssertionError) as context:
            super().test_hint()

        # hint is an no-op in sas, hence we don't see any errors for invalid hint values
        self.assertIn(
            "analysisexception not raised".lower(),
            str(context.exception).lower(),
        )

    @pytest.mark.skip("Out of Scope for Sas")
    def test_input_files(self):
        super().test_input_files()

    def test_invalid_column(self):
        with self.assertRaises(SparkConnectGrpcException) as context:
            super().test_invalid_column()

        self.assertIn(
            "(AssertionError) resolving an attribute of a unresolved dataframe".lower(),
            str(context.exception).lower(),
        )

    @pytest.mark.skip("Out of Scope for Sas")
    def test_is_local(self):
        super().test_is_local()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_is_streaming(self):
        super().test_is_streaming()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_join_hint(self):
        super().test_join_hint()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_json(self):
        super().test_json()

    def test_large_client_data(self):
        super().test_large_client_data()

    def test_multi_paths(self):
        with tempfile.TemporaryDirectory() as d:
            csv_files = []
            for i in range(0, 3):
                csv_file = f"{d}/test-{i}.csv"
                shutil.copyfile(
                    os.path.join(
                        os.path.dirname(os.path.abspath(__file__)),
                        "./resources/test.csv",
                    ),
                    csv_file,
                )
                csv_files.append(csv_file)

            self.assertEqual(
                self.connect.read.csv(csv_files).collect(),
                self.spark.read.csv(csv_files).collect(),
            )
        # Text files are not supported in SAS yet. Testing CSV instead

    def test_namedargs_with_global_limit(self):
        super().test_namedargs_with_global_limit()

    @pytest.mark.xfail
    def test_nested_type_create_from_rows(self):
        super().test_nested_type_create_from_rows()

    @pytest.mark.xfail
    def test_numeric_aggregation(self):
        super().test_numeric_aggregation()

    def test_observe(self):
        # SPARK-41527: test DataFrame.observe()
        observation_name = "my_metric"

        self.assert_eq(
            self.connect.read.table(self.tbl_name)
            .filter("id > 3")
            .observe(observation_name, CF.min("id"), CF.max("id"), CF.sum("id"))
            .toPandas(),
            self.spark.read.table(self.tbl_name)
            .filter("id > 3")
            .observe(observation_name, SF.min("id"), SF.max("id"), SF.sum("id"))
            .toPandas(),
        )

        from pyspark.sql.observation import Observation

        observation = Observation(observation_name)

        cdf = (
            self.connect.read.table(self.tbl_name)
            .filter("id > 3")
            .observe(observation, CF.min("id"), CF.max("id"), CF.sum("id"))
            .toPandas()
        )
        df = (
            self.spark.read.table(self.tbl_name)
            .filter("id > 3")
            .observe(observation, SF.min("id"), SF.max("id"), SF.sum("id"))
            .toPandas()
        )

        self.assert_eq(cdf, df)
        # Metrics is not supported in Snowflake

    @pytest.mark.skip("Out of Scope for Sas")
    def test_orc(self):
        super().test_orc()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_parquet(self):
        super().test_parquet()

    def test_print_schema(self):
        # SNOW-1877072: Snowpark is not able to distinguish between long and int
        tree_str = self.connect.sql("SELECT 1 AS X, 2 AS Y")._tree_string()
        # root
        #  |-- X: long (nullable = false)
        #  |-- Y: long (nullable = false)
        expected = 'root\n |-- "X": long (nullable = false)\n |-- "Y": long (nullable = false)\n'
        self.assertEqual(tree_str, expected)

    @pytest.mark.xfail
    def test_random_split(self):
        super().test_random_split()

    def test_repartition_by_expression(self):
        self.assert_eq(
            self.connect.read.table(self.tbl_name).repartition(10, "id").toPandas(),
            self.spark.read.table(self.tbl_name).repartition(10, "id").toPandas(),
        )

        self.assert_eq(
            self.connect.read.table(self.tbl_name).repartition("id").toPandas(),
            self.spark.read.table(self.tbl_name).repartition("id").toPandas(),
        )
        # repartition is a noop in snowflake so we won't throw error on unsupported parameter values

    def test_repartition_by_range(self):
        cdf = self.connect.read.table(self.tbl_name)
        sdf = self.spark.read.table(self.tbl_name)

        self.assert_eq(
            cdf.repartitionByRange(10, "id").toPandas(),
            sdf.repartitionByRange(10, "id").toPandas(),
        )

        self.assert_eq(
            cdf.repartitionByRange("id").toPandas(),
            sdf.repartitionByRange("id").toPandas(),
        )

        self.assert_eq(
            cdf.repartitionByRange(cdf.id.desc()).toPandas(),
            sdf.repartitionByRange(sdf.id.desc()).toPandas(),
        )
        # repartition is a noop in snowflake so we won't throw error on unsupported parameter values

    @pytest.mark.xfail  # SNOW-1952214
    def test_replace(self):
        with self.assertRaises(SparkConnectGrpcException) as context:
            super().test_replace()

        self.assertIsInstance(context.exception, SparkConnectGrpcException)
        self.assertIn(
            "Column name X does not exist".lower(), str(context.exception).lower()
        )

    def test_simple_explain_string(self):
        super().test_simple_explain_string()

    @pytest.mark.xfail
    def test_schema(self):
        super().test_schema()

    @pytest.mark.xfail
    def test_select_star(self):
        super().test_select_star()

    @pytest.mark.xfail  # SNOW-1952124
    def test_fill_na(self):
        super().test_fill_na()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_simple_datasource_read(self):
        super().test_simple_datasource_read()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_simple_read_without_schema(self):
        super().test_simple_read_without_schema()

    @pytest.mark.xfail
    def test_simple_udt(self):
        super().test_simple_udt()

    @pytest.mark.xfail
    def test_simple_udt_from_read(self):
        super().test_simple_udt_from_read()

    @pytest.mark.xfail
    def test_sql_with_command(self):
        super().test_sql_with_command()

    @pytest.mark.xfail(
        sys.platform in ["darwin"],
        reason="Fails on macOS and local environments",
    )
    def test_stat_cov(self):
        super().test_stat_cov()

    @pytest.mark.xfail
    def test_stat_freq_items(self):
        super().test_stat_freq_items()

    @pytest.mark.skip
    def test_stat_sample_by(self):
        super().test_stat_sample_by()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_streaming_local_relation(self):
        super().test_streaming_local_relation()

    def test_subquery_alias(self):
        plan_text = (
            self.connect.read.table(self.tbl_name)
            .alias("special_alias")
            ._explain_string(extended=True)
        )
        self.assertTrue("Query List:" in plan_text)

    def test_tail(self):
        df = self.connect.read.table(self.tbl_name).orderBy("id")
        df2 = self.spark.read.table(self.tbl_name).orderBy("id")
        self.assertEqual(df.tail(10), df2.tail(10))

    @pytest.mark.skip("Out of Scope for Sas")
    def test_text(self):
        super().test_text()

    @pytest.mark.xfail
    def test_to(self):
        super().test_to()

    def test_with_local_list(self):
        with self.assertRaises(SparkConnectGrpcException) as context:
            super().test_with_local_list()

        self.assertIn(
            "'col1magic_type,col2int,col3int,col4int' is not a supported type".lower(),
            str(context.exception).lower(),
        )

    @pytest.mark.xfail
    def test_with_local_ndarray(self):
        super().test_with_local_ndarray()

    @pytest.mark.xfail
    def test_with_none_and_nan(self):
        super().test_with_none_and_nan()

    @pytest.mark.xfail  # SNOW-1936603
    def test_is_empty(self):
        super().test_is_empty()

    @pytest.mark.skip("Out of Scope for Sas")
    def test_write_operations(self):
        super().test_write_operations()

    @contextmanager
    def tempView(self, is_global: bool, *views: str):
        assert hasattr(
            self, "connect"
        ), "it should have 'connect' attribute, having a spark session."
        try:
            yield
        finally:
            for v in views:
                (
                    self.connect.catalog.dropGlobalTempView(v)
                    if is_global
                    else self.connect.catalog.dropTempView(v)
                )


# Remove these from the namespace so pytest doesn't detect them and try to run them.
del SparkConnectBasicTests
