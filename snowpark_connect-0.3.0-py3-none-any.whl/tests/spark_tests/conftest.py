import os

import pytest

import snowpark_connect

# Make pyspark imports work in the original namespace.
os.environ["SPARK_CONNECT_MODE_ENABLED"] = "1"


@pytest.fixture(scope="session", autouse=True)
def init_sas():
    snowpark_connect.start_session()
