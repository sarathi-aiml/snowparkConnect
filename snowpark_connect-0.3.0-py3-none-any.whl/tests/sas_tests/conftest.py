import pytest
from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession

import snowpark_connect

# Use any time zone other than America/Los_Angeles and UTC, to minimize the
# odds of tests passing by luck.
TEST_TIMEZONE = "America/New_York"


@pytest.fixture(scope="session")
def spark_conf():
    conf = SparkConf()
    conf.set("spark.sql.session.timeZone", TEST_TIMEZONE)
    conf.set("spark.sql.catalogImplementation", "hive")
    conf.set("spark.driver.bindAddress", "127.0.0.1")

    return conf


@pytest.fixture(scope="session")
def sas_spark():
    snowpark_connect.start_session()
    spark = snowpark_connect.get_session()
    spark.conf.set("spark.sql.session.timeZone", TEST_TIMEZONE)

    yield spark
    spark.stop()


@pytest.fixture(scope="session")
def native_spark(spark_conf):
    # start local pyspark
    sc = SparkContext("local[2]", "Native_PySpark", conf=spark_conf)
    yield SparkSession(sc)
    sc.stop()
