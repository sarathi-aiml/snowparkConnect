import datetime
import decimal
import math

import pytest
from pandas.testing import assert_frame_equal
from pyspark.errors import PySparkTypeError, PySparkValueError
from pyspark.sql.types import (
    ArrayType,
    BooleanType,
    DateType,
    DecimalType,
    DoubleType,
    FloatType,
    IntegerType,
    LongType,
    MapType,
    Row,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

INT_MAX = 2**31 - 1
INT_MIN = -(2**31)
LONG_MAX = 2**63 - 1
LONG_MIN = -(2**63)


class TestSparkSqlTypes:
    def _assert_df_equal(self, sas_df, spark_df, column_name=None, test_to_pandas=True):
        assert sas_df.schema == spark_df.schema

        if test_to_pandas:
            sas_pd = sas_df.toPandas()
            spark_pd = spark_df.toPandas()
            assert_frame_equal(sas_pd, spark_pd)

        sas_df_rows = sas_df.collect()
        spark_df_rows = spark_df.collect()
        assert sas_df_rows == spark_df_rows

        return [row[column_name] for row in sas_df_rows] if column_name else None

    def test_date_type(self, sas_spark, native_spark):
        simple_dates = [datetime.date(2000, 1, 1), None]
        date_schema = StructType([StructField("date", DateType(), True)])
        date_data = [[e] for e in simple_dates]
        sas_df = sas_spark.createDataFrame(date_data, date_schema)
        spark_df = native_spark.createDataFrame(date_data, date_schema)

        date_column = self._assert_df_equal(sas_df, spark_df, "date")
        assert date_column == simple_dates

    def test_decimal_type(self, sas_spark, native_spark):
        simple_decimals = [
            decimal.Decimal("12345678"),
            decimal.Decimal("0.1234567"),
            None,
        ]
        decimal_schema = StructType([StructField("decimal", DecimalType(16, 8), True)])
        decimal_data = [[e] for e in simple_decimals]
        sas_df = sas_spark.createDataFrame(decimal_data, decimal_schema)
        spark_df = native_spark.createDataFrame(decimal_data, decimal_schema)
        decimal_column = self._assert_df_equal(sas_df, spark_df, "decimal")
        assert decimal_column == simple_decimals

    @pytest.mark.xfail
    def test_integer_type_schema(self, sas_spark, native_spark):
        data = [[1]]
        schema = StructType([StructField("integer", IntegerType(), True)])
        sas_df = sas_spark.createDataFrame(data, schema)
        spark_df = native_spark.createDataFrame(data, schema)
        self._assert_df_equal(sas_df, spark_df)

    def test_integer_type(self, sas_spark, native_spark):
        simple_integers = [1, 0, -1, INT_MAX, INT_MIN, None]
        integer_schema = StructType([StructField("integer", IntegerType(), True)])
        integer_data = [[e] for e in simple_integers]
        sas_df = sas_spark.createDataFrame(integer_data, integer_schema)
        spark_df = native_spark.createDataFrame(integer_data, integer_schema)
        for expected, sas_row, spark_row in zip(
            simple_integers, sas_df.collect(), spark_df.collect()
        ):
            assert sas_row["integer"] == spark_row["integer"] == expected

    def test_long_type(self, sas_spark, native_spark):
        simple_longs = [
            1,
            0,
            -1,
            INT_MAX,
            INT_MIN,
            INT_MAX + 1,
            INT_MIN - 1,
            LONG_MAX,
            LONG_MIN,
            None,
        ]
        long_schema = StructType([StructField("long", LongType(), True)])
        long_data = [[e] for e in simple_longs]
        sas_df = sas_spark.createDataFrame(long_data, long_schema)
        spark_df = native_spark.createDataFrame(long_data, long_schema)
        long_column = self._assert_df_equal(sas_df, spark_df, "long")
        assert long_column == simple_longs

    @pytest.mark.xfail
    def test_float_type_schema(self, sas_spark, native_spark):
        data = [[3.14]]
        schema = StructType([StructField("float", FloatType(), True)])
        sas_df = sas_spark.createDataFrame(data, schema)
        spark_df = native_spark.createDataFrame(data, schema)
        self._assert_df_equal(sas_df, spark_df)

    def test_float_type(self, sas_spark, native_spark):
        simple_floats = [3.1415, -0.888, float(1), None]
        float_schema = StructType([StructField("float", FloatType(), True)])
        float_data = [[e] for e in simple_floats]
        sas_df = sas_spark.createDataFrame(float_data, float_schema)
        spark_df = native_spark.createDataFrame(float_data, float_schema)
        sas_df_rows = sas_df.collect()
        spark_df_rows = spark_df.collect()

        for expected, sas_row, spark_row in zip(
            simple_floats, sas_df_rows, spark_df_rows
        ):
            if expected is None:
                assert sas_row["float"] == spark_row["float"] == expected
            else:
                assert math.isclose(sas_row["float"], spark_row["float"], abs_tol=0.01)
                assert math.isclose(sas_row["float"], expected, abs_tol=0.01)

    def test_double_type(self, sas_spark, native_spark):
        simple_doubles = [3.1415, -0.888, float(1), 0.0, None]
        double_schema = StructType([StructField("double", DoubleType(), True)])
        double_data = [[e] for e in simple_doubles]
        sas_df = sas_spark.createDataFrame(double_data, double_schema)
        spark_df = native_spark.createDataFrame(double_data, double_schema)
        double_column = self._assert_df_equal(sas_df, spark_df, "double")
        assert double_column == simple_doubles

    def test_boolean_type(self, sas_spark, native_spark):
        simple_booleans = [True, False, None]
        boolean_schema = StructType([StructField("boolean", BooleanType(), True)])
        boolean_data = [[e] for e in simple_booleans]
        sas_df = sas_spark.createDataFrame(boolean_data, boolean_schema)
        spark_df = native_spark.createDataFrame(boolean_data, boolean_schema)
        boolean_column = self._assert_df_equal(sas_df, spark_df, "boolean")
        assert boolean_column == simple_booleans

    def test_string_type(self, sas_spark, native_spark):
        simple_strings = ["", "12345", "fadsf&!@#$%^&*()-=_+[]{}`", None]
        string_schema = StructType([StructField("string", StringType(), True)])
        string_data = [[e] for e in simple_strings]
        sas_df = sas_spark.createDataFrame(string_data, string_schema)
        spark_df = native_spark.createDataFrame(string_data, string_schema)
        string_column = self._assert_df_equal(sas_df, spark_df, "string")
        assert string_column == simple_strings

    def test_timestamp_type(self, sas_spark, native_spark):
        # Seems like that timestamp result type is controlled by the precision of timestamp. If timestamp has nano sec
        # precision, then arrow uses pandas.Timestamp. Otherwise, e.g. 's', 'ms', 'us', it's python datetime.datetime.

        # timezone can be another problem that needs to be solved.
        simple_timestamps = [
            datetime.datetime(1970, 1, 1, 0, 0, 0),
            datetime.datetime(2024, 12, 17, 12, 0, 0),
            datetime.datetime(2008, 2, 29, 0, 0, 0),
        ]
        timestamp_schema = StructType([StructField("timestamp", TimestampType(), True)])
        timestamp_data = [[e] for e in simple_timestamps]
        sas_df = sas_spark.createDataFrame(timestamp_data, timestamp_schema)
        spark_df = native_spark.createDataFrame(timestamp_data, timestamp_schema)
        timestamp_column = self._assert_df_equal(sas_df, spark_df, "timestamp")
        assert timestamp_column == simple_timestamps

        timestamp_data = [["1970-1-1 00:00:00"]]
        with pytest.raises(AssertionError):
            sas_spark.createDataFrame(timestamp_data, timestamp_schema)
        with pytest.raises(PySparkTypeError):
            native_spark.createDataFrame(timestamp_data, timestamp_schema)

    def test_array_type(self, sas_spark, native_spark):
        array_field_name = "my_array_field"
        simple_array = [1, 2, 3]
        simple_array_schema = StructType(
            [StructField(array_field_name, ArrayType(LongType()), True)]
        )
        nested_array = [[5, 6, 7], [8, 9, 10]]
        nested_array_schema = StructType(
            [StructField(array_field_name, ArrayType(ArrayType(LongType())), True)]
        )

        for array_data, array_schema in zip(
            [simple_array, nested_array], [simple_array_schema, nested_array_schema]
        ):
            sas_df = sas_spark.createDataFrame([[array_data]], array_schema)
            spark_df = native_spark.createDataFrame([[array_data]], array_schema)
            # TODO: snowpark's arrayType's valueContainsNull is false, which doesn't align with spark.
            # assert sas_df.schema == spark_df.schema == array_schema
            sas_rows = sas_df.collect()
            spark_rows = spark_df.collect()
            assert sas_rows == spark_rows
            assert (
                sas_rows[0][array_field_name]
                == spark_rows[0][array_field_name]
                == array_data
            )

    def test_map_type(self, sas_spark, native_spark):
        map_field_name = "my_map_field"
        simple_map = {"Car": 66, "Bike": 88}
        simple_map_schema = StructType(
            [StructField(map_field_name, MapType(StringType(), LongType()), True)]
        )
        nested_map = {999: {66: "Car", 88: "Bike"}, 777: {666: "Car", 888: "Bike"}}
        nested_map_schema = StructType(
            [
                StructField(
                    map_field_name,
                    MapType(LongType(), MapType(LongType(), StringType())),
                    True,
                )
            ]
        )

        for map_data, map_schema in zip(
            [simple_map, nested_map], [simple_map_schema, nested_map_schema]
        ):
            sas_df = sas_spark.createDataFrame([[map_data]], map_schema)
            spark_df = native_spark.createDataFrame([[map_data]], map_schema)
            # TODO: snowpark inner Map's valueContainsNull is false, which doesn't align with spark.
            # assert sas_df.schema == spark_df.schema == map_schema
            sas_rows = sas_df.collect()
            spark_rows = spark_df.collect()
            assert sas_rows == spark_rows
            assert (
                sas_rows[0][map_field_name] == spark_rows[0][map_field_name] == map_data
            )

            sas_pd_df = sas_df.toPandas()
            spark_pd_df = spark_df.toPandas()
            assert_frame_equal(sas_pd_df, spark_pd_df)

    def test_struct_type(self, sas_spark, native_spark):
        struct_field_name = "Address_struct_type"
        simple_struct = [
            ("123 Elm St", "Somewhere", 12345),
        ]
        simple_struct_schema = StructType(
            [
                StructField(
                    struct_field_name,
                    StructType(
                        [
                            StructField("Street", StringType(), True),
                            StructField("City", StringType(), True),
                            StructField("ZipCode", LongType(), True),
                        ]
                    ),
                    True,
                )
            ]
        )
        data = [[e] for e in simple_struct]
        sas_df = sas_spark.createDataFrame(data, simple_struct_schema)
        spark_df = native_spark.createDataFrame(data, simple_struct_schema)
        # spark connect struct type df.to_pandas generates different result than spark df.to_pandas.
        # Spark connect struct type tests are currently only testing .collect(). We only run to_pandas() to make sure
        # it doesn't break.
        sas_df.toPandas()
        struct_column = self._assert_df_equal(
            sas_df, spark_df, struct_field_name, test_to_pandas=False
        )
        assert struct_column == simple_struct

    @pytest.mark.xfail
    def test_struct_field_nullable(self, sas_spark, native_spark):
        data = [[True, 123456789], [False, -987654321], [None, None]]
        schema = StructType(
            [
                StructField("boolean field", BooleanType(), True),
                StructField("Long FIELD", LongType(), False),
            ]
        )
        with pytest.raises(PySparkValueError) as sas_ex:
            # problem: SAS (snowpark) doesn't throw exception here!!
            sas_spark.createDataFrame(data, schema)
        with pytest.raises(PySparkValueError) as spark_ex:
            native_spark.createDataFrame(data, schema)
        assert sas_ex == spark_ex

    def test_struct_field(self, sas_spark, native_spark):
        data = [[True, 123456789], [False, -987654321], [None, 0]]
        schema = StructType(
            [
                StructField("boolean field", BooleanType()),
                StructField("Long FIELD", LongType()),
            ]
        )
        sas_df = sas_spark.createDataFrame(data, schema)
        spark_df = native_spark.createDataFrame(data, schema)
        self._assert_df_equal(sas_df, spark_df)

    def test_row_type(self, sas_spark, native_spark):
        simple_rows = [
            Row(name="Alice", age=25),
            Row(name="Bob", age=30),
            Row(name="Cathy", age=27),
        ]
        nested_rows = [
            Row(name="Alice", info=Row(age=25, city="San Francisco")),
            Row(name="Bob", info=Row(age=30, city="New York")),
        ]

        def _test_body(rows: list[Row]):
            spark_df_rows = native_spark.createDataFrame(rows).collect()
            sas_df_rows = sas_spark.createDataFrame(rows).collect()

            for sas_row, spark_row in zip(sas_df_rows, spark_df_rows):
                assert sas_row == spark_row

        _test_body(simple_rows)
        _test_body(nested_rows)

    def test_atom_type(self, sas_spark, native_spark):
        for data in [[(1), (2), (3)], [1, 2, 3]]:
            for schema in ["long", "int", "short"]:
                sas_rows = sas_spark.createDataFrame(data, schema=schema).collect()
                spark_rows = native_spark.createDataFrame(data, schema=schema).collect()
                # we can't compare schema, since snowpark returns LongType for both int and short.
                assert sas_rows == spark_rows
