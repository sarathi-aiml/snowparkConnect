import datetime
import uuid

import pytest
from pandas import Timestamp
from pyspark import Row

from tools.tox_util import _read_jdbc_connection_values

SF_JDBC_URL = "jdbc:snowflake://sfctest0.snowflakecomputing.com/?db=my_test_db&schema=public&warehouse=testwh_python&role=public"
SQLSERVER_JDBC_URL = "jdbc:sqlserver://igarish.database.windows.net:1433;database=IHG_DB;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
SF_JDBC_DRIVER = "net.snowflake.client.jdbc.SnowflakeDriver"
JDBC_TABLE_NAME = "MY_JDBC_TABLE"
JDBC_DATE_TABLE_NAME = "MY_JDBC_DATE_TABLE"


class TestSparkJdbcRead:
    def setup_jdbc_url(self):
        try:
            (
                self.sf_host,
                self.sf_user_name,
                self.sf_password,
                self.sf_database,
                self.sf_schema,
                self.sf_warehouse,
                self.sf_role,
            ) = _read_jdbc_connection_values()

            if self.sf_role is None:
                self.sf_role = "TESTROLE_SAS"
            self.sf_jdbc_url = f"jdbc:snowflake://{self.sf_host}/?db={self.sf_database}&schema={self.sf_schema}&warehouse={self.sf_warehouse}&role={self.sf_role}"
        except Exception:
            raise Exception("Not able to read config file and build the JDBC URL")

    def create_table_and_data(self, sas_spark):
        sas_spark.sql(
            f"CREATE OR REPLACE TABLE public.{JDBC_TABLE_NAME} (C1 int, C2 varchar(256))"
        ).collect()
        sas_spark.sql(
            f"INSERT INTO public.{JDBC_TABLE_NAME} values(1, 'SAS')"
        ).collect()
        sas_spark.sql(
            f"INSERT INTO public.{JDBC_TABLE_NAME} values(2, 'JDBC')"
        ).collect()
        sas_spark.sql(
            f"INSERT INTO public.{JDBC_TABLE_NAME} values(3, 'How is your day?')"
        ).collect()

    def create_date_types_table_and_data(self, sas_spark):
        sas_spark.sql(
            f"CREATE OR REPLACE TABLE public.{JDBC_DATE_TABLE_NAME} (C1 int, C2 DATE, C3 DATETIME)"
        ).collect()
        sas_spark.sql(
            f"INSERT INTO public.{JDBC_DATE_TABLE_NAME} values(1, '2025-01-01', '2025-01-01 01:01:01')"
        ).collect()
        sas_spark.sql(
            f"INSERT INTO public.{JDBC_DATE_TABLE_NAME} values(2, '2025-02-01', '2025-02-01 02:02:02')"
        ).collect()
        sas_spark.sql(
            f"INSERT INTO public.{JDBC_DATE_TABLE_NAME} values(3, '2025-03-01', '2025-03-01 03:03:03')"
        ).collect()

    def test_jdbc_read_from_sf(self, sas_spark):
        self.create_table_and_data(sas_spark)
        self.setup_jdbc_url()
        sas_jdbc_df = sas_spark.read.jdbc(
            self.sf_jdbc_url,
            JDBC_TABLE_NAME,
            properties={
                "user": self.sf_user_name,
                "password": self.sf_password,
                "driver": SF_JDBC_DRIVER,
            },
        ).collect()

        assert sas_jdbc_df == [
            Row(c1=1, c2="SAS"),
            Row(c1=2, c2="JDBC"),
            Row(c1=3, c2="How is your day?"),
        ]

    @pytest.mark.xfail  # There is no DATETIME is Spark
    def test_jdbc_read_date_types_from_sf(self, sas_spark):
        self.create_date_types_table_and_data(sas_spark)
        self.setup_jdbc_url()
        sas_jdbc_df = sas_spark.read.jdbc(
            self.sf_jdbc_url,
            JDBC_DATE_TABLE_NAME,
            properties={
                "user": self.sf_user_name,
                "password": self.sf_password,
                "driver": SF_JDBC_DRIVER,
            },
        ).collect()

        assert sas_jdbc_df == [
            Row(
                c1=1, c2=datetime.date(2025, 1, 1), c3=Timestamp("2025-01-01 06:01:01")
            ),
            Row(
                c1=2, c2=datetime.date(2025, 2, 1), c3=Timestamp("2025-02-01 07:02:02")
            ),
            Row(
                c1=3, c2=datetime.date(2025, 3, 1), c3=Timestamp("2025-03-01 08:03:03")
            ),
        ]

    @pytest.mark.skip
    def test_jdbc_large_data_read_from_sf(self, sas_spark):
        sas_jdbc_df = sas_spark.read.jdbc(
            SF_JDBC_URL,
            "public.my_large_table",
            "C1",
            "1",
            "100000",
            "10",
            properties={
                "user": "igarishrestapi",
                "password": "****",
                "driver": "net.snowflake.client.jdbc.SnowflakeDriver",
            },
        ).collect()
        row_count = len(sas_jdbc_df)
        assert row_count == 1000000

    def test_jdbc_read_using_query_from_sf(self, sas_spark):
        self.create_table_and_data(sas_spark)
        self.setup_jdbc_url()
        sas_jdbc_df = sas_spark.read.jdbc(
            self.sf_jdbc_url,
            "",
            properties={
                "user": self.sf_user_name,
                "password": self.sf_password,
                "driver": SF_JDBC_DRIVER,
                "query": f"SELECT * FROM public.{JDBC_TABLE_NAME} WHERE C1=1",
            },
        ).collect()

        assert sas_jdbc_df == [Row(c1=1, c2="SAS")]

    @pytest.mark.skip
    def test_jdbc_read_from_sqlserver(self, sas_spark):
        sas_jdbc_df = sas_spark.read.jdbc(
            SQLSERVER_JDBC_URL,
            "dbo.my_table",
            properties={
                "user": "sqlsrvr-admin",
                "password": "****",
                "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
            },
        ).collect()
        assert sas_jdbc_df == [Row(c1=1, c2="SQLS"), Row(c1=2, c2="SAS")]

    @pytest.mark.skip
    def test_jdbc_read_date_types_from_sqlserver(self, sas_spark):
        sas_jdbc_df = sas_spark.read.jdbc(
            SQLSERVER_JDBC_URL,
            "dbo.my_date_table",
            properties={
                "user": "sqlsrvr-admin",
                "password": "****",
                "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
            },
        ).collect()
        assert sas_jdbc_df == [
            Row(
                c1=1, c2=datetime.date(2025, 1, 1), c3=Timestamp("2025-01-01 06:01:01")
            ),
            Row(
                c1=2, c2=datetime.date(2025, 2, 1), c3=Timestamp("2025-02-01 07:02:02")
            ),
            Row(
                c1=3, c2=datetime.date(2025, 3, 1), c3=Timestamp("2025-03-01 08:03:03")
            ),
        ]


# Please add  "derby-*.jar" from {spark_home}/jars directory in start_jvm method in server.py,
# before running these tests
class TestSparkJdbc:
    @pytest.mark.skip
    def test_spark_jdbc(self, sas_spark):
        db = f"memory:{uuid.uuid4()}"
        url = f"jdbc:derby:{db}"
        dbtable = "test_jdbc_table"

        try:
            df = sas_spark.range(10)
            df.write.jdbc(url=f"{url};create=true", table=dbtable)

            readback = sas_spark.read.jdbc(url=url, table=dbtable)
            assert sorted(df.collect()) == sorted(readback.collect())

            additional_arguments = dict(
                column="id", lowerBound=3, upperBound=8, numPartitions=10
            )
            readback = sas_spark.read.jdbc(
                url=url, table=dbtable, **additional_arguments
            )
            assert sorted(df.collect()) == sorted(readback.collect())

            additional_arguments = dict(predicates=["id < 5"])
            readback = sas_spark.read.jdbc(
                url=url, table=dbtable, **additional_arguments
            )
            assert sorted(df.filter("id < 5").collect()) == sorted(readback.collect())
        finally:
            with pytest.raises(Exception, match=f"Database '{db}' dropped."):
                sas_spark.read.jdbc(url=f"{url};drop=true", table=dbtable).collect()

    @pytest.mark.skip
    def test_spark_jdbc_format(self, sas_spark):
        db = f"memory:{uuid.uuid4()}"
        url = f"jdbc:derby:{db}"
        dbtable = "test_jdbc_table"

        try:
            df = sas_spark.range(10)
            df.write.format("jdbc").options(
                url=f"{url};create=true", dbtable=dbtable
            ).save()
            readback = (
                sas_spark.read.format("jdbc").options(url=url, dbtable=dbtable).load()
            )
            assert sorted(df.collect()) == sorted(readback.collect())
        finally:
            # Clean up.
            with pytest.raises(Exception, match=f"Database '{db}' dropped."):
                sas_spark.read.format("jdbc").options(
                    url=f"{url};drop=true", dbtable=dbtable
                ).load().collect()
