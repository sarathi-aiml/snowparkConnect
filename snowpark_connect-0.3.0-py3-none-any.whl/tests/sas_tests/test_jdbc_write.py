import pytest
from pyspark import Row

SF_JDBC_URL = "jdbc:snowflake://sfctest0.snowflakecomputing.com/?db=my_test_db&schema=public&warehouse=testwh_python&role=public"
SQLSERVER_JDBC_URL = "jdbc:sqlserver://igarish.database.windows.net:1433;database=IHG_DB;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"


class TestSparkJdbcWrite:
    @pytest.mark.skip
    def test_jdbc_write_append_to_sf(self, sas_spark):
        sas_jdbc_df = sas_spark.createDataFrame(
            [
                Row(a=1, b=2.0, c="test1"),
                Row(a=2, b=3.0, c="test2"),
                Row(a=4, b=5.0, c="test3"),
            ]
        )

        try:
            sas_jdbc_df.write.jdbc(
                SF_JDBC_URL,
                "public.my_table2",
                mode="append",
                properties={
                    "user": "igarishrestapi",
                    "password": "****",
                    "driver": "net.snowflake.client.jdbc.SnowflakeDriver",
                },
            )
        except Exception as e:
            pytest.fail(f"Unexpected error {e}")

    @pytest.mark.skip
    def test_jdbc_write_overwrite_to_sf(self, sas_spark):
        sas_jdbc_df = sas_spark.createDataFrame(
            [
                Row(a=1, b=2.0, c="test1"),
                Row(a=2, b=3.0, c="test2"),
                Row(a=4, b=5.0, c="test3"),
            ]
        )

        try:
            sas_jdbc_df.write.jdbc(
                SF_JDBC_URL,
                "public.my_table2",
                mode="overwrite",
                properties={
                    "user": "igarishrestapi",
                    "password": "****",
                    "driver": "net.snowflake.client.jdbc.SnowflakeDriver",
                },
            )
        except Exception as e:
            pytest.fail(f"Unexpected error {e}")

    @pytest.mark.skip
    def test_jdbc_write_default_to_sf(self, sas_spark):
        sas_jdbc_df = sas_spark.createDataFrame(
            [
                Row(a=1, b=2.0, c="test1"),
                Row(a=2, b=3.0, c="test2"),
                Row(a=4, b=5.0, c="test3"),
            ]
        )

        try:
            sas_jdbc_df.write.jdbc(
                SF_JDBC_URL,
                "public.my_table2",
                properties={
                    "user": "igarishrestapi",
                    "password": "****",
                    "driver": "net.snowflake.client.jdbc.SnowflakeDriver",
                },
            )
            pytest.fail(
                "Expected an error as table exists and default write mode is errorifexists"
            )
        except Exception:
            pass

    @pytest.mark.skip
    def test_jdbc_write_ignore_to_sf(self, sas_spark):
        sas_jdbc_df = sas_spark.createDataFrame(
            [
                Row(a=1, b=2.0, c="test1"),
                Row(a=2, b=3.0, c="test2"),
                Row(a=4, b=5.0, c="test3"),
            ]
        )

        try:
            sas_jdbc_df.write.jdbc(
                SF_JDBC_URL,
                "public.my_table2",
                mode="ignore",
                properties={
                    "user": "igarishrestapi",
                    "password": "****",
                    "driver": "net.snowflake.client.jdbc.SnowflakeDriver",
                },
            )
        except Exception as e:
            pytest.fail(f"Unexpected error {e}")

    @pytest.mark.skip
    def test_jdbc_write_overwrite_to_sqlserver(self, sas_spark):
        sas_jdbc_df = sas_spark.createDataFrame(
            [
                Row(a=1, b=2.0, c="test1"),
                Row(a=2, b=3.0, c="test2"),
                Row(a=4, b=5.0, c="test3"),
            ]
        )

        try:
            sas_jdbc_df.write.jdbc(
                SQLSERVER_JDBC_URL,
                "dbo.my_table2",
                mode="overwrite",
                properties={
                    "user": "sqlsrvr-admin",
                    "password": "****",
                    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
                },
            )
        except Exception as e:
            pytest.fail(f"Unexpected error {e}")
