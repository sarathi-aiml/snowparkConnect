import contextlib
import os

from pandas.testing import assert_frame_equal


def assert_df_equal(sas_df, spark_df, column_name=None, test_to_pandas=True):
    assert sas_df.schema == spark_df.schema

    if test_to_pandas:
        sas_pd = sas_df.toPandas()
        spark_pd = spark_df.toPandas()
        assert_frame_equal(sas_pd, spark_pd)

    sas_df_rows = sas_df.collect()
    spark_df_rows = spark_df.collect()
    assert sas_df_rows == spark_df_rows
    return [row[column_name] for row in sas_df_rows] if column_name else None


@contextlib.contextmanager
def set_env(key, value):
    old_value = os.environ.get(key)
    os.environ[key] = value
    try:
        yield  # Allow execution within the context
    finally:
        if old_value is None:  # Restore the previous state
            del os.environ[key]
        else:
            os.environ[key] = old_value
