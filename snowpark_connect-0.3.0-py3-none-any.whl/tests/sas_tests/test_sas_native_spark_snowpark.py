def test_sas(sas_spark):
    from pyspark.sql.connect.functions import expr
    df1 = sas_spark.createDataFrame([(1, "a")], ["id", "value"]).alias("df1")
    df1.show()
    df2 = sas_spark.createDataFrame([(2, "a")], ["id", "value"]).alias("df2")
    joined = df1.join(df2, expr("df1.id = df2.id"))
    joined.show()


def test_native_spark(native_spark):
    from pyspark.sql.functions import expr
    df1 = native_spark.createDataFrame([(1, "a")], ["id", "value"]).alias("df1")
    df2 = native_spark.createDataFrame([(2, "a")], ["id", "value"]).alias("df2")
    joined = df1.join(df2, expr("df1.id = df2.id"))
    joined.show()


def test_sp():
    from snowflake import snowpark
    session = snowpark.Session.builder.getOrCreate()
    df1 = session.createDataFrame([(1, "a")], ["id", "value"]).alias("df1")
    df2 = session.createDataFrame([(2, "a")], ["id", "value"]).alias("df2")
    joined = df1.join(df2, df1["id"] == df2["id"])
    joined.show()
