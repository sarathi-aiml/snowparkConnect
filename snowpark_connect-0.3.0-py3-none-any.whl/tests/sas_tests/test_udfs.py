import math
import random

import pandas as pd
import pytest
from pyspark.sql import Row
from pyspark.sql.connect.functions import udf
from pyspark.sql.pandas.functions import pandas_udf
from pyspark.sql.types import IntegerType, LongType

from tests.sas_tests.utils import set_env


# TODO: investigate running pandas_udf with native spark. Seems like when numpy is involved, we hit this issue.
class TestUDFs:
    def test_simple_arrow_udf(self, sas_spark):
        @udf(useArrow=False)
        def pow(a: int, b: int) -> float:
            return math.pow(a, b)

        @udf(useArrow=True)
        def powArrow(a: int, b: int) -> float:
            return math.pow(a, b)

        df = sas_spark.createDataFrame([[1, 2], [3, 4]], ["a", "b"])
        res1 = df.select(pow(df["a"], df["b"])).collect()
        res2 = df.select(powArrow(df["a"], df["b"])).collect()
        assert res1 == res2

    def test_pandas_udf_series_to_series(self, sas_spark):
        def _test_slen_sas():
            with set_env("SPARK_CONNECT_MODE_ENABLED", "1"):

                @pandas_udf(LongType())
                def slen(s: pd.Series) -> pd.Series:
                    return s.str.len()

                df = sas_spark.createDataFrame(
                    [(1, "Wukong", -1), (2, "Goku Wukong", -1)], ("id", "name", "age")
                )
                return df.select(slen("name"))

        # having trouble running pandas_udf with native spark
        # def _test_slen_spark():
        #     @pandas_udf(LongType())
        #     def slen(s: pd.Series) -> pd.Series:
        #         return s.str.len()
        #
        #     df = native_spark.createDataFrame([(1, "Wukong", -1), (2, "Goku Wukong", -1)], ("id", "name", "age"))
        #     return df.select(slen("name"))

        df = _test_slen_sas()
        sas_rows = df.collect()
        assert [row[0] for row in sas_rows] == [6, 11]

    def test_pandas_udf_dataframe_to_series(self, sas_spark):
        with set_env("SPARK_CONNECT_MODE_ENABLED", "1"):

            @pandas_udf(IntegerType())
            def mul_udf(df: pd.DataFrame) -> pd.Series:
                return df[0] * df[1]

            # TODO: schema can't use structType, otherwise we hit Unknown user-defined function issue.
            df = sas_spark.createDataFrame([[1, 2], [3, 4]], ["a", "b"])
            df = df.select(mul_udf("a", "b"))
            assert [row[0] for row in df.collect()] == [2, 12]

    # TODO: SNOW-1885021 - investigate cause
    @pytest.mark.xfail(reason="sql execution error")
    def test_pandas_udf_series_to_scalar_agg_function(self, sas_spark):
        with set_env("SPARK_CONNECT_MODE_ENABLED", "1"):

            @pandas_udf("double")
            def mean_udf(v: pd.Series) -> float:
                return v.mean()

            df = sas_spark.createDataFrame(
                [(1, 1.0), (1, 2.0), (2, 3.0), (2, 5.0), (2, 10.0)], ("id", "v")
            )
            df.groupby("id").agg(mean_udf(df["v"])).show()

    @pytest.mark.xfail(reason="Sliding window frame unsupported")
    def test_pandas_udf_series_to_scalar_window_function(self, sas_spark):
        with set_env("SPARK_CONNECT_MODE_ENABLED", "1"):
            from pyspark.sql import Window

            @pandas_udf("double")
            def mean_udf(v: pd.Series) -> float:
                return v.mean()

            df = sas_spark.createDataFrame(
                [(1, 1.0), (1, 2.0), (2, 3.0), (2, 5.0), (2, 10.0)], ("id", "v")
            )
            w = Window.partitionBy("id").orderBy("v").rowsBetween(-1, 0)
            df.withColumn("mean_v", mean_udf("v").over(w)).show()

    @pytest.mark.xfail(reason="SNOW-1884806: Unknown user-defined function issue")
    def test_pandas_udf_series_to_dataframe(self, sas_spark):
        with set_env("SPARK_CONNECT_MODE_ENABLED", "1"):

            @pandas_udf("first string, last string")
            def split_expand(s: pd.Series) -> pd.DataFrame:
                return s.str.split(expand=True)

            df = sas_spark.createDataFrame([("John Doe",)], ("name",))
            df.select(split_expand("name")).show()

    @pytest.mark.xfail(reason="invalid type typing.Iterator[pandas.core.series.Series]")
    def test_pandas_udf_series_iterator_to_series_iterator(self, sas_spark):
        with set_env("SPARK_CONNECT_MODE_ENABLED", "1"):
            from typing import Iterator

            @pandas_udf("long")
            def plus_one(iterator: Iterator[pd.Series]) -> Iterator[pd.Series]:
                for s in iterator:
                    yield s + 1

            df = sas_spark.createDataFrame(pd.DataFrame([1, 2, 3], columns=["v"]))
            df.select(plus_one(df.v)).show()

    def test_udf_registration(self, sas_spark):
        data = [
            ("1", "john jones", 10),
            ("2", "tracey smith", 20),
            ("3", "amy sanders", 30),
        ]
        df = sas_spark.createDataFrame(data=data, schema=["id", "Name", "age"])
        df.createOrReplaceTempView("UDF_TEST_TABLE")

        def length(s: str) -> int:
            return len(s)

        def add(a: int, b: int) -> int:
            return a + b

        sas_spark.udf.register("add", add, IntegerType())
        sas_spark.udf.register("length", length, IntegerType())
        expected_result = [
            Row(**{"ADD(id, age)": 11}),
            Row(**{"ADD(id, age)": 22}),
            Row(**{"ADD(id, age)": 33}),
        ]

        result = sas_spark.sql("select add(id, age) from  UDF_TEST_TABLE").collect()

        assert result == expected_result

        result = sas_spark.sql(
            "select Name, length(name) from  UDF_TEST_TABLE"
        ).collect()

        expected_result = [
            Row(Name="john jones", **{"LENGTH(name)": 10}),
            Row(Name="tracey smith", **{"LENGTH(name)": 12}),
            Row(Name="amy sanders", **{"LENGTH(name)": 11}),
        ]

        assert result == expected_result

    def test_udf_registration_missing_type_hints(self, sas_spark):
        data = [(1, "john jones", 10), (2, "tracey smith", 20), (3, "amy sanders", 30)]
        df = sas_spark.createDataFrame(data=data, schema=["id", "Name", "age"])
        df.createOrReplaceTempView("UDF_TEST_TABLE")

        def add_without_type_hint(a: int, b) -> int:
            return a + b

        sas_spark.udf.register("add", add_without_type_hint, IntegerType())
        expected_result = [
            Row(**{"ADD(id, age)": 11}),
            Row(**{"ADD(id, age)": 22}),
            Row(**{"ADD(id, age)": 33}),
        ]

        result = sas_spark.sql("select add(id, age) from  UDF_TEST_TABLE").collect()
        assert result == expected_result

        def slen(s) -> int:
            return len(s)

        sas_spark.udf.register("slen", slen, IntegerType())
        expected_result = [
            Row(**{"SLEN(TO_VARIANT(Name))": 10}),
            Row(**{"SLEN(TO_VARIANT(Name))": 12}),
            Row(**{"SLEN(TO_VARIANT(Name))": 11}),
        ]
        # we cannot determine the datatype from string. so explicitly call TO_VARIANT.
        result = sas_spark.sql(
            "SELECT slen(TO_VARIANT(Name)) from UDF_TEST_TABLE"
        ).collect()

        assert result == expected_result

    def test_udf_registration_with_lambda(self, sas_spark):
        sas_spark.udf.register("stringLengthString", lambda x: len(x))
        result = sas_spark.sql(
            "SELECT stringLengthString(TO_VARIANT('test'))"
        ).collect()
        expected_result = [Row(**{"STRINGLENGTHSTRING(TO_VARIANT('test'))": "4"})]
        assert result == expected_result

        sas_spark.udf.register("stringLengthInt", lambda x: len(x), IntegerType())
        result = sas_spark.sql("SELECT stringLengthInt(TO_VARIANT('test'))").collect()
        expected_result = [Row(**{"STRINGLENGTHINT(TO_VARIANT('test'))": 4})]

        assert result == expected_result

    def test_udf_registration_with_udf(self, sas_spark):
        slen = udf(lambda s: len(s), IntegerType())
        sas_spark.udf.register("slen", slen)
        result = sas_spark.sql("SELECT slen(TO_VARIANT('test'))").collect()
        expected_result = [Row(**{"SLEN(TO_VARIANT('test'))": 4})]

        assert result == expected_result

        random_udf = udf(lambda: random.randint(0, 100), IntegerType())
        sas_spark.udf.register("random_udf", random_udf)
        result = sas_spark.sql("SELECT random_udf()").collect()
        assert len(result) > 0

    def test_udf_registration_with_pandas_udf(self, sas_spark):
        data = [(1, "john jones", 10), (2, "tracey smith", 20), (3, "amy sanders", 30)]
        df = sas_spark.createDataFrame(data=data, schema=["id", "Name", "age"])
        df.createOrReplaceTempView("UDF_TEST_TABLE")

        def add_one(s: pd.Series) -> pd.Series:
            return s + 1

        sas_spark.udf.register("add_one", add_one)
        result = sas_spark.sql(
            "SELECT add_one(TO_VARIANT(id)) FROM UDF_TEST_TABLE"
        ).collect()
        expected_result = [
            Row(**{"ADD_ONE(id)": "2"}),
            Row(**{"ADD_ONE(id)": "3"}),
            Row(**{"ADD_ONE(id)": "4"}),
        ]

        assert result == expected_result
